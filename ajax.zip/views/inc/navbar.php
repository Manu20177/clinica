<nav class="full-box dashboard-Navbar">
	<ul class="full-box list-unstyled text-right">
		<li class="pull-left">
			<a href="#!" class="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
		</li>
		<li>
			<a href="<?php echo SERVERURL; ?>search/" class="btn-search">
				<i class="zmdi zmdi-search"></i>
			</a>
		</li>
	</ul>
</nav>