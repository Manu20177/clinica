-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 21-07-2025 a las 03:40:10
-- Versión del servidor: 10.11.10-MariaDB-log
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u891835606_demo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `Codigo` varchar(70) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Nombres` varchar(70) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Apellidos` varchar(70) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`Codigo`, `Nombres`, `Apellidos`) VALUES
('AC34869806', 'Administrador', 'Administrador'),
('AC87720821', 'Administrador', 'Principal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cantones`
--

CREATE TABLE `cantones` (
  `id_canton` int(11) NOT NULL,
  `cod_canton` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `id_provincia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `cantones`
--

INSERT INTO `cantones` (`id_canton`, `cod_canton`, `nombre`, `id_provincia`) VALUES
(1, 1, 'CUENCA', 1),
(2, 2, 'GIRON', 1),
(3, 3, 'GUALACEO', 1),
(4, 4, 'NABON', 1),
(5, 5, 'PAUTE', 1),
(6, 6, 'PUCARA', 1),
(7, 7, 'SAN FERNANDO', 1),
(8, 8, 'SANTA ISABEL', 1),
(9, 9, 'SIGSIG', 1),
(10, 10, 'OÑA', 1),
(11, 11, 'CHORDELEG', 1),
(12, 12, 'EL PAN', 1),
(13, 13, 'SEVILLA DE ORO', 1),
(14, 14, 'GUACHAPALA', 1),
(15, 15, 'CAMILO PONCE ENRIQUEZ', 1),
(16, 1, 'GUARANDA', 2),
(17, 2, 'CHILLANES', 2),
(18, 3, 'CHIMBO', 2),
(19, 4, 'ECHEANDIA', 2),
(20, 5, 'SAN MIGUEL', 2),
(21, 6, 'CALUMA', 2),
(22, 7, 'LAS NAVES', 2),
(23, 1, 'AZOGUES', 3),
(24, 2, 'BIBLIAN', 3),
(25, 3, 'CAÑAR', 3),
(26, 4, 'LA TRONCAL', 3),
(27, 5, 'EL TAMBO', 3),
(28, 6, 'DELEG', 3),
(29, 7, 'SUSCAL', 3),
(30, 1, 'TULCAN', 4),
(31, 2, 'BOLIVAR', 4),
(32, 3, 'ESPEJO', 4),
(33, 4, 'MIRA', 4),
(34, 5, 'MONTUFAR', 4),
(35, 6, 'SAN PEDRO DE HUACA', 4),
(36, 1, 'LATACUNGA', 5),
(37, 2, 'LA MANA', 5),
(38, 3, 'PANGUA', 5),
(39, 4, 'PUJILI', 5),
(40, 5, 'SALCEDO', 5),
(41, 6, 'SAQUISILI', 5),
(42, 7, 'SIGCHOS', 5),
(43, 1, 'RIOBAMBA', 6),
(44, 2, 'ALAUSI', 6),
(45, 3, 'COLTA', 6),
(46, 4, 'CHAMBO', 6),
(47, 5, 'CHUNCHI', 6),
(48, 6, 'GUAMOTE', 6),
(49, 7, 'GUANO', 6),
(50, 8, 'PALLATANGA', 6),
(51, 9, 'PENIPE', 6),
(52, 10, 'CUMANDA', 6),
(53, 1, 'MACHALA', 7),
(54, 2, 'ARENILLAS', 7),
(55, 3, 'ATAHUALPA', 7),
(56, 4, 'BALSAS', 7),
(57, 5, 'CHILLA', 7),
(58, 6, 'EL GUABO', 7),
(59, 7, 'HUAQUILLAS', 7),
(60, 8, 'MARCABELI', 7),
(61, 9, 'PASAJE', 7),
(62, 10, 'PIÑAS', 7),
(63, 11, 'PORTOVELO', 7),
(64, 12, 'SANTA ROSA', 7),
(65, 13, 'ZARUMA', 7),
(66, 14, 'LAS LAJAS', 7),
(67, 1, 'ESMERALDAS', 8),
(68, 2, 'ELOY ALFARO', 8),
(69, 3, 'MUISNE', 8),
(70, 4, 'QUININDE', 8),
(71, 5, 'SAN LORENZO', 8),
(72, 6, 'ATACAMES', 8),
(73, 7, 'RIOVERDE', 8),
(74, 1, 'GUAYAQUIL', 9),
(75, 2, 'ALFREDO BAQUERIZO MORENO', 9),
(76, 3, 'BALAO', 9),
(77, 4, 'BALZAR', 9),
(78, 5, 'COLIMES', 9),
(79, 6, 'DAULE', 9),
(80, 7, 'DURAN', 9),
(81, 8, 'EL EMPALME', 9),
(82, 9, 'EL TRIUNFO', 9),
(83, 10, 'MILAGRO', 9),
(84, 11, 'NARANJAL', 9),
(85, 12, 'NARANJITO', 9),
(86, 13, 'PALESTINA', 9),
(87, 14, 'PEDRO CARBO', 9),
(88, 16, 'SAMBORONDON', 9),
(89, 18, 'SANTA LUCIA', 9),
(90, 19, 'SALITRE', 9),
(91, 20, 'SAN JACINTO DE YAGUACHI', 9),
(92, 21, 'PLAYAS', 9),
(93, 22, 'SIMON BOLIVAR', 9),
(94, 23, 'CORONEL MARCELINO MARIDUEÑA', 9),
(95, 24, 'LOMAS DE SARGENTILLO', 9),
(96, 25, 'NOBOL', 9),
(97, 27, 'GENERAL ANTONIO ELIZALDE', 9),
(98, 28, 'ISIDRO AYORA', 9),
(99, 1, 'IBARRA', 10),
(100, 2, 'ANTONIO ANTE', 10),
(101, 3, 'COTACACHI', 10),
(102, 4, 'OTAVALO', 10),
(103, 5, 'PIMAMPIRO', 10),
(104, 6, 'SAN MIGUEL DE URCUQUI', 10),
(105, 1, 'LOJA', 11),
(106, 2, 'CALVAS', 11),
(107, 3, 'CATAMAYO', 11),
(108, 4, 'CELICA', 11),
(109, 5, 'CHAGUARPAMBA', 11),
(110, 6, 'ESPINDOLA', 11),
(111, 7, 'GONZANAMA', 11),
(112, 8, 'MACARA', 11),
(113, 9, 'PALTAS', 11),
(114, 10, 'PUYANGO', 11),
(115, 11, 'SARAGURO', 11),
(116, 12, 'SOZORANGA', 11),
(117, 13, 'ZAPOTILLO', 11),
(118, 14, 'PINDAL', 11),
(119, 15, 'QUILANGA', 11),
(120, 16, 'OLMEDO', 11),
(121, 1, 'BABAHOYO', 12),
(122, 2, 'BABA', 12),
(123, 3, 'MONTALVO', 12),
(124, 4, 'PUEBLOVIEJO', 12),
(125, 5, 'QUEVEDO', 12),
(126, 6, 'URDANETA', 12),
(127, 7, 'VENTANAS', 12),
(128, 8, 'VINCES', 12),
(129, 9, 'PALENQUE', 12),
(130, 10, 'BUENA FE', 12),
(131, 11, 'VALENCIA', 12),
(132, 12, 'MOCACHE', 12),
(133, 13, 'QUINSALOMA', 12),
(134, 1, 'PORTOVIEJO', 13),
(135, 2, 'BOLIVAR', 13),
(136, 3, 'CHONE', 13),
(137, 4, 'EL CARMEN', 13),
(138, 5, 'FLAVIO ALFARO', 13),
(139, 6, 'JIPIJAPA', 13),
(140, 7, 'JUNIN', 13),
(141, 8, 'MANTA', 13),
(142, 9, 'MONTECRISTI', 13),
(143, 10, 'PAJAN', 13),
(144, 11, 'PICHINCHA', 13),
(145, 12, 'ROCAFUERTE', 13),
(146, 13, 'SANTA ANA', 13),
(147, 14, 'SUCRE', 13),
(148, 15, 'TOSAGUA', 13),
(149, 16, '24 DE MAYO', 13),
(150, 17, 'PEDERNALES', 13),
(151, 18, 'OLMEDO', 13),
(152, 19, 'PUERTO LOPEZ', 13),
(153, 20, 'JAMA', 13),
(154, 21, 'JARAMIJO', 13),
(155, 22, 'SAN VICENTE', 13),
(156, 1, 'MORONA', 14),
(157, 2, 'GUALAQUIZA', 14),
(158, 3, 'LIMON INDANZA', 14),
(159, 4, 'PALORA', 14),
(160, 5, 'SANTIAGO', 14),
(161, 6, 'SUCUA', 14),
(162, 7, 'HUAMBOYA', 14),
(163, 8, 'SAN JUAN BOSCO', 14),
(164, 9, 'TAISHA', 14),
(165, 10, 'LOGROÑO', 14),
(166, 11, 'PABLO SEXTO', 14),
(167, 12, 'TIWINTZA', 14),
(168, 1, 'TENA', 15),
(169, 3, 'ARCHIDONA', 15),
(170, 4, 'EL CHACO', 15),
(171, 7, 'QUIJOS', 15),
(172, 9, 'CARLOS JULIO AROSEMENA TOLA', 15),
(173, 1, 'PASTAZA', 16),
(174, 2, 'MERA', 16),
(175, 3, 'SANTA CLARA', 16),
(176, 4, 'ARAJUNO', 16),
(177, 1, 'DISTRITO METROPOLITANO DE QUITO', 17),
(178, 2, 'CAYAMBE', 17),
(179, 3, 'MEJIA', 17),
(180, 4, 'PEDRO MONCAYO', 17),
(181, 5, 'RUMIÑAHUI', 17),
(182, 7, 'SAN MIGUEL DE LOS BANCOS', 17),
(183, 8, 'PEDRO VICENTE MALDONADO', 17),
(184, 9, 'PUERTO QUITO', 17),
(185, 1, 'AMBATO', 18),
(186, 2, 'BAÑOS DE AGUA SANTA', 18),
(187, 3, 'CEVALLOS', 18),
(188, 4, 'MOCHA', 18),
(189, 5, 'PATATE', 18),
(190, 6, 'QUERO', 18),
(191, 7, 'SAN PEDRO DE PELILEO', 18),
(192, 8, 'SANTIAGO DE PILLARO', 18),
(193, 9, 'TISALEO', 18),
(194, 1, 'ZAMORA', 19),
(195, 2, 'CHINCHIPE', 19),
(196, 3, 'NANGARITZA', 19),
(197, 4, 'YACUAMBI', 19),
(198, 5, 'YANTZAZA', 19),
(199, 6, 'EL PANGUI', 19),
(200, 7, 'CENTINELA DEL CONDOR', 19),
(201, 8, 'PALANDA', 19),
(202, 9, 'PAQUISHA', 19),
(203, 1, 'SAN CRISTOBAL', 20),
(204, 2, 'ISABELA', 20),
(205, 3, 'SANTA CRUZ', 20),
(206, 1, 'LAGO AGRIO', 21),
(207, 2, 'GONZALO PIZARRO', 21),
(208, 3, 'PUTUMAYO', 21),
(209, 4, 'SHUSHUFINDI', 21),
(210, 5, 'SUCUMBIOS', 21),
(211, 6, 'CASCALES', 21),
(212, 7, 'CUYABENO', 21),
(213, 1, 'ORELLANA', 22),
(214, 2, 'AGUARICO', 22),
(215, 3, 'LA JOYA DE LOS SACHAS', 22),
(216, 4, 'LORETO', 22),
(217, 1, 'SANTO DOMINGO', 23),
(218, 2, 'LA CONCORDIA', 23),
(219, 1, 'SANTA ELENA', 24),
(220, 2, 'LA LIBERTAD', 24),
(221, 3, 'SALINAS', 24);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase`
--

CREATE TABLE `clase` (
  `id` int(7) NOT NULL,
  `Video` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Titulo` varchar(535) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Tutor` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Descripcion` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Adjuntos` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `estado_clase` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `clase`
--

INSERT INTO `clase` (`id`, `Video`, `Fecha`, `Titulo`, `Tutor`, `Descripcion`, `Adjuntos`, `estado_clase`) VALUES
(109, '<div style=\"width: 100%;\"><div style=\"position: relative; padding-bottom: 56.25%; padding-top: 0; height: 0;\"><iframe title=\"Curso1 Seguro Depósitos\" frameborder=\"0\" width=\"1200px\" height=\"675px\" style=\"position: absolute; top: 0; left: 0; width: 100%; height: 100%;\" src=\"https://view.genially.com/6568ae47a90e770014721328\" type=\"text/html\" allowscriptaccess=\"always\" allowfullscreen=\"true\" scrolling=\"yes\" allownetworking=\"all\"></iframe> </div> </div>', '2025-07-02', 'SEGURO DE DEPÓSITOS', 'COSEDE', '<p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">¡Bienvenidos queridos Estudiantes!<br></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">En este curso conoceremos los mecanismos de seguridad financiera, las entidades que lo componen, que es el Seguro de Depósitos y como interviene la COSEDE en el caso de una liquidación forzosa de una entidad financiera.</p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><em>POR FAVOR ASEGÚRATE DE USAR EL EXPLORADOR MOZILLA FIREFOX PARA EL CORRECTO FUNCIONAMIENTO DEL CURSO.</em></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span style=\"font-size: 0.9375rem;\"><span style=\"font-weight: bolder;\">¡IMPORTANTE: LOS CERTIFICADOS PODRÁN DESCARGARLOS HASTA 6 MESES POSTERIORES A SU GENERACIÓN!</span></span></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span style=\"font-size: 0.9375rem;\">¡Empecemos!</span></p><p>Si deseas certificarte directamente de la plataforma EDUCATE de la COSEDE accede mediante el siguiente link:</p><p><a href=\"https://educate.cosede.gob.ec/course/view.php?id=10800#section-1\" title=\"SEGURO DE DEPÓSITOS\" target=\"_blank\">Haz click aqui para poder acceder</a></p><div class=\"my-2\" style=\"--tw-border-spacing-x: 0; --tw-border-spacing-y: 0; --tw-translate-x: 0; --tw-translate-y: 0; --tw-rotate: 0; --tw-skew-x: 0; --tw-skew-y: 0; --tw-scale-x: 1; --tw-scale-y: 1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness: proximity; --tw-gradient-from-position: ; --tw-gradient-via-position: ; --tw-gradient-to-position: ; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width: 0px; --tw-ring-offset-color: #fff; --tw-ring-color: rgb(59 130 246 / .5); --tw-ring-offset-shadow: 0 0 #0000; --tw-ring-shadow: 0 0 #0000; --tw-shadow: 0 0 #0000; --tw-shadow-colored: 0 0 #0000; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; --tw-contain-size: ; --tw-contain-layout: ; --tw-contain-paint: ; --tw-contain-style: ; border-width: 0px; border-style: solid; border-color: rgb(227, 227, 227); margin-top: 0.5rem; margin-bottom: 0.5rem; color: rgb(44, 44, 54); font-family: system-ui, ui-sans-serif, -apple-system, BlinkMacSystemFont, sans-serif, Inter, NotoSansHans; letter-spacing: 0.32px; white-space-collapse: preserve-breaks;\"></div>', '', 4),
(111, '<iframe width=\"851\" height=\"480\" src=\"https://www.youtube.com/embed/f41p_MZoDkI\" title=\"Introducción al Riesgo Operativo\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-02', 'Introducción al Riesgo Operativo', 'Responsable de Riesgos', '<p data-start=\"145\" data-end=\"183\"><strong data-start=\"145\" data-end=\"183\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"185\" data-end=\"500\">En este curso abordaremos los fundamentos del <strong data-start=\"231\" data-end=\"251\">riesgo operativo</strong>, un tipo de riesgo presente en todas las organizaciones. Conoceremos cómo identificar, medir, controlar y mitigar los eventos que pueden afectar negativamente a una entidad debido a fallas humanas, tecnológicas, de procesos o por factores externos.</p>\r\n<p data-start=\"502\" data-end=\"738\">También revisaremos el <strong data-start=\"525\" data-end=\"575\">Sistema de Gestión de Riesgo Operativo (SIGRO)</strong> y su aplicación dentro del marco normativo vigente en el Ecuador, especialmente en entidades del sector financiero popular y solidario bajo el control de la SEPS.</p><p data-start=\"502\" data-end=\"738\"><strong data-start=\"846\" data-end=\"861\">IMPORTANTE:</strong><br data-start=\"861\" data-end=\"864\">\r\n</p><p data-start=\"502\" data-end=\"738\"><span data-start=\"846\" data-end=\"861\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.</span></p><p><span data-start=\"846\" data-end=\"861\"><strong>¡Comencemos!</strong></span></p>', 'Introduccion_al_Riesgo_Operativo.pdf', 4),
(112, '<iframe width=\"803\" height=\"425\" src=\"https://www.youtube.com/embed/a68Q62vatMU\" title=\"Marco Normativo\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-03', 'Fundamentos de la Economía Popular y Solidaria', 'Responsable de Educación', '<p data-start=\"178\" data-end=\"216\"><strong data-start=\"178\" data-end=\"216\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"218\" data-end=\"530\">En este curso abordaremos los <strong data-start=\"248\" data-end=\"304\">fundamentos de la Economía Popular y Solidaria (EPS)</strong>, un modelo económico basado en la solidaridad, la cooperación y la reciprocidad, donde las personas se organizan para producir, intercambiar, financiar y consumir con el objetivo de alcanzar el <strong data-start=\"499\" data-end=\"529\">buen vivir y el bien común</strong>.</p>\r\n<p data-start=\"532\" data-end=\"949\">Revisaremos los <strong data-start=\"548\" data-end=\"586\">principios fundamentales de la EPS</strong>, su estructura organizativa, las diferencias frente a las empresas tradicionales, así como el rol clave de la <strong data-start=\"697\" data-end=\"756\">Superintendencia de Economía Popular y Solidaria (SEPS)</strong> como ente regulador del sistema. También conoceremos las organizaciones reconocidas por la LOEPS y analizaremos el impacto de la EPS en la inclusión financiera y el desarrollo económico local.</p>\r\n<p data-start=\"1057\" data-end=\"1273\"><strong data-start=\"1057\" data-end=\"1072\">IMPORTANTE:</strong><br data-start=\"1072\" data-end=\"1075\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br></p>\r\n<p data-start=\"1275\" data-end=\"1291\"><strong data-start=\"1275\" data-end=\"1291\">¡Comencemos!</strong></p>\r\n<p data-start=\"1293\" data-end=\"1444\"><br></p>', ',Fundamentos_de_la_Economía_Popular_y_Solidaria.pdf', 4),
(113, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/F_oeM1XEXII\" title=\"Video Características de las Organizaciones de la EPS\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-03', 'Funcionamiento de las Organizaciones de la EPS', 'Responsable de Educación', '<p data-start=\"217\" data-end=\"255\"><strong data-start=\"217\" data-end=\"255\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"257\" data-end=\"510\">En este módulo exploraremos el F<strong data-start=\"288\" data-end=\"377\">uncionamiento Interno de las Organizaciones de la Economía Popular y Solidaria (EPS)</strong>, comprendiendo su estructura organizativa, los roles y atribuciones de sus órganos de gobierno, y las normas que rigen su operación.</p>\r\n<p data-start=\"512\" data-end=\"897\">Analizaremos tanto el caso de las <strong data-start=\"546\" data-end=\"562\">cooperativas</strong> como de las <strong data-start=\"575\" data-end=\"591\">asociaciones</strong>, con un enfoque práctico sobre la relación del socio con su organización, el papel de la Asamblea o Junta General, los Consejos de Administración y Vigilancia, la gerencia o administración, las comisiones especiales, y la importancia del cumplimiento normativo para una gestión transparente y democrática.</p>\r\n<p data-start=\"1005\" data-end=\"1221\"><strong data-start=\"1005\" data-end=\"1020\">IMPORTANTE:</strong><br data-start=\"1020\" data-end=\"1023\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1157\" data-end=\"1160\"><br></p>\r\n<p data-start=\"1223\" data-end=\"1239\"><strong data-start=\"1223\" data-end=\"1239\">¡Comencemos!</strong></p>\r\n<p data-start=\"1241\" data-end=\"1392\"><br></p>', 'Funcionamiento_de_las_Organizaciones_de_las_EPS.pdf', 4),
(114, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/rojIbmQZWV0\" title=\"Gobierno Cooperativo\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-03', 'Gobierno Cooperativo', 'Responsable de Educación', '<p data-start=\"184\" data-end=\"222\"><strong data-start=\"184\" data-end=\"222\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"224\" data-end=\"441\">En este módulo aprenderemos sobre el <strong data-start=\"261\" data-end=\"285\">Gobierno Cooperativo</strong>, un componente esencial para asegurar la transparencia, participación y sostenibilidad en las organizaciones del sector de la Economía Popular y Solidaria.</p>\r\n<p data-start=\"443\" data-end=\"764\">Analizaremos los principios del <strong data-start=\"475\" data-end=\"504\">buen gobierno cooperativo</strong>, los marcos normativos que lo respaldan, su aplicación en la estructura organizativa de cooperativas y asociaciones, y la importancia de la ética y el liderazgo responsable. También abordaremos los desafíos y las causas que limitan su implementación efectiva.</p>\r\n<p data-start=\"766\" data-end=\"999\">Este curso está diseñado para <strong data-start=\"796\" data-end=\"868\">fortalecer las capacidades de representantes, directivos y empleados</strong>, promoviendo una gestión ética y participativa conforme a la normativa vigente y enfocada en el beneficio colectivo de los socios.</p>\r\n<p data-start=\"1107\" data-end=\"1323\"><strong data-start=\"1107\" data-end=\"1122\">IMPORTANTE:</strong><br data-start=\"1122\" data-end=\"1125\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1259\" data-end=\"1262\"><br></p>\r\n<p data-start=\"1325\" data-end=\"1341\"><strong data-start=\"1325\" data-end=\"1341\">¡Comencemos!</strong></p>\r\n<p data-start=\"1343\" data-end=\"1494\"><br></p>', 'Gobierno_Cooperativo.pdf', 4),
(115, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/7tWPWU3YWRo\" title=\"Balance Social\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-04', 'Balance Social para Cooperativas de Ahorro y Crédito y Mutualistas', 'Responsable de Educación', '<p data-start=\"181\" data-end=\"219\"><strong data-start=\"181\" data-end=\"219\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"221\" data-end=\"498\">En este módulo aprenderemos sobre el <strong data-start=\"258\" data-end=\"276\">Balance Social</strong>, una herramienta clave en la gestión de las cooperativas y mutualistas, que permite evaluar su impacto social, ambiental y económico, así como rendir cuentas de manera transparente a los socios y a la sociedad en general.</p>\r\n<p data-start=\"500\" data-end=\"883\">Revisaremos su base legal, los antecedentes históricos, objetivos, beneficios y el proceso de elaboración del informe de Balance Social. También abordaremos el marco normativo establecido en la Constitución y en la Ley Orgánica de Economía Popular y Solidaria, además de las responsabilidades específicas que tienen los diferentes órganos de gobierno de la cooperativa en su gestión.</p>\r\n<p data-start=\"885\" data-end=\"1072\">Este curso fortalecerá los conocimientos de <strong data-start=\"929\" data-end=\"963\">socios, directivos y empleados</strong>, promoviendo el compromiso con el bienestar colectivo y la práctica efectiva de los principios cooperativos.</p>\r\n<p data-start=\"1180\" data-end=\"1396\"><strong data-start=\"1180\" data-end=\"1195\">IMPORTANTE:</strong><br data-start=\"1195\" data-end=\"1198\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1332\" data-end=\"1335\"><br></p>\r\n<p data-start=\"1398\" data-end=\"1414\"><strong data-start=\"1398\" data-end=\"1414\">¡Comencemos!</strong></p>', 'Balance_Social.pdf', 4),
(116, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/FKVp_RD_E2g\" title=\"Control Interno\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-04', 'Control Interno para Organizaciones de la Economía Popular y Solidaria', 'Responsable de Educación', '<p data-start=\"279\" data-end=\"317\"><strong data-start=\"279\" data-end=\"317\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"319\" data-end=\"657\">En este módulo estudiaremos los <strong data-start=\"351\" data-end=\"399\">principios y componentes del control interno</strong>, una herramienta fundamental para fortalecer la gestión organizacional, prevenir riesgos, garantizar el cumplimiento normativo y asegurar el uso eficiente de los recursos dentro de las <strong data-start=\"585\" data-end=\"656\">organizaciones del sector de la Economía Popular y Solidaria (OEPS)</strong>.</p>\r\n<p data-start=\"659\" data-end=\"957\">Durante el curso conoceremos cómo se estructura un sistema de control interno, su función en la toma de decisiones, el rol de los diferentes niveles de responsabilidad dentro de la organización y cómo este sistema contribuye al logro de los objetivos institucionales con integridad y transparencia.</p>\r\n<p data-start=\"959\" data-end=\"1186\">Este módulo está dirigido a <strong data-start=\"987\" data-end=\"1046\">socios, directivos, empleados y responsables de control</strong>, que deseen fortalecer la gobernabilidad institucional y asegurar el correcto funcionamiento de los procesos administrativos y financieros.</p>\r\n<p data-start=\"1294\" data-end=\"1510\"><strong data-start=\"1294\" data-end=\"1309\">IMPORTANTE:</strong><br data-start=\"1309\" data-end=\"1312\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1446\" data-end=\"1449\"><br></p>\r\n<p data-start=\"1512\" data-end=\"1528\"><strong data-start=\"1512\" data-end=\"1528\">¡Comencemos!</strong></p>', 'CONTROL_INTERNO_PARA_OEPS.pdf', 4),
(117, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/5oJPclSzF3I\" title=\"Procedimiento Parlamentario\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-04', 'Procedimiento Parlamentario y de Elecciones en el Sector Financiero Popular y Solidario', 'Responsable de Educación', '<p data-start=\"204\" data-end=\"242\"><strong data-start=\"204\" data-end=\"242\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"244\" data-end=\"566\">En este módulo aprenderemos sobre el <strong data-start=\"281\" data-end=\"312\">procedimiento parlamentario</strong> y las normas que rigen los procesos de <strong data-start=\"352\" data-end=\"375\">elecciones internas</strong> dentro de las organizaciones del sector de la Economía Popular y Solidaria. Estas reglas aseguran el funcionamiento democrático, participativo y ordenado de las asambleas y juntas generales.</p>\r\n<p data-start=\"568\" data-end=\"924\">Abordaremos temas como la <strong data-start=\"594\" data-end=\"639\">convocatoria y desarrollo de las sesiones</strong>, el quórum legal, la validez de las resoluciones, la forma de impugnar decisiones, y los requisitos para garantizar procesos electorales legítimos y transparentes. También conoceremos el rol de la Superintendencia de Economía Popular y Solidaria en el control de estos procedimientos.</p>\r\n<p data-start=\"926\" data-end=\"1114\">Este módulo está dirigido a <strong data-start=\"954\" data-end=\"1010\">socios, directivos y miembros de comités electorales</strong> que deseen fortalecer sus conocimientos para ejercer sus funciones de forma ética, legal y responsable.</p>\r\n<p data-start=\"1222\" data-end=\"1438\"><strong data-start=\"1222\" data-end=\"1237\">IMPORTANTE:</strong><br data-start=\"1237\" data-end=\"1240\">\r\n', 'Procedimiento_Parlamentario_y_de_Elecciones.pdf', 4),
(118, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/wlUCByLYg1E\" title=\"Principios de la Economía Popular y Solidaria\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-04', 'Gobernanza y Transparencia en la Cooperativa', 'Responsable de Educación', '<p data-start=\"209\" data-end=\"247\"><span data-start=\"209\" data-end=\"247\" style=\"font-weight: 700;\">¡Bienvenidos queridos Estudiantes!</span></p><p data-start=\"249\" data-end=\"626\">En este módulo profundizaremos en los fundamentos del&nbsp;<span data-start=\"303\" data-end=\"332\" style=\"font-weight: 700;\">buen gobierno cooperativo</span>, la&nbsp;<span data-start=\"337\" data-end=\"368\" style=\"font-weight: 700;\">transparencia institucional</span>, y la&nbsp;<span data-start=\"375\" data-end=\"398\" style=\"font-weight: 700;\">ética en la gestión</span>&nbsp;dentro de las cooperativas de ahorro y crédito. Estos principios son esenciales para fortalecer la confianza, la participación democrática y la sostenibilidad de las organizaciones del sector de la Economía Popular y Solidaria.</p><p data-start=\"628\" data-end=\"1034\">Durante el curso conoceremos el rol y las responsabilidades del Consejo de Administración, los mecanismos para prevenir conflictos de interés, el alcance del Código de Ética y Comportamiento, y la importancia de garantizar el acceso a la información financiera, organizacional y estratégica. También abordaremos el control democrático, la participación económica de los socios y la autonomía institucional.</p><p data-start=\"1036\" data-end=\"1211\">Este módulo está diseñado para que&nbsp;<span data-start=\"1071\" data-end=\"1122\" style=\"font-weight: 700;\">socios, directivos, empleados y administradores</span>&nbsp;desarrollen una gestión ética, participativa y comprometida con la rendición de cuentas.</p><br><p data-start=\"1319\" data-end=\"1535\"><span data-start=\"1319\" data-end=\"1334\" style=\"font-weight: 700;\">IMPORTANTE:</span><br data-start=\"1334\" data-end=\"1337\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1471\" data-end=\"1474\"><br></p><p data-start=\"1537\" data-end=\"1553\"><span data-start=\"1537\" data-end=\"1553\" style=\"font-weight: 700;\">¡Comencemos!</span></p>', '', 4),
(120, '', '2025-07-04', 'Responsabilidad Social y Compromiso Comunitario', 'Responsable de Educación', '<p data-start=\"196\" data-end=\"234\"><strong data-start=\"196\" data-end=\"234\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"236\" data-end=\"455\">En este módulo abordaremos la importancia de la <strong data-start=\"284\" data-end=\"322\">responsabilidad social cooperativa</strong> y su compromiso con el desarrollo comunitario y ambiental, como parte esencial de los principios de la Economía Popular y Solidaria.</p>\r\n<p data-start=\"457\" data-end=\"853\">Analizaremos cómo las cooperativas deben actuar con ética, equidad y solidaridad, promoviendo prácticas sostenibles, inclusión financiera, educación cooperativa y relaciones transparentes con su entorno. Además, revisaremos los <strong data-start=\"685\" data-end=\"709\">valores corporativos</strong> que guían el comportamiento institucional, tales como la honestidad, la prudencia financiera, la participación democrática y el trabajo en red.</p>\r\n<p data-start=\"855\" data-end=\"1105\">También conoceremos el rol de la <strong data-start=\"888\" data-end=\"912\">educación financiera</strong> como herramienta clave para empoderar a los socios y empleados, así como la importancia de la cooperación entre cooperativas para fortalecer al sector y fomentar el desarrollo económico local.</p>\r\n<p data-start=\"1213\" data-end=\"1429\"><strong data-start=\"1213\" data-end=\"1228\">IMPORTANTE:</strong><br data-start=\"1228\" data-end=\"1231\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1365\" data-end=\"1368\"><br></p>\r\n<p data-start=\"1431\" data-end=\"1447\"><strong data-start=\"1431\" data-end=\"1447\">¡Comencemos!</strong></p>', 'Responsabilidad_Social_y_Compromiso_Comunitario.pdf', 4),
(121, '', '2025-07-04', 'Estructura y  Funcionamiento de  las Cooperativas y  la Asamblea General', 'Responsable de Educación', '<p data-start=\"232\" data-end=\"270\"><strong data-start=\"232\" data-end=\"270\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"272\" data-end=\"532\">En este módulo conoceremos la <strong data-start=\"302\" data-end=\"410\">estructura organizativa de las cooperativas y asociaciones del sector de la Economía Popular y Solidaria</strong>, así como el papel central que cumple la <strong data-start=\"452\" data-end=\"480\">Asamblea o Junta General</strong>, como máximo órgano de gobierno de estas entidades.</p>\r\n<p data-start=\"534\" data-end=\"999\">Aprenderemos sobre los <strong data-start=\"557\" data-end=\"579\">tipos de asambleas</strong>, los <strong data-start=\"585\" data-end=\"621\">derechos y deberes de los socios</strong>, la forma adecuada de convocarlas (presencial o virtual), las etapas previas, concurrentes y posteriores al evento, y los mecanismos de votación establecidos por la normativa vigente. Se destacará la importancia de la participación democrática, el principio de \"una persona, un voto\" y las <strong data-start=\"912\" data-end=\"951\">atribuciones de la Asamblea General</strong> en la toma de decisiones clave para la entidad.</p>\r\n<p data-start=\"1001\" data-end=\"1201\">Este módulo está diseñado para fortalecer las competencias de socios, directivos y empleados, promoviendo una participación activa, informada y responsable en los procesos de gobernanza institucional.</p>\r\n<p data-start=\"1309\" data-end=\"1525\"><strong data-start=\"1309\" data-end=\"1324\">IMPORTANTE:</strong><br data-start=\"1324\" data-end=\"1327\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1461\" data-end=\"1464\"><br></p>\r\n<p data-start=\"1527\" data-end=\"1543\"><strong data-start=\"1527\" data-end=\"1543\">¡Comencemos!</strong></p>', 'Estructura_y_Funcionamiento_de_las_Cooperativas.pdf', 4),
(122, '<div style=\"width: 100%;\"><div style=\"position: relative; padding-bottom: 56.25%; padding-top: 0; height: 0;\"><iframe title=\"CURSO 2: FONDO LIQUIDEZ Y SEGURO DEPOSITOS\" frameborder=\"0\" width=\"1200px\" height=\"675px\" style=\"position: absolute; top: 0; left: 0; width: 100%; height: 100%;\" src=\"https://view.genially.com/65709fe05adcfa0014221a4b\" type=\"text/html\" allowscriptaccess=\"always\" allowfullscreen=\"true\" scrolling=\"yes\" allownetworking=\"all\"></iframe> </div> </div>', '2025-07-07', '2 CURSO FONDO DEL SEGURO DE DEPOSITOS', 'COSEDE', '<p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span lang=\"ES\">Te damos la bienvenida al curso de&nbsp;<strong>FONDO DEL SEGURO DE DEPÓSITOS Y FONDO DE LIQUIDEZ</strong></span></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span style=\"font-size: 0.9375rem;\">El objetivo es que el alumno conozca respecto a los Fondos de Seguro de Depósitos de los Sectores Financieros Privado y Popular y Solidario administrados por la <strong>COSEDE</strong>, su sostenibilidad y fuentes de fondeo; además del proceso del Pago del Seguro de Depósitos en el caso de liquidación forzosa de una entidad financiera regulada por el respectivo organismo de control, en los términos que la Ley lo señala.</span><br></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span lang=\"ES\">Además, que conozca sobre la Administración del Fondo de Liquidez, sus aspectos generales, sostenibilidad, tipos de préstamos e inversiones, gestionada por la <strong>COSEDE</strong>.</span></p><span lang=\"ES\"></span><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><strong>POR FAVOR ASEGÚRATE DE USAR EL EXPLORADOR MOZILLA FIREFOX PARA EL CORRECTO FUNCIONAMIENTO DEL CURSO.</strong></p><p><span style=\"color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">¡Empecemos!</span></p>', '', 4),
(123, '<div style=\"width: 100%;\"><div style=\"position: relative; padding-bottom: 56.25%; padding-top: 0; height: 0;\"><iframe title=\"CURSO 3: SEGURO DE SEGUROS PRIVADOS\" frameborder=\"0\" width=\"1200px\" height=\"675px\" style=\"position: absolute; top: 0; left: 0; width: 100%; height: 100%;\" src=\"https://view.genially.com/6571d1580ce4f60015f97b93\" type=\"text/html\" allowscriptaccess=\"always\" allowfullscreen=\"true\" scrolling=\"yes\" allownetworking=\"all\"></iframe> </div> </div>', '2025-07-07', '3 CURSO SEGURO DE SEGUROS PRIVADOS', 'COSEDE', '<p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">¡Bienvenidos queridos Estudiantes!<br></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">En este curso conoceremos sobre el Seguro de Seguros Privados, una vez que una empresa aseguradora privada es declarada en liquidación forzosa por parte del respectivo Organismo de Control y como interviene la COSEDE en el caso de dicha liquidación forzosa.</p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><strong>POR FAVOR ASEGÚRATE DE USAR EL EXPLORADOR MOZILLA FIREFOX PARA EL CORRECTO FUNCIONAMIENTO DEL CURSO.</strong></p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span style=\"font-weight: bolder;\">¡IMPORTANTE: LOS CERTIFICADOS PODRÁN DESCARGARLOS HASTA 6 MESES POSTERIORES A SU GENERACIÓN!</span><br></p><p><span style=\"color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">¡Empecemos!</span></p>', '', 4),
(124, '<div style=\"width: 100%;\"><div style=\"position: relative; padding-bottom: 56.25%; padding-top: 0; height: 0;\"><iframe title=\"Presentación Esencial\" frameborder=\"0\" width=\"1200px\" height=\"675px\" style=\"position: absolute; top: 0; left: 0; width: 100%; height: 100%;\" src=\"https://view.genially.com/6578b9d7a5c46d001511841f\" type=\"text/html\" allowscriptaccess=\"always\" allowfullscreen=\"true\" scrolling=\"yes\" allownetworking=\"all\"></iframe> </div> </div>', '2025-07-08', '4 CURSO COSEDE TERRITORIAL', 'COSEDE', '<p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><span lang=\"ES\">Te damos la bienvenida al curso de&nbsp;SEGURO DE DEPÓSITOS - COSEDE TERRITORIAL<br></span></p><span lang=\"ES\"><br></span><p><span style=\"color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">El objetivo es que el alumno conozca el proceso del Pago del Seguro de Depósitos como un mecanismo de contingencia financiera gratuito para la ciudadanía, el cual es pagar los depósitos a los clientes de las entidades financieras cubiertas por el este Seguro, en el caso de liquidación forzosa de cualquiera de ellas, en los términos que la Ley lo señala.</span></p><br style=\"color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">POR FAVOR ASEGÚRATE DE USAR EL EXPLORADOR MOZILLA FIREFOX PARA EL CORRECTO FUNCIONAMIENTO DEL CURSO.</p><p style=\"margin-bottom: 1rem; color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\"><strong>¡IMPORTANTE: LOS CERTIFICADOS PODRÁN DESCARGARLOS HASTA 6 MESES POSTERIORES A SU GENERACIÓN!<br></strong></p><p><span style=\"color: rgb(55, 58, 60); font-family: alegreyasansL, Arial, Helvetica, sans-serif;\">¡Empecemos!</span></p>', '', 4),
(125, '', '2025-07-08', 'Cumplimiento Normativo y Calificación de Idoneidad de los Administradores y Vocales de los Consejos de Administración y Vigilancia de las Entidades del Sector Financiero Popular y Solidario', 'Responsable de Educación', '<p data-start=\"228\" data-end=\"266\"><strong data-start=\"228\" data-end=\"266\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"268\" data-end=\"645\">En esta clase abordaremos los aspectos fundamentales del <strong data-start=\"325\" data-end=\"351\">cumplimiento normativo</strong> en el marco de la <strong data-start=\"370\" data-end=\"402\">Economía Popular y Solidaria</strong>, enfocándonos especialmente en los procedimientos para la <strong data-start=\"461\" data-end=\"490\">calificación de idoneidad</strong> y <strong data-start=\"493\" data-end=\"520\">registro de los vocales</strong> de los Consejos de Administración y Vigilancia, así como de <strong data-start=\"581\" data-end=\"616\">gerentes y gerentes subrogantes</strong> de las entidades del sector.</p>\r\n<p data-start=\"647\" data-end=\"1113\">Analizaremos los <strong data-start=\"664\" data-end=\"733\">requisitos legales, documentos habilitantes, plazos y condiciones</strong> que deben cumplir las entidades de los diferentes segmentos, según la normativa emitida por la <strong data-start=\"838\" data-end=\"897\">Superintendencia de Economía Popular y Solidaria (SEPS)</strong>. También conoceremos las <strong data-start=\"923\" data-end=\"955\">obligaciones de capacitación</strong> posteriores al registro, el cumplimiento de criterios de formación académica, experiencia, y declaraciones juramentadas como parte del control institucional.</p>\r\n<p data-start=\"1115\" data-end=\"1366\">Este módulo tiene como propósito fortalecer la gobernanza, garantizar la transparencia institucional y asegurar que los órganos directivos estén conformados por personas <strong data-start=\"1285\" data-end=\"1365\">idóneas, capacitadas y comprometidas con los principios del sector solidario.</strong></p>\r\n<p data-start=\"1474\" data-end=\"1690\"><strong data-start=\"1474\" data-end=\"1489\">IMPORTANTE:</strong><br data-start=\"1489\" data-end=\"1492\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1626\" data-end=\"1629\"><br></p>\r\n<p data-start=\"1692\" data-end=\"1708\"><strong data-start=\"1692\" data-end=\"1708\">¡Comencemos!</strong></p><p data-start=\"1710\" data-end=\"1861\"><br></p>', 'Cumplimiento_Normativo.pdf', 4),
(126, '', '2025-07-08', 'Proceso Electoral y Designación de Directivos', 'Responsable de Educación', '<p data-start=\"290\" data-end=\"328\"><strong data-start=\"290\" data-end=\"328\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"330\" data-end=\"626\">En este módulo conoceremos las <strong data-start=\"361\" data-end=\"393\">etapas del proceso electoral</strong> para la <strong data-start=\"402\" data-end=\"425\">elección de vocales</strong> de los Consejos de Administración y de Vigilancia, así como los procedimientos para la <strong data-start=\"513\" data-end=\"568\">designación de directivos y del representante legal</strong> en las organizaciones de la Economía Popular y Solidaria.</p>\r\n<p data-start=\"628\" data-end=\"941\">Estudiaremos las tres fases del proceso electoral:<br data-start=\"686\" data-end=\"689\"><strong data-start=\"692\" data-end=\"708\">-Etapa previa</strong>: Convocatoria, notificación y requisitos.<br data-start=\"750\" data-end=\"753\"><strong data-start=\"756\" data-end=\"777\">-Etapa concurrente</strong>: Desarrollo de la Asamblea/Junta General y mecanismos de votación.<br data-start=\"844\" data-end=\"847\"><strong data-start=\"850\" data-end=\"869\">-Etapa posterior</strong>: Registro de resultados, lectura del acta y formalización ante la SEPS.</p>\r\n<p data-start=\"943\" data-end=\"1242\">Además, revisaremos consideraciones específicas para <strong data-start=\"996\" data-end=\"1019\">asambleas virtuales</strong>, como la convocatoria, el desarrollo, y la socialización del acta. Este conocimiento es esencial para garantizar la legalidad, la transparencia y la participación democrática en las elecciones internas de las cooperativas.</p>\r\n<p data-start=\"1350\" data-end=\"1566\"><strong data-start=\"1350\" data-end=\"1365\">IMPORTANTE:</strong><br data-start=\"1365\" data-end=\"1368\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1502\" data-end=\"1505\"><br></p>\r\n<p data-start=\"1568\" data-end=\"1584\"><strong data-start=\"1568\" data-end=\"1584\">¡Comencemos!</strong></p>', 'Proceso_Electoral.pdf', 4),
(127, '', '2025-07-08', 'Atribuciones y Responsabilidades del Representante Legal, Consejo de Administración y Consejo de Vigilancia', 'Responsable de Educación', '<p data-start=\"280\" data-end=\"318\"><strong data-start=\"280\" data-end=\"318\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"320\" data-end=\"504\">En este módulo conoceremos a profundidad las <strong data-start=\"365\" data-end=\"410\">atribuciones, deberes y responsabilidades</strong> de los principales órganos de gobierno en una cooperativa de la Economía Popular y Solidaria:</p>\r\n<p data-start=\"506\" data-end=\"595\"><strong data-start=\"508\" data-end=\"531\">-Representante Legal</strong><br data-start=\"531\" data-end=\"534\"><strong data-start=\"536\" data-end=\"565\">-Consejo de Administración</strong><br data-start=\"565\" data-end=\"568\"><strong data-start=\"570\" data-end=\"595\">-Consejo de Vigilancia</strong></p>\r\n<p data-start=\"597\" data-end=\"1037\">Estudiaremos las funciones clave que deben cumplir para garantizar el <strong data-start=\"667\" data-end=\"806\">cumplimiento de los principios cooperativos, la transparencia institucional, la buena gobernanza y la sostenibilidad de la organización</strong>. Se detallarán las responsabilidades legales, administrativas, estratégicas y de control que cada órgano debe ejercer, de acuerdo con la normativa vigente emitida por la <strong data-start=\"977\" data-end=\"1036\">Superintendencia de Economía Popular y Solidaria (SEPS)</strong>.</p>\r\n<p data-start=\"1039\" data-end=\"1308\">Esta clase busca fortalecer el conocimiento de socios, dirigentes y empleados sobre el correcto funcionamiento del gobierno cooperativo, destacando la importancia de la participación activa, la rendición de cuentas y el equilibrio de poderes dentro de la organización.</p>\r\n<p data-start=\"1416\" data-end=\"1632\"><strong data-start=\"1416\" data-end=\"1431\">IMPORTANTE:</strong><br data-start=\"1431\" data-end=\"1434\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1568\" data-end=\"1571\"><br></p>\r\n<p data-start=\"1634\" data-end=\"1650\"><strong data-start=\"1634\" data-end=\"1650\">¡Comencemos!</strong></p>', 'Presentación-Atribuciones_Deberes_y_Responsabilidades.pptx', 4),
(128, '', '2025-07-08', 'Plan Estratégico, Plan Operativo y Presupuesto', 'Responsable de Educación', '<p data-start=\"221\" data-end=\"259\"><strong data-start=\"221\" data-end=\"259\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"261\" data-end=\"571\">Aprenderemos los conceptos fundamentales, funciones y estructura del <strong data-start=\"345\" data-end=\"365\">Plan Estratégico</strong>, el <strong data-start=\"370\" data-end=\"400\">Plan Operativo Anual (POA)</strong> y el <strong data-start=\"406\" data-end=\"421\">Presupuesto</strong>, como herramientas clave para la planificación, gestión y evaluación de las cooperativas y asociaciones que integran la Economía Popular y Solidaria.</p>\r\n<p data-start=\"573\" data-end=\"1006\">Exploraremos los elementos esenciales del <strong data-start=\"615\" data-end=\"635\">Plan Estratégico</strong>, incluyendo la formulación de misión, visión, valores, el análisis FODA, la definición de objetivos estratégicos, estrategias, indicadores y metas. También comprenderemos cómo estas directrices a largo plazo se convierten en acciones concretas a través del <strong data-start=\"893\" data-end=\"911\">Plan Operativo</strong>, que organiza metas específicas, actividades, cronogramas, responsables y formas de ejecución.</p>\r\n<p data-start=\"1008\" data-end=\"1193\">Finalmente, conoceremos la estructura básica del <strong data-start=\"1057\" data-end=\"1072\">Presupuesto</strong>, el cual respalda la planificación anual con recursos económicos necesarios para alcanzar los objetivos institucionales.</p>\r\n<p data-start=\"1517\" data-end=\"1733\"><strong data-start=\"1517\" data-end=\"1532\">IMPORTANTE:</strong><br data-start=\"1532\" data-end=\"1535\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1669\" data-end=\"1672\"><br></p>\r\n<p data-start=\"1735\" data-end=\"1751\"><strong data-start=\"1735\" data-end=\"1751\">¡Comencemos!</strong></p>', 'Presentación-Plan_Estrategico,_Operativo_y_Presupuesto.pdf', 4),
(129, '', '2025-07-10', 'Cultura Organizacional y Relaciones Humanas', 'Responsable de Educación', '<p data-start=\"358\" data-end=\"396\"><span data-start=\"358\" data-end=\"396\" style=\"font-weight: 700;\">¡Bienvenidos queridos estudiantes!</span></p><p data-start=\"398\" data-end=\"807\">En esta clase abordaremos los fundamentos de la&nbsp;<span data-start=\"446\" data-end=\"472\" style=\"font-weight: 700;\">cultura organizacional</span>&nbsp;y su impacto en las relaciones humanas y la ética profesional dentro del entorno cooperativo. Conoceremos los&nbsp;<span data-start=\"583\" data-end=\"620\" style=\"font-weight: 700;\">principios y valores cooperativos</span>, el rol del&nbsp;<span data-start=\"633\" data-end=\"652\" style=\"font-weight: 700;\">liderazgo ético</span>, la importancia de una&nbsp;<span data-start=\"676\" data-end=\"701\" style=\"font-weight: 700;\">comunicación efectiva</span>, y la necesidad de actuar con&nbsp;<span data-start=\"732\" data-end=\"776\" style=\"font-weight: 700;\">diligencia, honestidad y responsabilidad</span>&nbsp;en nuestras funciones diarias.</p><p data-start=\"809\" data-end=\"1214\">También analizaremos el tratamiento de los&nbsp;<span data-start=\"852\" data-end=\"877\" style=\"font-weight: 700;\">conflictos de interés</span>, los&nbsp;<span data-start=\"883\" data-end=\"904\" style=\"font-weight: 700;\">actos censurables</span>&nbsp;y el&nbsp;<span data-start=\"910\" data-end=\"933\" style=\"font-weight: 700;\">régimen sancionador</span>&nbsp;aplicable en la Cooperativa, conforme al marco normativo interno y externo vigente. Se enfatizará la relevancia de la&nbsp;<span data-start=\"1052\" data-end=\"1086\" style=\"font-weight: 700;\">ética, la prudencia financiera</span>&nbsp;y el&nbsp;<span data-start=\"1092\" data-end=\"1123\" style=\"font-weight: 700;\">compromiso con la comunidad</span>&nbsp;como pilares fundamentales para fortalecer el clima organizacional y el servicio al socio.</p><p data-start=\"1322\" data-end=\"1538\"><span data-start=\"1322\" data-end=\"1337\" style=\"font-weight: 700;\">IMPORTANTE:</span><br data-start=\"1337\" data-end=\"1340\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1474\" data-end=\"1477\"><br></p><p data-start=\"1540\" data-end=\"1556\"><span data-start=\"1540\" data-end=\"1556\" style=\"font-weight: 700;\">¡Comencemos!</span></p>', 'Cultural_Organizacional_y_Relaciones_Humanas.pdf', 4),
(130, '', '2025-07-16', 'Introducción a la Economía Popular y Solidaria', 'Responsable de Educación', '<p data-start=\"318\" data-end=\"356\"><strong data-start=\"318\" data-end=\"356\">¡Bienvenidos queridos Estudiantes!</strong></p>\r\n<p data-start=\"358\" data-end=\"606\">En este curso introductorio aprenderemos qué es la <strong data-start=\"409\" data-end=\"447\">Economía Popular y Solidaria (EPS)</strong>, su importancia como modelo alternativo al sistema capitalista tradicional y su rol en la transformación de las relaciones sociales, económicas y financieras.</p>\r\n<p data-start=\"608\" data-end=\"1015\">Exploraremos los <strong data-start=\"625\" data-end=\"653\">principios fundamentales</strong> de la EPS, como la solidaridad, la equidad, la autogestión y la responsabilidad social. Además, conoceremos la <strong data-start=\"765\" data-end=\"792\">estructura organizativa</strong> del sector, las diferencias clave con la empresa privada, y el marco normativo que regula a las cooperativas, asociaciones y otras entidades dentro del ámbito de la <strong data-start=\"958\" data-end=\"1014\">Ley Orgánica de Economía Popular y Solidaria (LOEPS)</strong>.</p>\r\n<p data-start=\"1017\" data-end=\"1313\">También profundizaremos en los derechos y obligaciones de los socios y asociados, el proceso de pérdida de calidad de miembro, y el régimen de liquidación de haberes. Este módulo es esencial para fortalecer la participación consciente y activa de todos los miembros de una organización solidaria.</p>\r\n<p data-start=\"1315\" data-end=\"1419\"><br></p>\r\n<p data-start=\"1421\" data-end=\"1637\"><strong data-start=\"1421\" data-end=\"1436\">IMPORTANTE:</strong><br data-start=\"1436\" data-end=\"1439\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1573\" data-end=\"1576\"><br></p>\r\n<p data-start=\"1639\" data-end=\"1655\"><strong data-start=\"1639\" data-end=\"1655\">¡Comencemos!</strong></p>', 'Introducción_a_la_Economía_Popular_y_Solidaria.pdf', 4),
(131, '', '2025-07-16', 'Educación Financiera para Socios', 'Responsable de Educación', '<p data-start=\"329\" data-end=\"367\"><strong data-start=\"329\" data-end=\"367\">¡Bienvenidos queridos estudiantes!</strong></p>\r\n<p data-start=\"369\" data-end=\"581\">En este módulo aprenderemos los fundamentos clave de la <strong data-start=\"425\" data-end=\"449\">educación financiera</strong>, una herramienta esencial para la toma de decisiones responsables en la vida personal y dentro de nuestra organización cooperativa.</p>\r\n<p data-start=\"583\" data-end=\"998\">Analizaremos la importancia de la <strong data-start=\"617\" data-end=\"645\">planificación financiera</strong>, aprenderemos a construir un <strong data-start=\"675\" data-end=\"710\">presupuesto personal y familiar</strong>, identificaremos cómo desarrollar un <strong data-start=\"748\" data-end=\"775\">plan de ahorro efectivo</strong>, y conoceremos los principios del <strong data-start=\"810\" data-end=\"839\">endeudamiento responsable</strong>. Además, se abordarán temas como el manejo de los <strong data-start=\"890\" data-end=\"908\">gastos hormiga</strong>, la diferencia entre <strong data-start=\"930\" data-end=\"952\">ahorrar e invertir</strong>, y los riesgos y beneficios de cada práctica.</p>\r\n<p data-start=\"1000\" data-end=\"1159\">Este conocimiento permite a los socios gestionar mejor sus recursos y contribuir al bienestar colectivo, promoviendo prácticas financieras sanas y sostenibles.</p>\r\n<p data-start=\"1267\" data-end=\"1483\"><strong data-start=\"1267\" data-end=\"1282\">IMPORTANTE:</strong></p><p data-start=\"1267\" data-end=\"1483\">Los certificados se generarán automáticamente al completar el curso, aprobar la evaluación y responder la encuesta de satisfacción.<br data-start=\"1419\" data-end=\"1422\"><br></p>\r\n<p data-start=\"1485\" data-end=\"1501\"><strong data-start=\"1485\" data-end=\"1501\">¡Comencemos!</strong></p>', 'Educación_Financiera_para_Socios.pdf', 4),
(132, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/yrP9vgLsalA\" title=\"Planificación Financiera  20201008 1340 1\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-17', 'Elaboración y Evaluación Periódica de Planes Operativos, Financieros y Presupuestos', 'Responsable de Educación', '<p data-start=\"177\" data-end=\"272\"><strong data-start=\"274\" data-end=\"312\">¡Bienvenidos estimados Directivos!</strong></p>\r\n<p data-start=\"314\" data-end=\"622\">Este módulo ha sido diseñado especialmente para fortalecer sus competencias en la <strong data-start=\"396\" data-end=\"432\">gestión estratégica y financiera</strong> de la cooperativa, mediante una correcta aplicación de la <strong data-start=\"491\" data-end=\"516\">planeación financiera</strong>, la estructuración del <strong data-start=\"540\" data-end=\"570\">Plan Operativo Anual (POA)</strong> y la elaboración del <strong data-start=\"592\" data-end=\"621\">presupuesto institucional</strong>.</p>\r\n<p data-start=\"624\" data-end=\"681\">Durante la clase abordaremos herramientas prácticas para:</p>\r\n<ul data-start=\"682\" data-end=\"1064\">\r\n<li data-start=\"682\" data-end=\"751\">\r\n<p data-start=\"684\" data-end=\"751\">Formular objetivos estratégicos alineados con el plan institucional</p>\r\n</li>\r\n<li data-start=\"752\" data-end=\"828\">\r\n<p data-start=\"754\" data-end=\"828\">Definir actividades, metas, responsables, recursos y cronogramas en el POA</p>\r\n</li>\r\n<li data-start=\"829\" data-end=\"887\">\r\n<p data-start=\"831\" data-end=\"887\">Elaborar y validar presupuestos operativos y financieros</p>\r\n</li>\r\n<li data-start=\"888\" data-end=\"976\">\r\n<p data-start=\"890\" data-end=\"976\">Analizar proyecciones de ingresos y egresos, flujos de caja y márgenes de rentabilidad</p>\r\n</li>\r\n<li data-start=\"977\" data-end=\"1064\">\r\n<p data-start=\"979\" data-end=\"1064\">Evaluar la <strong data-start=\"990\" data-end=\"1015\">viabilidad financiera</strong> de proyectos como la apertura de nuevas agencias</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"1066\" data-end=\"1265\">Además, se revisarán los <strong data-start=\"1091\" data-end=\"1132\">lineamientos establecidos por la SEPS</strong> en cuanto a planificación, ejecución, monitoreo y control presupuestario, incluyendo el uso de indicadores financieros y de gestión.</p>\r\n<p data-start=\"1267\" data-end=\"1435\">Este conocimiento es clave para que el cuerpo directivo tome decisiones informadas, proactivas y sostenibles en beneficio de los socios y del crecimiento institucional.</p>\r\n<p data-start=\"1437\" data-end=\"1652\"><strong data-start=\"1440\" data-end=\"1454\">IMPORTANTE</strong>:<br data-start=\"1553\" data-end=\"1556\">El certificado se generará al aprobar la evaluación y completar la encuesta de satisfacción.</p>\r\n<p data-start=\"1654\" data-end=\"1723\"><strong data-start=\"1654\" data-end=\"1723\">¡Iniciemos este proceso de fortalecimiento técnico y estratégico!</strong></p>', 'Presentación-Planeacion_Financiera-Directivos.pdf', 4);
INSERT INTO `clase` (`id`, `Video`, `Fecha`, `Titulo`, `Tutor`, `Descripcion`, `Adjuntos`, `estado_clase`) VALUES
(133, '<iframe width=\"853\" height=\"480\" src=\"https://www.youtube.com/embed/ELNGqKnss3k\" title=\"PLANIFICACIÓN FINANCIERA, APLICADA A COAC SEG 4 y 5\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2025-07-17', 'Planificación financiera, aplicada a cooperativas de ahorro y crédito de los segmentos 4 y 5', 'Responsable de Educación', '<p data-start=\"380\" data-end=\"605\"><strong data-start=\"380\" data-end=\"418\">¡Bienvenidos estimados directivos!</strong><br data-start=\"418\" data-end=\"421\">\r\nEn este módulo, profundizaremos en el proceso de <strong data-start=\"470\" data-end=\"519\">planeación financiera estratégica y operativa</strong>, con un enfoque práctico para los segmentos 4 y 5 del sector cooperativo ecuatoriano.</p>\r\n<p data-start=\"607\" data-end=\"643\">Durante la capacitación abordaremos:</p>\r\n<ul data-start=\"644\" data-end=\"1232\">\r\n<li data-start=\"644\" data-end=\"743\">\r\n<p data-start=\"646\" data-end=\"743\">La metodología para convertir la planificación estratégica en proyecciones financieras concretas.</p>\r\n</li>\r\n<li data-start=\"744\" data-end=\"826\">\r\n<p data-start=\"746\" data-end=\"826\">El diseño del presupuesto institucional a partir de metas comerciales realistas.</p>\r\n</li>\r\n<li data-start=\"827\" data-end=\"895\">\r\n<p data-start=\"829\" data-end=\"895\">El análisis macroeconómico y sectorial para la toma de decisiones.</p>\r\n</li>\r\n<li data-start=\"896\" data-end=\"977\">\r\n<p data-start=\"898\" data-end=\"977\">El diagnóstico financiero integral: estructura, tendencias e indicadores clave.</p>\r\n</li>\r\n<li data-start=\"978\" data-end=\"1081\">\r\n<p data-start=\"980\" data-end=\"1081\">La elaboración de proyecciones financieras con base en variables ajustadas al contexto institucional.</p>\r\n</li>\r\n<li data-start=\"1082\" data-end=\"1153\">\r\n<p data-start=\"1084\" data-end=\"1153\">La importancia del flujo de caja, los gastos operativos y de capital.</p>\r\n</li>\r\n<li data-start=\"1154\" data-end=\"1232\">\r\n<p data-start=\"1156\" data-end=\"1232\">Herramientas para realizar seguimiento, control y evaluación presupuestaria.</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"1234\" data-end=\"1440\"><strong data-start=\"1234\" data-end=\"1350\">Este curso permitirá a los directivos tomar decisiones fundamentadas en datos y proyecciones financieras sólidas</strong>, garantizando sostenibilidad, eficiencia operativa y cumplimiento normativo ante la SEPS.</p>\r\n<p><hr data-start=\"1442\" data-end=\"1445\"></p>\r\n<p data-start=\"1447\" data-end=\"1710\"><strong data-start=\"1447\" data-end=\"1462\">IMPORTANTE:</strong><br data-start=\"1576\" data-end=\"1579\">El certificado se generará automáticamente al finalizar el curso, aprobar la evaluación y completar la encuesta de satisfacción.</p>', 'Planificación_Financiera-Segmento_4_y_5.pdf', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase_alumno`
--

CREATE TABLE `clase_alumno` (
  `id_clase_alumno` int(11) NOT NULL,
  `id_curso_clase` int(11) NOT NULL,
  `id_curso_alumno` int(11) NOT NULL,
  `estado_video` int(11) NOT NULL,
  `estado_evaluacion` int(11) NOT NULL,
  `estado_encuesta` int(11) NOT NULL,
  `estado_clase` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `idc` int(17) NOT NULL,
  `id` int(7) NOT NULL,
  `Fecha` datetime NOT NULL,
  `Comentario` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Adjunto` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Tipo` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Codigo` varchar(70) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`idc`, `id`, `Fecha`, `Comentario`, `Adjunto`, `Tipo`, `Codigo`) VALUES
(22, 111, '2025-07-02 16:22:04', 'Para ampliar y reforzar los conocimientos adquiridos en esta clase, te invitamos a ver el siguiente video:\r\n \"Gestión de Riesgo Operativo 2024\". ->\r\nLink del video: https://youtu.be/GovqK1H0lzc?siz3dv5fkRYIVm8hsg .\r\nEste recurso audiovisual te permitirá visualizar conceptos clave y ejemplos prácticos que complementan el contenido teórico del módulo.', '', 'Administrador', 'AC59858823'),
(23, 118, '2025-07-04 13:31:38', 'Se adjunta la presentación de la clase: Gobernanza y Transparencia en la Cooperativa', 'Gobernanza y Transparencia Cooperativa.pdf', 'Administrador', 'AC59858823');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correos_enviados`
--

CREATE TABLE `correos_enviados` (
  `id` int(11) NOT NULL,
  `usuario_id` varchar(20) NOT NULL,
  `destinatarios` longtext NOT NULL,
  `asunto` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `contenido` longtext NOT NULL,
  `archivos_adjuntos` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `fecha_envio` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuenta`
--

CREATE TABLE `cuenta` (
  `id` int(7) NOT NULL,
  `Privilegio` int(1) NOT NULL,
  `Usuario` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Clave` varchar(535) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Tipo` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Genero` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Codigo` varchar(70) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish2_ci;

--
-- Volcado de datos para la tabla `cuenta`
--

INSERT INTO `cuenta` (`id`, `Privilegio`, `Usuario`, `Clave`, `Tipo`, `Genero`, `Codigo`) VALUES
(1, 1, 'Admin1998', 'ZFZaSzVtbGlvYlNVVEtPc2tEQy91Zz09', 'Administrador', 'Masculino', 'AC87720821'),
(31, 4, 'Manolo1998', 'aTd4SFE1dlIrN2NiYmJIODladnNTUT09', 'Estudiante', 'Masculino', 'EC19550714'),
(35, 1, 'admin', 'cDM1Z3V6a1FLTUd4M2xMZklYT3FWZz09', 'Administrador', 'Masculino', 'AC34869806');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `id_curso` varchar(10) NOT NULL,
  `Titulo` text NOT NULL,
  `Portada` text NOT NULL,
  `Fecha` date NOT NULL,
  `Estado` int(11) NOT NULL,
  `Norma` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`id_curso`, `Titulo`, `Portada`, `Fecha`, `Estado`, `Norma`) VALUES
('CCF0977733', 'Eventos de Capacitación Interna en Temas de Interés Local o Comunitario', 'png-transparent-community-service-volunteering-local-community-society-family-service-orange-people-thumbnail.png', '2025-07-02', 4, 1),
('CCF1688056', 'Educación en Temas de Interés Local o Comunitario', 'png-clipart-computer-icons-community-uk-miscellaneous-community-development-thumbnail.png', '2025-07-02', 4, 1),
('CCF5591795', '3 CURSO SEGURO DE SEGUROS PRIVADOS', '3_CURSO_SEGURO_DE_SEGUROS_PRIVADOS.png', '2025-07-07', 4, 10),
('CCF5681175', '1 CURSO SEGURO DE DEPÓSITOS', '1_CURSO_SEGURO_DE_DEPÓSITOS.png', '2025-07-02', 4, 10),
('CCF6786886', 'Principios y Valores', 'principios_y_v_alores.jpg', '2025-07-02', 4, 1),
('CCF7507811', 'Formación de Futuros Representantes', 'reunion-rompecabezas-colores.jpg', '2025-07-02', 4, 1),
('CCF8203634', 'Gestión de Riesgo Operativo', 'riesgosoperativos1.jpg', '2025-07-02', 4, 2),
('CCF8291297', '4 CURSO COSEDE TERRITORIAL', '4_CURSO_COSEDE_TERRITORIAL.png', '2025-07-08', 4, 10),
('CCF8370835', 'Educación Financiera para la Economía Popular y Solidaria', 'Captura.JPG', '2025-07-02', 4, 1),
('CCF8643412', '2 CURSO FONDO DEL SEGURO DE DEPOSITOS', '2_CURSO_FONDO_DEL_SEGURO_DE_DEPOSITOS.png', '2025-07-07', 4, 10),
('CCF9190685', 'Economía Popular y Solidaria (EPS)', 'EPS.png', '2025-07-02', 4, 1),
('CCF9271000', 'Curso de Educación Financiera', '¿Que-es-la-educacion-financiera.jpg', '2025-07-02', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso_alumno`
--

CREATE TABLE `curso_alumno` (
  `id_curso_alumno` int(11) NOT NULL,
  `id_curso` varchar(11) NOT NULL,
  `id_alumno` varchar(70) NOT NULL,
  `estado_curso` int(11) NOT NULL,
  `fecha_termino` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso_clase`
--

CREATE TABLE `curso_clase` (
  `id_curso_clase` int(11) NOT NULL,
  `id_curso` text NOT NULL,
  `id_clase` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `horas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `curso_clase`
--

INSERT INTO `curso_clase` (`id_curso_clase`, `id_curso`, `id_clase`, `orden`, `horas`) VALUES
(2009, 'CCF5681175', 109, 1, 8),
(2010, 'CCF8203634', 110, 1, 2),
(2011, 'CCF8203634', 111, 2, 2),
(2012, 'CCF9190685', 112, 1, 2),
(2013, 'CCF9190685', 113, 2, 2),
(2014, 'CCF9190685', 114, 3, 2),
(2015, 'CCF9190685', 115, 4, 2),
(2016, 'CCF9190685', 116, 5, 2),
(2017, 'CCF9190685', 117, 6, 2),
(2018, 'CCF6786886', 118, 7, 2),
(2019, 'CCF9190685', 119, 7, 2),
(2020, 'CCF6786886', 120, 2, 2),
(2021, 'CCF7507811', 121, 1, 2),
(2022, 'CCF8643412', 122, 1, 8),
(2023, 'CCF5591795', 123, 1, 8),
(2024, 'CCF8291297', 124, 1, 8),
(2025, 'CCF7507811', 125, 2, 2),
(2026, 'CCF7507811', 126, 3, 2),
(2027, 'CCF7507811', 127, 4, 2),
(2028, 'CCF7507811', 128, 5, 2),
(2029, 'CCF6786886', 129, 3, 2),
(2030, 'CCF8370835', 130, 1, 2),
(2031, 'CCF8370835', 131, 2, 2),
(2032, 'CCF8370835', 132, 3, 8),
(2033, 'CCF8370835', 133, 4, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta_rapida`
--

CREATE TABLE `encuesta_rapida` (
  `id_pregunta` int(11) NOT NULL,
  `id_clase` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `tipo` enum('multiple','verdadero_falso','completar') NOT NULL,
  `opcion1` text DEFAULT NULL,
  `opcion2` text DEFAULT NULL,
  `opcion3` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `encuesta_rapida`
--

INSERT INTO `encuesta_rapida` (`id_pregunta`, `id_clase`, `pregunta`, `tipo`, `opcion1`, `opcion2`, `opcion3`) VALUES
(419, 109, '¿Cómo calificarías tu experiencia general con el curso?', 'multiple', 'Excelente', 'Buena', 'Regular'),
(420, 109, '¿El contenido del curso fue claro y fácil de entender?', 'multiple', 'Sí', 'No', 'En parte'),
(421, 109, '¿Consideras que el curso te ayudó a comprender mejor el funcionamiento del seguro de depósitos?', 'multiple', 'Mucho', 'Algo', 'Nada'),
(422, 109, '¿La duración del curso fue adecuada?', 'verdadero_falso', 'Sí', 'No', ''),
(423, 109, '¿Recomendarías este curso a otras personas?', 'verdadero_falso', 'Sí', 'No', ''),
(424, 109, '¿Qué aspecto del curso te pareció más útil?', 'multiple', 'Contenido práctico', 'Videos explicativos', 'Ejercicios evaluativos'),
(425, 109, '¿Hubo algún momento en el que sentiste que faltaba información relevante?', 'verdadero_falso', 'Sí', 'No', ''),
(426, 109, '¿Cómo te enteraste del curso?', 'multiple', 'Página web de COSEDE', 'Redes sociales', 'Recomendación personal'),
(427, 109, '¿Estás satisfecho con el soporte brindado durante el curso?', 'multiple', 'Sí', 'No', 'En algunas ocasiones'),
(428, 109, '¿Te gustaría recibir más cursos o capacitaciones por parte de COSEDE?', 'verdadero_falso', 'Sí', 'No', ''),
(432, 111, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(433, 111, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(434, 111, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(435, 111, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(436, 111, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(437, 111, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(438, 111, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(439, 111, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(440, 111, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(441, 111, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(442, 112, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(443, 112, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(444, 112, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(445, 112, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(446, 112, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(447, 112, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(448, 112, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(449, 112, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(450, 112, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(451, 112, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(452, 113, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(453, 113, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(454, 113, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(455, 113, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(456, 113, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(457, 113, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(458, 113, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(459, 113, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(460, 113, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(461, 113, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(462, 114, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(463, 114, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(464, 114, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(465, 114, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(466, 114, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(467, 114, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(468, 114, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(469, 114, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(470, 114, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(471, 114, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(472, 115, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(473, 115, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(474, 115, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(475, 115, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(476, 115, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(477, 115, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(478, 115, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(479, 115, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(480, 115, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(481, 115, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(482, 116, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(483, 116, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(484, 116, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(485, 116, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(486, 116, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(487, 116, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(488, 116, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(489, 116, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(490, 116, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(491, 116, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(492, 117, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(493, 117, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(494, 117, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(495, 117, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(496, 117, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(497, 117, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(498, 117, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(499, 117, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(500, 117, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(501, 117, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(502, 118, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(503, 118, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(504, 118, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(505, 118, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(506, 118, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(507, 118, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(508, 118, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(509, 118, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(510, 118, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(511, 118, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(512, 120, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(513, 120, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(514, 120, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(515, 120, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(516, 120, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(517, 120, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(518, 120, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(519, 120, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(520, 120, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(521, 120, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(522, 121, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(523, 121, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(524, 121, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(525, 121, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(526, 121, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(527, 121, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(528, 121, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(529, 121, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(530, 121, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(531, 121, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(532, 122, '¿Cómo calificaría la calidad del contenido del curso?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(533, 122, 'El curso cumplió con mis expectativas.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(534, 122, 'Complete: Me pareció ______ la duración del curso.', 'completar', 'adecuada', 'muy larga', 'insuficiente'),
(535, 122, '¿Qué tan claros fueron los facilitadores al explicar el tema?', 'multiple', 'Muy claros', 'Poco claros', 'Nada claros'),
(536, 122, 'Recomendaría este curso a otros compañeros.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(537, 122, 'Complete: Considero que el curso fue ______ para mi trabajo diario.', 'completar', 'útil', 'irrelevante', 'complementario'),
(538, 122, '¿Qué aspecto mejoraría del curso?', 'multiple', 'Duración', 'Materiales', 'Plataforma usada'),
(539, 122, 'La plataforma utilizada fue fácil de manejar.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(540, 122, 'Complete: Me gustaría que en futuros cursos se incluya ______.', 'completar', 'más ejercicios prácticos', 'menos teoría', 'foros de discusión'),
(541, 122, '¿Cómo califica su nivel de satisfacción general con el curso?', 'multiple', 'Alto', 'Medio', 'Bajo'),
(542, 123, '¿Qué tan claro te pareció el contenido del curso?', 'multiple', 'Muy claro', 'Poco claro', 'Nada claro'),
(543, 123, 'El curso cumplió con tus expectativas.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(544, 123, 'Complete: El tiempo destinado al curso me pareció ______.', 'completar', 'adecuado', 'muy corto', 'excesivo'),
(545, 123, '¿Cómo calificarías la experiencia general del curso?', 'multiple', 'Excelente', 'Buena', 'Regular'),
(546, 123, 'El instructor demostró dominio sobre el tema del curso.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(547, 123, 'Complete: Lo que más me gustó del curso fue ______.', 'completar', 'la claridad de los temas', 'la interacción con el instructor', 'el material entregado'),
(548, 123, '¿Cuál fue el aspecto más útil del curso para ti?', 'multiple', 'Conocer sobre pólizas', 'Saber sobre derechos del asegurado', 'Normativa de seguros'),
(549, 123, 'El material didáctico proporcionado fue adecuado.', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(550, 123, 'Complete: Me gustaría que en futuras capacitaciones se incluya ______.', 'completar', 'estudios de casos reales', 'sesiones prácticas', 'ejercicios interactivos'),
(551, 123, '¿Cómo evalúas la utilidad del curso para tu trabajo o vida personal?', 'multiple', 'Muy útil', 'Poco útil', 'Nada útil'),
(552, 124, '¿Con qué nivel de claridad considera que fue explicado el funcionamiento del Seguro de Depósitos?', 'multiple', 'Muy claro', 'Poco claro', 'Nada claro'),
(553, 124, '¿Qué tan satisfecho está con la información recibida sobre la cobertura del COSEDE?', 'multiple', 'Satisfecho', 'Neutral', 'Insatisfecho'),
(554, 124, '¿Considera que el Seguro de Depósitos fortalece su confianza en la cooperativa?', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(555, 124, '¿La información brindada sobre el COSEDE respondió a sus dudas?', 'multiple', 'Sí  totalmente', 'Parcialmente', 'No'),
(556, 124, '¿Conocía usted del Seguro de Depósitos antes de esta capacitación?', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(557, 124, '¿Qué tan accesible le pareció el lenguaje utilizado para explicar el COSEDE?', 'multiple', 'Muy accesible', 'Regular', 'Difícil de entender'),
(558, 124, 'El contenido sobre el Seguro de Depósitos fue:', 'multiple', 'Relevante', 'Poco relevante', 'Irrelevante'),
(559, 124, '¿Cómo califica el tiempo destinado a explicar el tema del Seguro de Depósitos?', 'multiple', 'Adecuado', 'Corto', 'Largo'),
(560, 124, '¿Cree que esta información debería compartirse con más socios?', 'verdadero_falso', 'VERDADERO', 'FALSO', ''),
(561, 124, '¿Qué sugerencias tiene para mejorar la socialización del tema?', 'completar', '', '', ''),
(562, 125, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(563, 125, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(564, 125, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(565, 125, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(566, 125, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(567, 125, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(568, 125, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(569, 125, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(570, 125, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(571, 125, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(572, 126, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(573, 126, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(574, 126, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(575, 126, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(576, 126, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(577, 126, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(578, 126, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(579, 126, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(580, 126, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(581, 126, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(582, 127, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(583, 127, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(584, 127, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(585, 127, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(586, 127, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(587, 127, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(588, 127, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(589, 127, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(590, 127, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(591, 127, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(592, 128, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(593, 128, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(594, 128, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(595, 128, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(596, 128, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(597, 128, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(598, 128, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(599, 128, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(600, 128, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(601, 128, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(602, 129, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(603, 129, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(604, 129, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(605, 129, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(606, 129, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(607, 129, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(608, 129, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(609, 129, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(610, 129, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(611, 129, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(612, 130, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(613, 130, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(614, 130, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(615, 130, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(616, 130, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(617, 130, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(618, 130, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(619, 130, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(620, 130, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(621, 130, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(622, 131, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(623, 131, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(624, 131, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(625, 131, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(626, 131, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(627, 131, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(628, 131, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(629, 131, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(630, 131, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(631, 131, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(632, 132, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(633, 132, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(634, 132, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(635, 132, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(636, 132, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(637, 132, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(638, 132, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(639, 132, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(640, 132, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(641, 132, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', ''),
(642, 133, 'En general  estoy satisfecho/a con el módulo recibido.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(643, 133, 'La información del módulo fue clara y comprensible.', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(644, 133, '¿La duración del módulo fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(645, 133, 'Los contenidos tratados en este evento  son útiles para su organización o para el desarrollo de su trabajo', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(646, 133, '¿La presentación del material (diapositivas  recursos) fue adecuada?', 'multiple', 'Excelente', 'Bueno', 'Regular'),
(647, 133, '¿La herramienta de capacitación virtual fue fácil de usar?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(648, 133, '¿Durante la capacitación presentó problemas en la plataforma?', 'multiple', 'Sí', 'Parcialmente', 'No'),
(649, 133, '¿Recomendaría este módulo a otros colaboradores?', 'multiple', 'Sí', 'Tal vez', 'No'),
(650, 133, '¿Sobre qué temas usted considera que requiere ser capacitado?', 'completar', '', '', ''),
(651, 133, '¿Qué recomendaciones daría usted a los organizadores?', 'completar', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta_respuesta`
--

CREATE TABLE `encuesta_respuesta` (
  `id_respuesta` int(11) NOT NULL,
  `id_usuario` varchar(70) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `respuesta_usuario` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta_usuario`
--

CREATE TABLE `encuesta_usuario` (
  `id_notas` int(11) NOT NULL,
  `id_usuario` varchar(70) DEFAULT NULL,
  `id_clase` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha_respuesta` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_curso`
--

CREATE TABLE `estado_curso` (
  `id_estado` int(11) NOT NULL,
  `estado` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `estado_curso`
--

INSERT INTO `estado_curso` (`id_estado`, `estado`) VALUES
(1, 'Completo'),
(2, 'En Proceso'),
(3, 'Sin Iniciar'),
(4, 'Activo'),
(5, 'Inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE `estudiante` (
  `Codigo` varchar(70) NOT NULL,
  `Nombres` varchar(70) NOT NULL,
  `Apellidos` varchar(70) NOT NULL,
  `Email` varchar(70) NOT NULL,
  `Cedula` varchar(10) NOT NULL,
  `Telefono` varchar(10) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `Nivel` varchar(255) NOT NULL,
  `Provincia` int(255) NOT NULL,
  `Canton` int(11) NOT NULL,
  `Parroquia` int(11) NOT NULL,
  `Actividad` varchar(255) NOT NULL,
  `Etnia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`Codigo`, `Nombres`, `Apellidos`, `Email`, `Cedula`, `Telefono`, `Tipo`, `Nivel`, `Provincia`, `Canton`, `Parroquia`, `Actividad`, `Etnia`) VALUES
('EC19550714', 'Manuel Ignacio', 'Macías Sánchez', 'manuelmacias698@gmail.com', '0955886288', '0983957796', 3, 'TercerNivel', 9, 74, 462, 'Tecnología e Informática', 'Mestizo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos`
--

CREATE TABLE `juegos` (
  `id` varchar(11) NOT NULL,
  `tipo` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `archivo_csv` varchar(55) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha_creacion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juego_alumno`
--

CREATE TABLE `juego_alumno` (
  `id_juego_alumno` int(11) NOT NULL,
  `id_alumno` varchar(55) NOT NULL,
  `id_juego` varchar(55) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juego_clase`
--

CREATE TABLE `juego_clase` (
  `id_clase_juego` int(11) NOT NULL,
  `id_clase` int(11) NOT NULL,
  `id_juego` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas_usuario`
--

CREATE TABLE `notas_usuario` (
  `id_notas` int(11) NOT NULL,
  `id_usuario` varchar(70) DEFAULT NULL,
  `id_clase` int(11) DEFAULT NULL,
  `nota` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha_respuesta` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `palabras`
--

CREATE TABLE `palabras` (
  `id` int(11) NOT NULL,
  `juego_id` varchar(11) NOT NULL,
  `palabra` varchar(100) NOT NULL,
  `pista` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parroquias`
--

CREATE TABLE `parroquias` (
  `id_parroquia` int(11) NOT NULL,
  `cod_parroquia` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `id_canton` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `parroquias`
--

INSERT INTO `parroquias` (`id_parroquia`, `cod_parroquia`, `nombre`, `id_canton`) VALUES
(1, 1, 'BELLAVISTA', 1),
(2, 2, 'CAÑARIBAMBA', 1),
(3, 3, 'EL BATÁN', 1),
(4, 4, 'EL SAGRARIO', 1),
(5, 5, 'EL VECINO', 1),
(6, 6, 'GIL RAMÍREZ DÁVALOS', 1),
(7, 7, 'HUAYNACÁPAC', 1),
(8, 8, 'MACHÁNGARA', 1),
(9, 9, 'MONAY', 1),
(10, 10, 'SAN BLAS', 1),
(11, 11, 'SAN SEBASTIÁN', 1),
(12, 12, 'SUCRE', 1),
(13, 13, 'TOTORACOCHA', 1),
(14, 14, 'YANUNCAY', 1),
(15, 15, 'HERMANO MIGUEL', 1),
(16, 51, 'BAÑOS', 1),
(17, 52, 'CUMBE', 1),
(18, 53, 'CHAUCHA', 1),
(19, 54, 'CHECA (JIDCAY)', 1),
(20, 55, 'CHIQUINTAD', 1),
(21, 56, 'LLACAO', 1),
(22, 57, 'MOLLETURO', 1),
(23, 58, 'NULTI', 1),
(24, 59, 'OCTAVIO CORDERO PALACIOS (STA. ROSA)', 1),
(25, 60, 'PACCHA', 1),
(26, 61, 'QUINGEO', 1),
(27, 62, 'RICAURTE', 1),
(28, 63, 'SAN JOAQUIN', 1),
(29, 64, 'SANTA ANA', 1),
(30, 65, 'SAYAUSI', 1),
(31, 66, 'SIDCAY', 1),
(32, 67, 'SININCAY', 1),
(33, 68, 'TARQUI', 1),
(34, 69, 'TURI', 1),
(35, 70, 'VALLE', 1),
(36, 71, 'VICTORIA DEL PORTETE (IRQUIS)', 1),
(37, 50, 'GIRON', 2),
(38, 51, 'LA ASUNCION', 2),
(39, 52, 'SAN GERARDO', 2),
(40, 50, 'GUALACEO', 3),
(41, 52, 'DANIEL CORDOVA TORAL (EL ORIENTE)', 3),
(42, 53, 'JADAN', 3),
(43, 54, 'MARIANO MORENO', 3),
(44, 56, 'REMIGIO CRESPO TORAL (GULAG)', 3),
(45, 57, 'SAN JUAN', 3),
(46, 58, 'ZHIDMAD', 3),
(47, 59, 'LUIS CORDERO VEGA', 3),
(48, 60, 'SIMON BOLIVAR (CAB. EN GAÑANZOL)', 3),
(49, 50, 'NABON', 4),
(50, 51, 'COCHAPATA', 4),
(51, 52, 'EL PROGRESO (CAB. EN ZHOTA)', 4),
(52, 53, 'LAS NIEVES (CHAYA)', 4),
(53, 50, 'PAUTE', 5),
(54, 52, 'BULAN (JOSE VICTOR IZQUIERDO)', 5),
(55, 53, 'CHICAN (GUILLERMO ORTEGA)', 5),
(56, 54, 'EL CABO', 5),
(57, 56, 'GUARAINAG', 5),
(58, 59, 'SAN CRISTOBAL (CARLOS ORDOÑEZ LAZO)', 5),
(59, 61, 'TOMEBAMBA', 5),
(60, 62, 'DUG DUG', 5),
(61, 50, 'PUCARA', 6),
(62, 52, 'SAN RAFAEL DE SHARUG', 6),
(63, 50, 'SAN FERNANDO', 7),
(64, 51, 'CHUMBLIN', 7),
(65, 50, 'SANTA ISABEL (CHAGUARURCO)', 8),
(66, 51, 'ABDON CALDERON (LA UNION)', 8),
(67, 52, 'EL CARMEN DE PIJILI', 8),
(68, 53, 'ZHAGLLI (SHAGLLI )', 8),
(69, 54, 'SAN SALVADOR DE CAÑARIBAMBA', 8),
(70, 50, 'SIGSIG', 9),
(71, 51, 'CUCHIL', 9),
(72, 52, 'GIMA', 9),
(73, 53, 'GUEL', 9),
(74, 54, 'LUDO', 9),
(75, 55, 'SAN BARTOLOME', 9),
(76, 56, 'SAN JOSE DE RARANGA', 9),
(77, 50, 'SAN FELIPE DE OÑA', 10),
(78, 51, 'SUSUDEL', 10),
(79, 50, 'CHORDELEG', 11),
(80, 51, 'PRINCIPAL', 11),
(81, 52, 'LA UNION', 11),
(82, 53, 'LUIS GALARZA ORELLANA (CAB. EN DELEGSOL)', 11),
(83, 54, 'SAN MARTIN DE PUZHIO', 11),
(84, 50, 'EL PAN', 12),
(85, 53, 'SAN VICENTE', 12),
(86, 50, 'SEVILLA DE ORO', 13),
(87, 51, 'AMALUZA', 13),
(88, 52, 'PALMAS', 13),
(89, 50, 'GUACHAPALA', 14),
(90, 50, 'CAMILO PONCE ENRIQUEZ', 15),
(91, 1, 'ÁNGEL POLIBIO CHÁVES', 16),
(92, 2, 'GABRIEL IGNACIO VEINTIMILLA', 16),
(93, 3, 'GUANUJO', 16),
(94, 51, 'FACUNDO VELA', 16),
(95, 53, 'JULIO E. MORENO (CATANAHUAN GRANDE)', 16),
(96, 55, 'SALINAS', 16),
(97, 56, 'SAN LORENZO', 16),
(98, 57, 'SAN SIMON (YACOTO)', 16),
(99, 58, 'SANTA FE (SANTA FE)', 16),
(100, 59, 'SIMIATUG', 16),
(101, 60, 'SAN LUIS DE PAMBIL', 16),
(102, 50, 'CHILLANES', 17),
(103, 51, 'SAN JOSE DEL TAMBO (TAMBOPAMBA)', 17),
(104, 50, 'SAN JOSE DE CHIMBO', 18),
(105, 51, 'ASUNCION (ASANCOTO)', 18),
(106, 53, 'LA MAGDALENA (CHAPACOTO)', 18),
(107, 54, 'SAN SEBASTIAN', 18),
(108, 55, 'TELIMBELA', 18),
(109, 50, 'ECHEANDIA', 19),
(110, 50, 'SAN MIGUEL', 20),
(111, 51, 'BALSAPAMBA', 20),
(112, 52, 'BILOVAN', 20),
(113, 53, 'REGULO DE MORA', 20),
(114, 54, 'SAN PABLO (SAN PABLO DE ATENAS)', 20),
(115, 55, 'SANTIAGO', 20),
(116, 56, 'SAN VICENTE', 20),
(117, 50, 'CALUMA', 21),
(118, 1, 'LAS MERCEDES', 22),
(119, 2, 'LAS NAVES', 22),
(120, 1, 'AURELIO BAYAS MARTÍNEZ', 23),
(121, 2, 'AZOGUES', 23),
(122, 3, 'BORRERO', 23),
(123, 4, 'SAN FRANCISCO', 23),
(124, 51, 'COJITAMBO', 23),
(125, 53, 'GUAPAN', 23),
(126, 54, 'JAVIER LOYOLA (CHUQUIPATA)', 23),
(127, 55, 'LUIS CORDERO', 23),
(128, 56, 'PINDILIG', 23),
(129, 57, 'RIVERA', 23),
(130, 58, 'SAN MIGUEL', 23),
(131, 60, 'TADAY', 23),
(132, 50, 'BIBLIAN', 24),
(133, 51, 'NAZON (CAB. EN PAMPA DE DOMINGUEZ)', 24),
(134, 52, 'SAN FRANCISCO DE SAGEO', 24),
(135, 53, 'TURUPAMBA', 24),
(136, 54, 'JERUSALEN', 24),
(137, 50, 'CAÑAR', 25),
(138, 51, 'CHONTAMARCA', 25),
(139, 52, 'CHOROCOPTE', 25),
(140, 53, 'GENERAL MORALES (SOCARTE)', 25),
(141, 54, 'GUALLETURO', 25),
(142, 55, 'HONORATO VASQUEZ (TAMBO VIEJO)', 25),
(143, 56, 'INGAPIRCA', 25),
(144, 57, 'JUNCAL', 25),
(145, 58, 'SAN ANTONIO', 25),
(146, 61, 'ZHUD', 25),
(147, 62, 'VENTURA', 25),
(148, 63, 'DUCUR', 25),
(149, 50, 'LA TRONCAL', 26),
(150, 51, 'MANUEL J. CALLE', 26),
(151, 52, 'PANCHO NEGRO', 26),
(152, 50, 'EL TAMBO', 27),
(153, 50, 'DELEG', 28),
(154, 51, 'SOLANO', 28),
(155, 50, 'SUSCAL', 29),
(156, 1, 'GONZÁLEZ SUÁREZ', 30),
(157, 2, 'TULCÁN', 30),
(158, 51, 'EL CARMELO (EL PUN)', 30),
(159, 53, 'JULIO ANDRADE (OREJUELA)', 30),
(160, 54, 'MALDONADO', 30),
(161, 55, 'PIOTER', 30),
(162, 56, 'TOBAR DONOSO (LA BOCANA DE CAMUMBI)', 30),
(163, 57, 'TUFIÑO', 30),
(164, 58, 'URBINA (TAYA)', 30),
(165, 59, 'EL CHICAL', 30),
(166, 61, 'SANTA MARTHA DE CUBA', 30),
(167, 50, 'BOLIVAR', 31),
(168, 51, 'GARCIA MORENO', 31),
(169, 52, 'LOS ANDES', 31),
(170, 53, 'MONTE OLIVO', 31),
(171, 54, 'SAN VICENTE DE PUSIR', 31),
(172, 55, 'SAN RAFAEL', 31),
(173, 1, 'EL ÁNGEL', 32),
(174, 2, '27 DE SEPTIEMBRE', 32),
(175, 51, 'EL GOALTAL', 32),
(176, 52, 'LA LIBERTAD (ALIZO)', 32),
(177, 53, 'SAN ISIDRO', 32),
(178, 50, 'MIRA (CHONTAHUASI)', 33),
(179, 51, 'CONCEPCION', 33),
(180, 52, 'JIJON Y CAAMAÑO (CAB. EN RIO BLANCO)', 33),
(181, 53, 'JUAN MONTALVO (SAN IGNACIO DE quil', 33),
(182, 1, 'GONZÁLEZ SUÁREZ', 34),
(183, 2, 'SAN JOSÉ', 34),
(184, 51, 'CRISTOBAL COLON', 34),
(185, 52, 'CHITAN DE NAVARRETE', 34),
(186, 53, 'FERNANDEZ SALVADOR', 34),
(187, 54, 'LA PAZ', 34),
(188, 55, 'PIARTAL', 34),
(189, 50, 'HUACA', 35),
(190, 51, 'MARISCAL SUCRE', 35),
(191, 1, 'ELOY ALFARO (SAN FELIPE)', 36),
(192, 2, 'IGNACIO FLORES (PARQUE FLORES)', 36),
(193, 3, 'JUAN MONTALVO (SAN SEBASTIÁN)', 36),
(194, 4, 'LA MATRIZ', 36),
(195, 5, 'SAN BUENAVENTURA', 36),
(196, 51, 'ALAQUEZ (ALAQUES)', 36),
(197, 52, 'BELISARIO QUEVEDO (GUANAILIN)', 36),
(198, 53, 'GUAYTACAMA (GUAITACAMA)', 36),
(199, 54, 'JOSEGUANGO BAJO', 36),
(200, 56, 'MULALO', 36),
(201, 57, '11 DE NOVIEMBRE (ILINCHISI)', 36),
(202, 58, 'POALO', 36),
(203, 59, 'SAN JUAN DE PASTOCALLE', 36),
(204, 61, 'TANICUCHI', 36),
(205, 62, 'TOACASO', 36),
(206, 1, 'EL CARMEN', 37),
(207, 2, 'LA MANÁ', 37),
(208, 3, 'EL TRIUNFO', 37),
(209, 51, 'GUASAGANDA (CAB. EN GUASAGANDA CENTRO)', 37),
(210, 52, 'PUCAYACU', 37),
(211, 50, 'EL CORAZON', 38),
(212, 51, 'MORASPUNGO', 38),
(213, 52, 'PINLLOPATA', 38),
(214, 53, 'RAMON CAMPAÑA', 38),
(215, 50, 'PUJILI', 39),
(216, 51, 'ANGAMARCA', 39),
(217, 53, 'GUANGAJE', 39),
(218, 55, 'LA VICTORIA', 39),
(219, 56, 'PILALO', 39),
(220, 57, 'TINGO', 39),
(221, 58, 'ZUMBAHUA', 39),
(222, 50, 'SAN MIGUEL', 40),
(223, 51, 'ANTONIO JOSE HOLGUIN (SANTA LUCIA)', 40),
(224, 52, 'CUSUBAMBA', 40),
(225, 53, 'MULALILLO', 40),
(226, 54, 'MULLIQUINDIL (SANTA ANA)', 40),
(227, 55, 'PANSALEO', 40),
(228, 50, 'SAQUISILI', 41),
(229, 51, 'CANCHAGUA', 41),
(230, 52, 'CHANTILIN', 41),
(231, 53, 'COCHAPAMBA', 41),
(232, 50, 'SIGCHOS', 42),
(233, 51, 'CHUGCHILLAN', 42),
(234, 52, 'ISINLIVI', 42),
(235, 53, 'LAS PAMPAS', 42),
(236, 54, 'PALO QUEMADO', 42),
(237, 1, 'LIZARZABURU', 43),
(238, 2, 'MALDONADO', 43),
(239, 3, 'VELASCO', 43),
(240, 4, 'VELOZ', 43),
(241, 5, 'YARUQUÍES', 43),
(242, 51, 'CACHA (CAB. EN MACHANGARA)', 43),
(243, 52, 'CALPI', 43),
(244, 53, 'CUBIJIES', 43),
(245, 54, 'FLORES', 43),
(246, 55, 'LICAN', 43),
(247, 56, 'LICTO', 43),
(248, 57, 'PUNGALA', 43),
(249, 58, 'PUNIN', 43),
(250, 59, 'QUIMIAG', 43),
(251, 60, 'SAN JUAN', 43),
(252, 61, 'SAN LUIS', 43),
(253, 50, 'ALAUSI', 44),
(254, 51, 'ACHUPALLAS', 44),
(255, 53, 'GUASUNTOS', 44),
(256, 54, 'HUIGRA', 44),
(257, 55, 'MULTITUD', 44),
(258, 56, 'PISTISHI (NARIZ DEL DIABLO)', 44),
(259, 57, 'PUMALLACTA', 44),
(260, 58, 'SEVILLA', 44),
(261, 59, 'SIBAMBE', 44),
(262, 60, 'TIXAN', 44),
(263, 1, 'CAJABAMBA', 45),
(264, 2, 'SICALPA', 45),
(265, 51, 'CAÑI', 45),
(266, 52, 'COLUMBE', 45),
(267, 53, 'JUAN DE VELASCO (PANGOR)', 45),
(268, 54, 'SANTIAGO DE QUITO (CAB. EN SAN ANTONIO DE QUITO)', 45),
(269, 50, 'CHAMBO', 46),
(270, 50, 'CHUNCHI', 47),
(271, 51, 'CAPZOL', 47),
(272, 52, 'COMPUD', 47),
(273, 53, 'GONZOL', 47),
(274, 54, 'LLAGOS', 47),
(275, 50, 'GUAMOTE', 48),
(276, 51, 'CEBADAS', 48),
(277, 52, 'PALMIRA', 48),
(278, 1, 'EL ROSARIO', 49),
(279, 2, 'LA MATRIZ', 49),
(280, 51, 'GUANANDO', 49),
(281, 52, 'ILAPO', 49),
(282, 53, 'LA PROVIDENCIA', 49),
(283, 54, 'SAN ANDRES', 49),
(284, 55, 'SAN GERARDO DE PACAICAGUAN', 49),
(285, 56, 'SAN ISIDRO DE PATULU', 49),
(286, 57, 'SAN JOSE DEL CHAZO', 49),
(287, 58, 'SANTA FE DE GALAN', 49),
(288, 59, 'VALPARAISO', 49),
(289, 50, 'PALLATANGA', 50),
(290, 50, 'PENIPE', 51),
(291, 51, 'EL ALTAR', 51),
(292, 52, 'MATUS', 51),
(293, 53, 'PUELA', 51),
(294, 54, 'SAN ANTONIO DE BAYUSHIG', 51),
(295, 55, 'LA CANDELARIA', 51),
(296, 56, 'BILBAO (CAB. EN QUILLUYACU)', 51),
(297, 50, 'CUMANDA', 52),
(298, 1, 'LA PROVIDENCIA', 53),
(299, 2, 'MACHALA', 53),
(300, 3, 'PUERTO BOLÍVAR', 53),
(301, 4, 'NUEVE DE MAYO', 53),
(302, 5, 'EL CAMBIO', 53),
(303, 52, 'EL RETIRO', 53),
(304, 50, 'ARENILLAS', 54),
(305, 51, 'CHACRAS', 54),
(306, 54, 'PALMALES', 54),
(307, 55, 'CARCABON', 54),
(308, 56, 'LA CUCA', 54),
(309, 50, 'PACCHA', 55),
(310, 51, 'AYAPAMBA', 55),
(311, 52, 'CORDONCILLO', 55),
(312, 53, 'MILAGRO', 55),
(313, 54, 'SAN JOSE', 55),
(314, 55, 'SAN JUAN DE CERRO AZUL', 55),
(315, 50, 'BALSAS', 56),
(316, 51, 'BELLAMARIA', 56),
(317, 50, 'CHILLA', 57),
(318, 50, 'EL GUABO', 58),
(319, 51, 'BARBONES (SUCRE)', 58),
(320, 52, 'LA IBERIA', 58),
(321, 53, 'TENDALES (CAB. EN PUERTO TENDALES)', 58),
(322, 54, 'RIO BONITO', 58),
(323, 1, 'ECUADOR', 59),
(324, 2, 'EL PARAÍSO', 59),
(325, 3, 'HUALTACO', 59),
(326, 4, 'MILTON REYES', 59),
(327, 5, 'UNIÓN LOJANA', 59),
(328, 50, 'MARCABELI', 60),
(329, 51, 'EL INGENIO', 60),
(330, 1, 'BOLÍVAR', 61),
(331, 2, 'LOMA DE FRANCO', 61),
(332, 3, 'OCHOA LEÓN (MATRIZ)', 61),
(333, 4, 'TRES CERRITOS', 61),
(334, 51, 'BUENAVISTA', 61),
(335, 52, 'CASACAY', 61),
(336, 53, 'LA PEAÑA', 61),
(337, 54, 'PROGRESO', 61),
(338, 55, 'UZHCURRUMI', 61),
(339, 56, 'CAÑAQUEMADA', 61),
(340, 1, 'LA MATRIZ', 62),
(341, 2, 'LA SUSAYA', 62),
(342, 3, 'PIÑAS GRANDE', 62),
(343, 51, 'CAPIRO (CAB. EN LA CAPILLA DE CAPIRO)', 62),
(344, 52, 'LA BOCANA', 62),
(345, 53, 'MOROMORO (CAB. EN EL VADO)', 62),
(346, 54, 'PIEDRAS', 62),
(347, 55, 'SAN ROQUE (AMBROSIO MALDONADO)', 62),
(348, 56, 'SARACAY', 62),
(349, 50, 'PORTOVELO', 63),
(350, 51, 'CURTINCAPA', 63),
(351, 52, 'MORALES', 63),
(352, 53, 'SALATI', 63),
(353, 1, 'SANTA ROSA', 64),
(354, 2, 'PUERTO JELÍ', 64),
(355, 3, 'BALNEARIO JAMBELÍ (SATÉLITE)', 64),
(356, 4, 'JUMÓN (SATÉLITE)', 64),
(357, 5, 'NUEVO SANTA ROSA', 64),
(358, 51, 'BELLAVISTA', 64),
(359, 52, 'JAMBELI', 64),
(360, 53, 'LA AVANZADA', 64),
(361, 54, 'SAN ANTONIO', 64),
(362, 55, 'TORATA', 64),
(363, 56, 'VICTORIA', 64),
(364, 57, 'BELLAMARIA', 64),
(365, 50, 'ZARUMA', 65),
(366, 51, 'ABAÑIN', 65),
(367, 52, 'ARCAPAMBA', 65),
(368, 53, 'GUANAZAN', 65),
(369, 54, 'GUIZHAGUIÑA', 65),
(370, 55, 'HUERTAS', 65),
(371, 56, 'MALVAS', 65),
(372, 57, 'MULUNCAY GRANDE', 65),
(373, 58, 'SINSAO', 65),
(374, 59, 'SALVIAS', 65),
(375, 1, 'LA VICTORIA', 66),
(376, 2, 'PLATANILLOS', 66),
(377, 3, 'VALLE HERMOSO', 66),
(378, 51, 'LA LIBERTAD', 66),
(379, 52, 'EL PARAISO', 66),
(380, 53, 'SAN ISIDRO', 66),
(381, 1, 'BARTOLOMÉ RUIZ (CÉSAR FRANCO CARRIÓN)', 67),
(382, 2, '5 DE AGOSTO', 67),
(383, 3, 'ESMERALDAS', 67),
(384, 4, 'LUIS TELLO (LAS PALMAS)', 67),
(385, 5, 'SIMÓN PLATA TORRES', 67),
(386, 52, 'CAMARONES (CAB. EN SAN VICENTE)', 67),
(387, 53, 'CORONEL CARLOS CONCHA TORRES (CAB. EN HUELE)', 67),
(388, 54, 'CHINCA', 67),
(389, 59, 'MAJUA', 67),
(390, 63, 'SAN MATEO', 67),
(391, 65, 'TABIAZO', 67),
(392, 66, 'TACHINA', 67),
(393, 68, 'VUELTA LARGA', 67),
(394, 50, 'VALDEZ (LIMONES)', 68),
(395, 51, 'ANCHAYACU', 68),
(396, 52, 'ATAHUALPA (CAB. EN CAMARONES)', 68),
(397, 53, 'BORBON', 68),
(398, 54, 'LA TOLA', 68),
(399, 55, 'LUIS VARGAS TORRES (CAB. EN PLAYA DE ORO)', 68),
(400, 56, 'MALDONADO', 68),
(401, 57, 'PAMPANAL DE BOLIVAR', 68),
(402, 58, 'SAN FRANCISCO DE ONZOLE', 68),
(403, 59, 'SANTO DOMINGO DE ONZOLE', 68),
(404, 60, 'SELVA ALEGRE', 68),
(405, 61, 'TELEMBI', 68),
(406, 62, 'COLON ELOY DEL MARIA', 68),
(407, 63, 'SAN JOSE DE CAYAPAS', 68),
(408, 64, 'TIMBIRE', 68),
(409, 65, 'SANTA LUCIA DE LAS PEÑAS', 68),
(410, 50, 'MUISNE', 69),
(411, 51, 'BOLIVAR', 69),
(412, 52, 'DAULE', 69),
(413, 53, 'GALERA', 69),
(414, 54, 'QUINGUE (OLMEDO PERDOMO FRANCO)', 69),
(415, 55, 'SALIMA', 69),
(416, 56, 'SAN FRANCISCO', 69),
(417, 57, 'SAN GREGORIO', 69),
(418, 58, 'SAN JOSE DE CHAMANGA', 69),
(419, 50, 'ROSA ZARATE (QUININDE)', 70),
(420, 51, 'CUBE', 70),
(421, 52, 'CHURA (CHANCAMA) (CAB. EN EL YERBERO)', 70),
(422, 53, 'MALIMPIA', 70),
(423, 54, 'VICHE', 70),
(424, 55, 'LA UNION', 70),
(425, 50, 'SAN LORENZO', 71),
(426, 51, 'ALTO TAMBO (CAB EN GUADUAL)', 71),
(427, 52, 'ANCON (PICHANGAL) (CAB. EN PALMA REAL)', 71),
(428, 53, 'CALDERON', 71),
(429, 54, 'CARONDELET', 71),
(430, 55, '5 DE JUNIO (CAB. EN UIMBI)', 71),
(431, 56, 'CONCEPCION', 71),
(432, 57, 'MATAJE (CAB. EN SANTANDER)', 71),
(433, 58, 'SAN JAVIER DE CACHAVI (CAB. EN SAN JAVIER)', 71),
(434, 59, 'SANTA RITA', 71),
(435, 60, 'TAMBILLO', 71),
(436, 61, 'TULULBI (CAB. EN RICAURTE)', 71),
(437, 62, 'URBINA', 71),
(438, 50, 'ATACAMES', 72),
(439, 51, 'LA UNION', 72),
(440, 52, 'SUA (CAB. EN LA BOCANA)', 72),
(441, 53, 'TONCHIGUE', 72),
(442, 54, 'TONSUPA', 72),
(443, 50, 'RIOVERDE', 73),
(444, 51, 'CHONTADURO', 73),
(445, 52, 'CHUMUNDE', 73),
(446, 53, 'LAGARTO', 73),
(447, 54, 'MONTALVO (CAB EN HORQUETA)', 73),
(448, 55, 'ROCAFUERTE', 73),
(449, 1, 'AYACUCHO', 74),
(450, 2, 'BOLÍVAR (SAGRARIO)', 74),
(451, 3, 'CARBO (CONCEPCIÓN)', 74),
(452, 4, 'FEBRES CORDERO', 74),
(453, 5, 'GARCÍA MORENO', 74),
(454, 6, 'LETAMENDI', 74),
(455, 7, 'NUEVE DE OCTUBRE', 74),
(456, 8, 'OLMEDO (SAN ALEJO)', 74),
(457, 9, 'ROCA', 74),
(458, 10, 'ROCAFUERTE', 74),
(459, 11, 'SUCRE', 74),
(460, 12, 'TARQUI', 74),
(461, 13, 'URDANETA', 74),
(462, 14, 'XIMENA', 74),
(463, 15, 'PASCUALES', 74),
(464, 52, 'JUAN GOMEZ RENDON (PROGRESO)', 74),
(465, 53, 'MORRO', 74),
(466, 56, 'POSORJA', 74),
(467, 57, 'PUNA', 74),
(468, 58, 'TENGUEL', 74),
(469, 50, 'ALFREDO BAQUERIZO MORENO (JUJAN)', 75),
(470, 50, 'BALAO', 76),
(471, 50, 'BALZAR', 77),
(472, 50, 'COLIMES', 78),
(473, 51, 'SAN JACINTO', 78),
(474, 1, 'DAULE', 79),
(475, 2, 'LA AURORA (SATÉLITE)', 79),
(476, 3, 'BANIFE', 79),
(477, 4, 'EMILIANO CAICEDO MARCOS', 79),
(478, 5, 'MAGRO', 79),
(479, 6, 'PADRE JUAN BAUTISTA AGUIRRE', 79),
(480, 7, 'SANTA CLARA', 79),
(481, 8, 'VICENTE PIEDRAHITA', 79),
(482, 52, 'JUAN BAUTISTA AGUIRRE (LOS TINTOS)', 79),
(483, 53, 'LAUREL', 79),
(484, 54, 'LIMONAL', 79),
(485, 56, 'LOS LOJAS (ENRIQUE BAQUERIZO MORENO)', 79),
(486, 1, 'ELOY ALFARO (DURÁN)', 80),
(487, 2, 'EL RECREO', 80),
(488, 3, 'DIVINO NIÑO', 80),
(489, 50, 'VELASCO IBARRA (CAB. EL EMPALME)', 81),
(490, 51, 'GUAYAS (PUEBLO NUEVO)', 81),
(491, 52, 'EL ROSARIO', 81),
(492, 50, 'EL TRIUNFO', 82),
(493, 1, 'CAMILO ANDRADE', 83),
(494, 2, 'ELOY ALFARO', 83),
(495, 3, 'CHIRIJOS', 83),
(496, 4, 'CORONEL ENRIQUE VALDEZ', 83),
(497, 5, 'ROSA MARIA', 83),
(498, 6, 'JOSE MARIA VELASCO IBARRA', 83),
(499, 7, 'VICENTE ROCAFUERTE', 83),
(500, 8, 'ERNESTO SEMINARIO', 83),
(501, 9, 'LAS PIÑAS', 83),
(502, 51, 'CHOBO', 83),
(503, 53, 'MARISCAL SUCRE (HUAQUES)', 83),
(504, 54, 'ROBERTO ASTUDILLO (CAB. EN CRUCE DE VENECIA)', 83),
(505, 50, 'NARANJAL', 84),
(506, 51, 'JESUS MARIA', 84),
(507, 52, 'SAN CARLOS', 84),
(508, 53, 'SANTA ROSA DE FLANDES', 84),
(509, 54, 'TAURA', 84),
(510, 50, 'NARANJITO', 85),
(511, 50, 'PALESTINA', 86),
(512, 50, 'PEDRO CARBO', 87),
(513, 51, 'VALLE DE LA VIRGEN', 87),
(514, 52, 'SABANILLA', 87),
(515, 1, 'SAMBORONDÓN', 88),
(516, 2, 'LA PUNTILLA (SATÉLITE)', 88),
(517, 51, 'TARIFA', 88),
(518, 50, 'SANTA LUCIA', 89),
(519, 1, 'BOCANA', 90),
(520, 2, 'CANDILEJOS', 90),
(521, 3, 'CENTRAL', 90),
(522, 4, 'PARAÍSO', 90),
(523, 5, 'SAN MATEO', 90),
(524, 51, 'GENERAL VERNAZA (DOS ESTEROS)', 90),
(525, 52, 'LA VICTORIA (ÑAUZA)', 90),
(526, 53, 'JUNQUILLAL', 90),
(527, 50, 'SAN JACINTO DE YAGUACHI', 91),
(528, 53, 'GENERAL PEDRO J. MONTERO (BOLICHE)', 91),
(529, 55, 'YAGUACHI VIEJO (CONE)', 91),
(530, 56, 'VIRGEN DE FATIMA', 91),
(531, 50, 'GENERAL VILLAMIL (PLAYAS)', 92),
(532, 50, 'SIMON BOLIVAR', 93),
(533, 51, 'CORONEL LORENZO DE GARAYCOA (PEDREGAL)', 93),
(534, 50, 'CORONEL MARCELINO MARIDUEÑA (SAN CARLOS)', 94),
(535, 50, 'LOMAS DE SARGENTILLO', 95),
(536, 50, 'NARCISA DE JESUS', 96),
(537, 50, 'GENERAL ANTONIO ELIZALDE (BUCAY)', 97),
(538, 50, 'ISIDRO AYORA', 98),
(539, 1, 'CARANQUI', 99),
(540, 2, 'GUAYAQUIL DE ALPACHACA', 99),
(541, 3, 'SAGRARIO', 99),
(542, 4, 'SAN FRANCISCO', 99),
(543, 5, 'LA DOLOROSA DEL PRIORATO', 99),
(544, 51, 'AMBUQUI', 99),
(545, 52, 'ANGOCHAGUA', 99),
(546, 53, 'CAROLINA', 99),
(547, 54, 'LA ESPERANZA', 99),
(548, 55, 'LITA', 99),
(549, 56, 'SALINAS', 99),
(550, 57, 'SAN ANTONIO', 99),
(551, 1, 'ANDRADE MARÍN (LOURDES)', 100),
(552, 2, 'ATUNTAQUI', 100),
(553, 51, 'IMBAYA (SAN LUIS DE COBUENDO)', 100),
(554, 52, 'SAN FRANCISCO DE NATABUELA', 100),
(555, 53, 'SAN JOSE DE CHALTURA', 100),
(556, 54, 'SAN ROQUE', 100),
(557, 1, 'SAGRARIO', 101),
(558, 2, 'SAN FRANCISCO', 101),
(559, 51, 'APUELA', 101),
(560, 52, 'GARCIA MORENO (LLURIMAGUA)', 101),
(561, 53, 'IMANTAG', 101),
(562, 54, 'PEÑAHERRERA', 101),
(563, 55, 'PLAZA GUTIERREZ (CALVARIO)', 101),
(564, 56, 'QUIROGA', 101),
(565, 57, 'SEIS DE JULIO DE CUELLAJE (CAB. EN CUELLAJE)', 101),
(566, 58, 'VACAS GALINDO (EL CHURO) (CAB. EN SAN MIGUEL ALTO)', 101),
(567, 1, 'JORDÁN', 102),
(568, 2, 'SAN LUIS', 102),
(569, 51, 'DOCTOR MIGUEL EGAS CABEZAS (PEGUCHE)', 102),
(570, 52, 'EUGENIO ESPEJO (CALPAQUI)', 102),
(571, 53, 'GONZALEZ SUAREZ', 102),
(572, 54, 'PATAQUI', 102),
(573, 55, 'SAN JOSE DE QUICHINCHE', 102),
(574, 56, 'SAN JUAN DE ILUMAN', 102),
(575, 57, 'SAN PABLO', 102),
(576, 58, 'SAN RAFAEL', 102),
(577, 59, 'SELVA ALEGRE (CAB. EN SAN MIGUEL DE PAMPLONA)', 102),
(578, 50, 'PIMAMPIRO', 103),
(579, 51, 'CHUGA', 103),
(580, 52, 'MARIANO ACOSTA', 103),
(581, 53, 'SAN FRANCISCO DE SIGSIPAMBA', 103),
(582, 50, 'URCUQUI', 104),
(583, 51, 'CAHUASQUI', 104),
(584, 52, 'LA MERCED DE BUENOS AIRES', 104),
(585, 53, 'PABLO ARENAS', 104),
(586, 54, 'SAN BLAS', 104),
(587, 55, 'TUMBABIRO', 104),
(588, 1, 'EL SAGRARIO', 105),
(589, 2, 'SAN SEBASTIÁN', 105),
(590, 3, 'SUCRE', 105),
(591, 4, 'VALLE', 105),
(592, 5, 'CARIGÁN', 105),
(593, 6, 'PUNZARA', 105),
(594, 51, 'CHANTACO', 105),
(595, 52, 'CHUQUIRIBAMBA', 105),
(596, 53, 'EL CISNE', 105),
(597, 54, 'GUALEL', 105),
(598, 55, 'JIMBILLA', 105),
(599, 56, 'MALACATOS (VALLADOLID)', 105),
(600, 57, 'SAN LUCAS', 105),
(601, 58, 'SAN PEDRO DE VILCABAMBA', 105),
(602, 59, 'SANTIAGO', 105),
(603, 60, 'TAQUIL (MIGUEL RIOFRIO)', 105),
(604, 61, 'VILCABAMBA (VICTORIA)', 105),
(605, 62, 'YANGANA (ARSENIO CASTILLO)', 105),
(606, 63, 'QUINARA', 105),
(607, 1, 'CARIAMANGA', 106),
(608, 2, 'CHILE', 106),
(609, 3, 'SAN VICENTE', 106),
(610, 51, 'COLAISACA', 106),
(611, 52, 'EL LUCERO', 106),
(612, 53, 'UTUANA', 106),
(613, 54, 'SANGUILLIN', 106),
(614, 1, 'CATAMAYO', 107),
(615, 2, 'SAN JOSÉ', 107),
(616, 51, 'EL TAMBO', 107),
(617, 52, 'GUAYQUICHUMA', 107),
(618, 53, 'SAN PEDRO DE LA BENDITA', 107),
(619, 54, 'ZAMBI', 107),
(620, 50, 'CELICA', 108),
(621, 51, 'CRUZPAMBA (CAB EN CARLOS BUSTAMANTE)', 108),
(622, 55, 'POZUL (SAN JUAN DE POZUL)', 108),
(623, 56, 'SABANILLA', 108),
(624, 57, 'TENIENTE MAXIMILIANO RODRIGUEZ LOAIZA', 108),
(625, 50, 'CHAGUARPAMBA', 109),
(626, 51, 'BUENAVISTA', 109),
(627, 52, 'EL ROSARIO', 109),
(628, 53, 'SANTA RUFINA', 109),
(629, 54, 'AMARILLOS', 109),
(630, 50, 'AMALUZA', 110),
(631, 51, 'BELLAVISTA', 110),
(632, 52, 'JIMBURA', 110),
(633, 53, 'SANTA TERESITA', 110),
(634, 54, '27 DE ABRIL (CAB. EN LA NARANJA)', 110),
(635, 55, 'EL INGENIO', 110),
(636, 56, 'EL AIRO', 110),
(637, 50, 'GONZANAMA', 111),
(638, 51, 'CHANGAIMINA (LA LIBERTAD)', 111),
(639, 53, 'NAMBACOLA', 111),
(640, 54, 'PURUNUMA (EGUIGUREN)', 111),
(641, 56, 'SACAPALCA', 111),
(642, 1, 'GENERAL ELOY ALFARO (SAN SEBASTIÁN)', 112),
(643, 2, 'MACARÁ (MANUEL ENRIQUE RENGEL SUQUILANDA)', 112),
(644, 51, 'LARAMA', 112),
(645, 52, 'LA VICTORIA', 112),
(646, 53, 'SABIANGO (LA CAPILLA)', 112),
(647, 1, 'CATACOCHA', 113),
(648, 2, 'LOURDES', 113),
(649, 51, 'CANGONAMA', 113),
(650, 52, 'GUACHANAMA', 113),
(651, 54, 'LAURO GUERRERO', 113),
(652, 56, 'ORIANGA', 113),
(653, 57, 'SAN ANTONIO', 113),
(654, 58, 'CASANGA', 113),
(655, 59, 'YAMANA', 113),
(656, 50, 'ALAMOR', 114),
(657, 51, 'CIANO', 114),
(658, 52, 'EL ARENAL', 114),
(659, 53, 'EL LIMO (MARIANA DE JESUS)', 114),
(660, 54, 'MERCADILLO', 114),
(661, 55, 'VICENTINO', 114),
(662, 50, 'SARAGURO', 115),
(663, 51, 'EL PARAISO DE CELEN', 115),
(664, 52, 'EL TABLON', 115),
(665, 53, 'LLUZHAPA', 115),
(666, 54, 'MANU', 115),
(667, 55, 'SAN ANTONIO DE QUMBE (CUMBE)', 115),
(668, 56, 'SAN PABLO DE TENTA', 115),
(669, 57, 'SAN SEBASTIAN DE YULUC', 115),
(670, 58, 'SELVA ALEGRE', 115),
(671, 59, 'URDANETA (PAQUISHAPA)', 115),
(672, 60, 'SUMAYPAMBA', 115),
(673, 50, 'SOZORANGA', 116),
(674, 51, 'NUEVA FATIMA', 116),
(675, 52, 'TACAMOROS', 116),
(676, 50, 'ZAPOTILLO', 117),
(677, 51, 'MANGAHURCO', 117),
(678, 52, 'GARZAREAL', 117),
(679, 53, 'LIMONES', 117),
(680, 54, 'PALETILLAS', 117),
(681, 55, 'BOLASPAMBA', 117),
(682, 56, 'CAZADEROS', 117),
(683, 50, 'PINDAL', 118),
(684, 51, 'CHAQUINAL', 118),
(685, 52, '12 DE DICIEMBRE (CAB. EN ACHIOTES)', 118),
(686, 53, 'MILAGROS', 118),
(687, 50, 'QUILANGA', 119),
(688, 51, 'FUNDOCHAMBA', 119),
(689, 52, 'SAN ANTONIO DE LAS ARADAS (CAB. EN LAS ARADAS)', 119),
(690, 50, 'OLMEDO', 120),
(691, 51, 'LA TINGUE', 120),
(692, 1, 'CLEMENTE BAQUERIZO', 121),
(693, 2, 'DOCTOR CAMILO PONCE', 121),
(694, 3, 'BARREIRO', 121),
(695, 4, 'EL SALTO', 121),
(696, 52, 'CARACOL', 121),
(697, 53, 'FEBRES CORDERO (LAS JUNTAS)', 121),
(698, 54, 'PIMOCHA', 121),
(699, 55, 'LA UNION', 121),
(700, 50, 'BABA', 122),
(701, 51, 'GUARE', 122),
(702, 52, 'ISLA DE BEJUCAL', 122),
(703, 50, 'MONTALVO', 123),
(704, 51, 'LA ESMERALDA', 123),
(705, 50, 'PUEBLOVIEJO', 124),
(706, 51, 'PUERTO PECHICHE', 124),
(707, 52, 'SAN JUAN', 124),
(708, 1, 'QUEVEDO', 125),
(709, 2, 'SAN CAMILO', 125),
(710, 4, 'GUAYACÁN', 125),
(711, 5, 'NICOLÁS INFANTE DÍAZ', 125),
(712, 6, 'SAN CRISTÓBAL', 125),
(713, 7, 'SIETE DE OCTUBRE', 125),
(714, 8, '24 DE MAYO', 125),
(715, 9, 'VENUS DEL RÍO QUEVEDO', 125),
(716, 10, 'VIVA ALFARO', 125),
(717, 53, 'SAN CARLOS', 125),
(718, 55, 'LA ESPERANZA', 125),
(719, 50, 'CATARAMA', 126),
(720, 51, 'RICAURTE', 126),
(721, 1, '10 DE NOVIEMBRE', 127),
(722, 2, 'VENTANAS', 127),
(723, 52, 'ZAPOTAL', 127),
(724, 53, 'CHACARITA', 127),
(725, 54, 'LOS ANGELES', 127),
(726, 1, 'BALZAR DE VINCES', 128),
(727, 2, 'VINCES CENTRAL', 128),
(728, 3, 'SAN LORENZO DE VINCES', 128),
(729, 51, 'ANTONIO SOTOMAYOR (CAB. EN PLAYAS DE VINCES)', 128),
(730, 50, 'PALENQUE', 129),
(731, 1, 'SAN JACINTO DE BUENA FÉ', 130),
(732, 2, '7 DE AGOSTO', 130),
(733, 3, '11 DE OCTUBRE', 130),
(734, 51, 'PATRICIA PILAR', 130),
(735, 1, 'VALENCIA', 131),
(736, 2, 'LA UNION', 131),
(737, 3, 'LA NUEVA UNION', 131),
(738, 50, 'MOCACHE', 132),
(739, 50, 'QUINSALOMA', 133),
(740, 1, 'PORTOVIEJO', 134),
(741, 2, '12 DE MARZO', 134),
(742, 3, 'COLÓN', 134),
(743, 4, 'PICOAZÁ', 134),
(744, 5, 'SAN PABLO', 134),
(745, 6, 'ANDRÉS DE VERA', 134),
(746, 7, 'FRANCISCO PACHECO', 134),
(747, 8, '18 DE OCTUBRE', 134),
(748, 9, 'SIMÓN BOLÍVAR', 134),
(749, 51, 'ABDON CALDERON (SAN FRANCISCO)', 134),
(750, 52, 'ALHAJUELA (BAJO GRANDE)', 134),
(751, 53, 'CRUCITA', 134),
(752, 54, 'PUEBLO NUEVO', 134),
(753, 55, 'RIOCHICO (RIO CHICO)', 134),
(754, 56, 'SAN PLACIDO', 134),
(755, 57, 'CHIRIJOS', 134),
(756, 50, 'CALCETA', 31),
(757, 51, 'MEMBRILLO', 31),
(758, 52, 'QUIROGA', 31),
(759, 1, 'CHONE', 136),
(760, 2, 'SANTA RITA', 136),
(761, 51, 'BOYACA', 136),
(762, 52, 'CANUTO', 136),
(763, 53, 'CONVENTO', 136),
(764, 54, 'CHIBUNGA', 136),
(765, 55, 'ELOY ALFARO', 136),
(766, 56, 'RICAURTE', 136),
(767, 57, 'SAN ANTONIO', 136),
(768, 1, 'EL CARMEN', 137),
(769, 2, '4 DE DICIEMBRE', 137),
(770, 51, 'WILFRIDO LOOR MOREIRA (MAICITO)', 137),
(771, 52, 'SAN PEDRO DE SUMA', 137),
(772, 53, 'SANTA MARIA (CAB EN SANTA MARIA)', 137),
(773, 54, 'EL PARAISO LA 14 (CAB EN EL PARAISO)', 137),
(774, 50, 'FLAVIO ALFARO', 138),
(775, 51, 'SAN FRANCISCO DE NOVILLO (CAB. EN NOVILLO)', 138),
(776, 52, 'ZAPALLO', 138),
(777, 1, 'DOCTOR MIGUEL MORÁN LUCIO', 139),
(778, 2, 'MANUEL INOCENCIO PARRALES Y GUALE', 139),
(779, 3, 'SAN LORENZO DE JIPIJAPA', 139),
(780, 51, 'AMERICA', 139),
(781, 52, 'EL ANEGADO (CAB. EN ELOY ALFARO)', 139),
(782, 53, 'JULCUY', 139),
(783, 54, 'LA UNION', 139),
(784, 56, 'MEMBRILLAL', 139),
(785, 57, 'PEDRO PABLO GOMEZ', 139),
(786, 58, 'PUERTO DE CAYO', 139),
(787, 50, 'JUNIN', 140),
(788, 1, 'LOS ESTEROS', 141),
(789, 2, 'MANTA', 141),
(790, 3, 'SAN MATEO', 141),
(791, 4, 'TARQUI', 141),
(792, 5, 'ELOY ALFARO', 141),
(793, 51, 'SAN LORENZO', 141),
(794, 52, 'SANTA MARIANITA (BOCA DE PACOCHE)', 141),
(795, 1, 'ANÍBAL SAN ANDRÉS', 142),
(796, 2, 'MONTECRISTI', 142),
(797, 3, 'EL COLORADO', 142),
(798, 4, 'GENERAL ELOY ALFARO', 142),
(799, 5, 'LEONIDAS PROAÑO', 142),
(800, 52, 'LA PILA', 142),
(801, 50, 'PAJAN', 143),
(802, 51, 'CAMPOZANO (LA PALMA DE PAJAN)', 143),
(803, 52, 'CASCOL', 143),
(804, 53, 'GUALE', 143),
(805, 54, 'LASCANO', 143),
(806, 50, 'PICHINCHA', 144),
(807, 51, 'BARRAGANETE', 144),
(808, 52, 'SAN SEBASTIAN', 144),
(809, 50, 'ROCAFUERTE', 145),
(810, 1, 'SANTA ANA', 146),
(811, 2, 'LODANA', 146),
(812, 51, 'AYACUCHO', 146),
(813, 52, 'HONORATO VASQUEZ (CAB EN VASQUEZ)', 146),
(814, 53, 'LA UNION', 146),
(815, 55, 'SAN PABLO (CAB EN PUEBLO NUEVO)', 146),
(816, 1, 'BAHÍA DE CARÁQUEZ', 147),
(817, 2, 'LEONIDAS PLAZA GUTIÉRREZ', 147),
(818, 53, 'CHARAPOTO', 147),
(819, 57, 'SAN ISIDRO', 147),
(820, 50, 'TOSAGUA', 148),
(821, 51, 'BACHILLERO', 148),
(822, 52, 'ANGEL PEDRO GILER (LA ESTANCILLA)', 148),
(823, 50, 'SUCRE', 149),
(824, 51, 'BELLAVISTA', 149),
(825, 52, 'NOBOA', 149),
(826, 53, 'ARQUITECTO SIXTO DURAN BALLEN', 149),
(827, 50, 'PEDERNALES', 150),
(828, 51, 'COJIMIES', 150),
(829, 52, 'DIEZ DE AGOSTO', 150),
(830, 53, 'ATAHUALPA', 150),
(831, 50, 'OLMEDO', 120),
(832, 50, 'PUERTO LOPEZ', 152),
(833, 51, 'MACHALILLA', 152),
(834, 52, 'SALANGO', 152),
(835, 50, 'JAMA', 153),
(836, 50, 'JARAMIJO', 154),
(837, 50, 'SAN VICENTE', 155),
(838, 51, 'CANOA', 155),
(839, 50, 'MACAS', 156),
(840, 51, 'ALSHI (CAB EN 9 DE OCTUBRE)', 156),
(841, 53, 'GENERAL PROAÑO', 156),
(842, 56, 'SAN ISIDRO', 156),
(843, 57, 'SEVILLA DON BOSCO', 156),
(844, 58, 'SINAI', 156),
(845, 60, 'ZUÑA (ZUÑAC)', 156),
(846, 62, 'CUCHAENTZA', 156),
(847, 64, 'RIO BLANCO', 156),
(848, 1, 'GUALAQUIZA', 157),
(849, 2, 'MERCEDES MOLINA', 157),
(850, 51, 'AMAZONAS (ROSARIO DE CUYES)', 157),
(851, 52, 'BERMEJOS', 157),
(852, 53, 'BOMBOIZA', 157),
(853, 54, 'CHIGUINDA', 157),
(854, 55, 'EL ROSARIO', 157),
(855, 56, 'NUEVA TARQUI', 157),
(856, 57, 'SAN MIGUEL DE CUYES', 157),
(857, 58, 'EL IDEAL', 157),
(858, 50, 'GENERAL LEONIDAS PLAZA GUTIERREZ', 158),
(859, 51, 'INDANZA', 158),
(860, 53, 'SAN ANTONIO (CAB EN SAN ANTONIO CENTRO)', 158),
(861, 56, 'SAN MIGUEL DE CONCHAY', 158),
(862, 57, 'STA SUSANA DE CHIVIAZA (CAB EN CHIVIAZA)', 158),
(863, 58, 'YUNGANZA (CAB EN EL ROSARIO)', 158),
(864, 50, 'PALORA (METZERA)', 159),
(865, 51, 'ARAPICOS', 159),
(866, 52, 'CUMANDA (CAB EN COLONIA AGRICOLA SEVILLA DEL ORO)', 159),
(867, 54, 'SANGAY (CAB EN NAYAMANACA)', 159),
(868, 55, '16 DE AGOSTO', 159),
(869, 50, 'SANTIAGO DE MENDEZ', 160),
(870, 51, 'COPAL', 160),
(871, 52, 'CHUPIANZA', 160),
(872, 53, 'PATUCA', 160),
(873, 54, 'SAN LUIS DE EL ACHO (CAB EN EL ACHO)', 160),
(874, 56, 'TAYUZA', 160),
(875, 57, 'SAN FRANCISCO DE CHINIMBIMI', 160),
(876, 50, 'SUCUA', 161),
(877, 51, 'ASUNCION', 161),
(878, 52, 'HUAMBI', 161),
(879, 55, 'SANTA MARIANITA DE JESUS', 161),
(880, 50, 'HUAMBOYA', 162),
(881, 51, 'CHIGUAZA', 162),
(882, 50, 'SAN JUAN BOSCO', 163),
(883, 51, 'PAN DE AZUCAR', 163),
(884, 52, 'SAN CARLOS DE LIMON', 163),
(885, 53, 'SAN JACINTO DE WAKAMBEIS', 163),
(886, 54, 'SANTIAGO DE PANANZA', 163),
(887, 50, 'TAISHA', 164),
(888, 51, 'HUASAGA (CAB EN WAMPUIK)', 164),
(889, 52, 'MACUMA', 164),
(890, 53, 'TUUTINENTZA', 164),
(891, 54, 'PUMPUENTSA', 164),
(892, 50, 'LOGROÑO', 165),
(893, 51, 'YAUPI', 165),
(894, 52, 'SHIMPIS', 165),
(895, 50, 'PABLO SEXTO', 166),
(896, 50, 'SANTIAGO', 167),
(897, 51, 'SAN JOSE DE MORONA', 167),
(898, 50, 'TENA', 168),
(899, 51, 'AHUANO', 168),
(900, 53, 'CHONTAPUNTA', 168),
(901, 54, 'PANO', 168),
(902, 55, 'PUERTO MISAHUALLI', 168),
(903, 56, 'PUERTO NAPO', 168),
(904, 57, 'TALAG', 168),
(905, 58, 'SAN JUAN DE MUYUNA', 168),
(906, 50, 'ARCHIDONA', 169),
(907, 52, 'COTUNDO', 169),
(908, 54, 'SAN PABLO DE USHPAYACU', 169),
(909, 56, 'HATUN SUMAKU', 169),
(910, 50, 'EL CHACO', 170),
(911, 51, 'GONZALO DIAZ DE PINEDA (EL BOMBON)', 170),
(912, 52, 'LINARES', 170),
(913, 53, 'OYACACHI', 170),
(914, 54, 'SANTA ROSA', 170),
(915, 55, 'SARDINAS', 170),
(916, 50, 'BAEZA', 171),
(917, 51, 'COSANGA', 171),
(918, 52, 'CUYUJA', 171),
(919, 53, 'PAPALLACTA', 171),
(920, 54, 'SAN FRANCISCO DE BORJA (VIRGILIO DAVILA)', 171),
(921, 56, 'SUMACO', 171),
(922, 50, 'CARLOS JULIO AROSEMENA TOLA', 172),
(923, 50, 'PUYO', 173),
(924, 52, 'CANELOS', 173),
(925, 54, 'DIEZ DE AGOSTO', 173),
(926, 55, 'FATIMA', 173),
(927, 56, 'MONTALVO (ANDOAS)', 173),
(928, 57, 'POMONA', 173),
(929, 58, 'RIO CORRIENTES', 173),
(930, 59, 'RIO TIGRE', 173),
(931, 61, 'SARAYACU', 173),
(932, 62, 'SIMON BOLIVAR (CAB. EN MUSHULLACTA)', 173),
(933, 63, 'TARQUI', 173),
(934, 64, 'TENIENTE HUGO ORTIZ', 173),
(935, 65, 'VERACRUZ (INDILLAMA) (CAB. EN INDILLAMA)', 173),
(936, 66, 'EL TRIUNFO', 173),
(937, 50, 'MERA', 174),
(938, 51, 'MADRE TIERRA', 174),
(939, 52, 'SHELL', 174),
(940, 50, 'SANTA CLARA', 175),
(941, 51, 'SAN JOSE', 175),
(942, 50, 'ARAJUNO', 176),
(943, 51, 'CURARAY', 176),
(944, 1, 'BELISARIO QUEVEDO', 177),
(945, 2, 'CARCELÉN', 177),
(946, 3, 'CENTRO HISTÓRICO', 177),
(947, 4, 'COCHAPAMBA', 177),
(948, 5, 'COMITÉ DEL PUEBLO', 177),
(949, 6, 'COTOCOLLAO', 177),
(950, 7, 'CHILIBULO', 177),
(951, 8, 'CHILLOGALLO', 177),
(952, 9, 'CHIMBACALLE', 177),
(953, 10, 'EL CONDADO', 177),
(954, 11, 'GUAMANÍ', 177),
(955, 12, 'IÑAQUITO', 177),
(956, 13, 'ITCHIMBIA', 177),
(957, 14, 'JIPIJAPA', 177),
(958, 15, 'KENNEDY', 177),
(959, 16, 'LA ARGELIA', 177),
(960, 17, 'LA CONCEPCIÓN', 177),
(961, 18, 'LA ECUATORIANA', 177),
(962, 19, 'LA FERROVIARIA', 177),
(963, 20, 'LA LIBERTAD', 177),
(964, 21, 'LA MAGDALENA', 177),
(965, 22, 'LA MENA', 177),
(966, 23, 'MARISCAL SUCRE', 177),
(967, 24, 'PONCEANO', 177),
(968, 25, 'PUENGASÍ', 177),
(969, 26, 'QUITUMBE', 177),
(970, 27, 'RUMIPAMBA', 177),
(971, 28, 'SAN BARTOLO', 177),
(972, 29, 'SAN ISIDRO DEL INCA', 177),
(973, 30, 'SAN JUAN', 177),
(974, 31, 'SOLANDA', 177),
(975, 32, 'TURUBAMBA', 177),
(976, 51, 'ALANGASI', 177),
(977, 52, 'AMAGUAÑA', 177),
(978, 53, 'ATAHUALPA (HABASPAMBA)', 177),
(979, 54, 'CALACALI', 177),
(980, 55, 'CALDERON (CARAPUNGO)', 177),
(981, 56, 'CONOCOTO', 177),
(982, 57, 'CUMBAYA', 177),
(983, 58, 'CHAVEZPAMBA', 177),
(984, 59, 'CHECA (CHILPA)', 177),
(985, 60, 'EL QUINCHE', 177),
(986, 61, 'GUALEA', 177),
(987, 62, 'GUANGOPOLO', 177),
(988, 63, 'GUAYLLABAMBA', 177),
(989, 64, 'LA MERCED', 177),
(990, 65, 'LLANO CHICO', 177),
(991, 66, 'LLOA', 177),
(992, 68, 'NANEGAL', 177),
(993, 69, 'NANEGALITO', 177),
(994, 70, 'NAYON', 177),
(995, 71, 'NONO', 177),
(996, 72, 'PACTO', 177),
(997, 74, 'PERUCHO', 177),
(998, 75, 'PIFO', 177),
(999, 76, 'PINTAG', 177),
(1000, 77, 'POMASQUI', 177),
(1001, 78, 'PUELLARO', 177),
(1002, 79, 'PUEMBO', 177),
(1003, 80, 'SAN ANTONIO', 177),
(1004, 81, 'SAN JOSE DE MINAS', 177),
(1005, 83, 'TABABELA', 177),
(1006, 84, 'TUMBACO', 177),
(1007, 85, 'YARUQUI', 177),
(1008, 86, 'ZAMBIZA', 177),
(1009, 2, 'CAYAMBE', 178),
(1010, 3, 'JUAN MONTALVO', 178),
(1011, 51, 'ASCAZUBI', 178),
(1012, 52, 'CANGAHUA', 178),
(1013, 53, 'OLMEDO (PESILLO)', 178),
(1014, 54, 'OTON', 178),
(1015, 55, 'SANTA ROSA DE CUZUBAMBA', 178),
(1016, 56, 'SAN JOSE DE AYORA', 178),
(1017, 50, 'MACHACHI', 179),
(1018, 51, 'ALOAG', 179),
(1019, 52, 'ALOASI', 179),
(1020, 53, 'CUTUGLAHUA', 179),
(1021, 54, 'EL CHAUPI', 179),
(1022, 55, 'MANUEL CORNEJO ASTORGA (TANDAPI)', 179),
(1023, 56, 'TAMBILLO', 179),
(1024, 57, 'UYUMBICHO', 179),
(1025, 50, 'TABACUNDO', 180),
(1026, 51, 'LA ESPERANZA', 180),
(1027, 52, 'MALCHINGUI', 180),
(1028, 53, 'TOCACHI', 180),
(1029, 54, 'TUPIGACHI', 180),
(1030, 1, 'SANGOLQUÍ', 181),
(1031, 2, 'SAN PEDRO DE TABOADA', 181),
(1032, 3, 'SAN RAFAEL', 181),
(1033, 4, 'FAJARDO', 181),
(1034, 51, 'COTOGCHOA', 181),
(1035, 52, 'RUMIPAMBA', 181),
(1036, 50, 'SAN MIGUEL DE LOS BANCOS', 182),
(1037, 51, 'MINDO', 182),
(1038, 50, 'PEDRO VICENTE MALDONADO', 183),
(1039, 50, 'PUERTO QUITO', 184),
(1040, 1, 'ATOCHA – FICOA', 185),
(1041, 2, 'CELIANO MONGE', 185),
(1042, 3, 'HUACHI CHICO', 185),
(1043, 4, 'HUACHI LORETO', 185),
(1044, 5, 'LA MERCED', 185),
(1045, 6, 'LA PENÍNSULA', 185),
(1046, 7, 'MATRIZ', 185),
(1047, 8, 'PISHILATA', 185),
(1048, 9, 'SAN FRANCISCO', 185),
(1049, 51, 'AMBATILLO', 185),
(1050, 52, 'ATAHUALPA (CHISALATA)', 185),
(1051, 53, 'AUGUSTO N. MARTINEZ (MUNDUGLEO)', 185),
(1052, 54, 'CONSTANTINO FERNANDEZ (CAB. EN CULLITAHUA)', 185),
(1053, 55, 'HUACHI GRANDE', 185),
(1054, 56, 'IZAMBA', 185),
(1055, 57, 'JUAN BENIGNO VELA', 185),
(1056, 58, 'MONTALVO', 185),
(1057, 59, 'PASA', 185),
(1058, 60, 'PICAIGUA', 185),
(1059, 61, 'PILAGUIN (PILAHUIN)', 185),
(1060, 62, 'QUISAPINCHA (QUIZAPINCHA)', 185),
(1061, 63, 'SAN BARTOLOME DE PINLLOG', 185),
(1062, 64, 'SAN FERNANDO (PASA SAN FERNANDO)', 185),
(1063, 65, 'SANTA ROSA', 185),
(1064, 66, 'TOTORAS', 185),
(1065, 67, 'CUNCHIBAMBA', 185),
(1066, 68, 'UNAMUNCHO', 185),
(1067, 50, 'BAÑOS DE AGUA SANTA', 186),
(1068, 51, 'LLIGUA', 186),
(1069, 52, 'RIO NEGRO', 186),
(1070, 53, 'RIO VERDE', 186),
(1071, 54, 'ULBA', 186),
(1072, 50, 'CEVALLOS', 187),
(1073, 50, 'MOCHA', 188),
(1074, 51, 'PINGUILI', 188),
(1075, 50, 'PATATE', 189),
(1076, 51, 'EL TRIUNFO', 189),
(1077, 52, 'LOS ANDES (CAB. EN POATUG)', 189),
(1078, 53, 'SUCRE (CAB. EN SUCRE-PATATE URCU)', 189),
(1079, 50, 'QUERO', 190),
(1080, 51, 'RUMIPAMBA', 190),
(1081, 52, 'YANAYACU - MOCHAPATA (CAB. EN YANAYACU)', 190),
(1082, 1, 'PELILEO', 191),
(1083, 2, 'PELILEO GRANDE', 191),
(1084, 51, 'BENITEZ (PACHANLICA)', 191),
(1085, 52, 'BOLIVAR', 191),
(1086, 53, 'COTALO', 191),
(1087, 54, 'CHIQUICHA (CAB. EN CHIQUICHA GRANDE)', 191),
(1088, 55, 'EL ROSARIO (RUMICHACA)', 191),
(1089, 56, 'GARCIA MORENO (CHUMAQUI)', 191),
(1090, 57, 'GUAMBALO (HUAMBALO)', 191),
(1091, 58, 'SALASACA', 191),
(1092, 1, 'CIUDAD NUEVA', 192),
(1093, 2, 'PÍLLARO', 192),
(1094, 51, 'BAQUERIZO MORENO', 192),
(1095, 52, 'EMILIO MARIA TERAN (RUMIPAMBA)', 192),
(1096, 53, 'MARCOS ESPINEL (CHACATA)', 192),
(1097, 54, 'PRESIDENTE URBINA (CHAGRAPAMBA PATZUCUL)', 192),
(1098, 55, 'SAN ANDRES', 192),
(1099, 56, 'SAN JOSE DE POALO', 192),
(1100, 57, 'SAN MIGUELITO', 192),
(1101, 50, 'TISALEO', 193),
(1102, 51, 'QUINCHICOTO', 193),
(1103, 1, 'EL LIMÓN', 194),
(1104, 2, 'ZAMORA', 194),
(1105, 51, 'CUMBARATZA', 194),
(1106, 52, 'GUADALUPE', 194),
(1107, 53, 'IMBANA (LA VICTORIA DE IMBANA)', 194),
(1108, 55, 'SABANILLA', 194),
(1109, 56, 'TIMBARA', 194),
(1110, 58, 'SAN CARLOS DE LAS MINAS', 194),
(1111, 50, 'ZUMBA', 195),
(1112, 51, 'CHITO', 195),
(1113, 52, 'EL CHORRO', 195),
(1114, 54, 'LA CHONTA', 195),
(1115, 56, 'PUCAPAMBA', 195),
(1116, 59, 'SAN ANDRES', 195),
(1117, 50, 'GUAYZIMI', 196),
(1118, 51, 'ZURMI', 196),
(1119, 52, 'NUEVO PARAISO', 196),
(1120, 53, 'NANKAIS (CAB EN SANTA ELENA)', 196),
(1121, 50, '28 DE MAYO (SAN JOSE DE YACUAMBI)', 197),
(1122, 51, 'LA PAZ', 197),
(1123, 52, 'TUTUPALI', 197),
(1124, 50, 'YANTZAZA (YANZATZA)', 198),
(1125, 51, 'CHICAÑA', 198),
(1126, 53, 'LOS ENCUENTROS', 198),
(1127, 50, 'EL PANGUI', 199),
(1128, 51, 'EL GUISME', 199),
(1129, 52, 'PACHICUTZA', 199),
(1130, 53, 'TUNDAYME', 199),
(1131, 50, 'ZUMBI', 200),
(1132, 52, 'TRIUNFO-DORADO', 200),
(1133, 53, 'PANGUINTZA', 200),
(1134, 50, 'PALANDA', 201),
(1135, 51, 'EL PORVENIR DEL CARMEN', 201),
(1136, 52, 'SAN FRANCISCO DEL VERGEL', 201),
(1137, 53, 'VALLADOLID', 201),
(1138, 54, 'LA CANELA', 201),
(1139, 50, 'PAQUISHA', 202),
(1140, 51, 'BELLAVISTA', 202),
(1141, 52, 'NUEVO QUITO', 202),
(1142, 50, 'PUERTO BAQUERIZO MORENO', 203),
(1143, 51, 'EL PROGRESO', 203),
(1144, 52, 'ISLA SANTA MARÍA (FLOREANA) (CAB. EN PTO. VELASCO IBARRA)', 203),
(1145, 50, 'PUERTO VILLAMIL', 204),
(1146, 51, 'TOMAS DE BERLANGA (SANTO TOMAS)', 204),
(1147, 50, 'PUERTO AYORA', 205),
(1148, 51, 'BELLA VISTA', 205),
(1149, 52, 'SANTA ROSA', 205),
(1150, 50, 'NUEVA LOJA', 206),
(1151, 52, 'DURENO', 206),
(1152, 53, 'GENERAL FARFAN', 206),
(1153, 55, 'EL ENO', 206),
(1154, 56, 'PACAYACU', 206),
(1155, 57, 'JAMBELI', 206),
(1156, 58, 'SANTA CECILIA', 206),
(1157, 60, '10 DE AGOSTO', 206),
(1158, 50, 'LUMBAQUI', 207),
(1159, 51, 'EL REVENTADOR', 207),
(1160, 52, 'GONZALO PIZARRO', 207),
(1161, 54, 'PUERTO LIBRE', 207),
(1162, 50, 'PUERTO EL CARMEN DEL PUTUMAYO', 208),
(1163, 51, 'PALMA ROJA', 208),
(1164, 52, 'PUERTO BOLIVAR (PUERTO MONTUFAR)', 208),
(1165, 53, 'PUERTO RODRIGUEZ', 208),
(1166, 54, 'SANTA ELENA', 208),
(1167, 50, 'SHUSHUFINDI', 209),
(1168, 51, 'LIMONCOCHA', 209),
(1169, 52, 'PAÑACOCHA', 209),
(1170, 53, 'SAN ROQUE (CAB. EN SAN VICENTE)', 209),
(1171, 54, 'SAN PEDRO DE LOS COFANES', 209),
(1172, 55, 'SIETE DE JULIO', 209),
(1173, 50, 'LA BONITA', 210),
(1174, 51, 'EL PLAYON DE SAN FRANCISCO', 210),
(1175, 52, 'LA SOFIA', 210),
(1176, 53, 'ROSA FLORIDA', 210),
(1177, 54, 'SANTA BARBARA', 210),
(1178, 50, 'EL DORADO DE CASCALES', 211),
(1179, 51, 'SANTA ROSA DE SUCUMBIOS', 211),
(1180, 52, 'SEVILLA', 211),
(1181, 53, 'NUEVA TRONCAL (CAB EN NUEVA TRONCAL)', 211),
(1182, 50, 'TARAPOA', 212),
(1183, 51, 'CUYABENO', 212),
(1184, 52, 'AGUAS NEGRAS', 212),
(1185, 50, 'PUERTO FRANCISCO DE ORELLANA (EL COCA)', 213),
(1186, 51, 'DAYUMA', 213),
(1187, 52, 'TARACOA (NUEVA ESPERANZA: YUCA)', 213),
(1188, 53, 'ALEJANDRO LABAKA', 213),
(1189, 54, 'EL DORADO', 213),
(1190, 55, 'EL EDEN', 213),
(1191, 56, 'GARCIA MORENO', 213),
(1192, 57, 'INES ARANGO (CAB. EN WESTERN)', 213),
(1193, 58, 'LA BELLEZA', 213),
(1194, 59, 'NUEVO PARAISO (CAB. EN UNION )', 213),
(1195, 60, 'SAN JOSE DE GUAYUSA', 213),
(1196, 61, 'SAN LUIS DE ARMENIA', 213),
(1197, 50, 'NUEVO ROCAFUERTE', 214),
(1198, 51, 'CAPITAN AUGUSTO RIVADENEYRA', 214),
(1199, 52, 'CONONACO', 214),
(1200, 53, 'SANTA MARIA DE HUIRIRIMA', 214),
(1201, 54, 'TIPUTINI', 214),
(1202, 55, 'YASUNI', 214),
(1203, 50, 'LA JOYA DE LOS SACHAS', 215),
(1204, 51, 'ENOKANQUI', 215),
(1205, 52, 'POMPEYA', 215),
(1206, 53, 'SAN CARLOS', 215),
(1207, 54, 'SAN SEBASTIAN DEL COCA', 215),
(1208, 55, 'LAGO SAN PEDRO', 215),
(1209, 56, 'RUMIPAMBA', 215),
(1210, 57, 'TRES DE NOVIEMBRE', 215),
(1211, 58, 'UNION MILAGREÑA', 215),
(1212, 50, 'LORETO', 216),
(1213, 51, 'AVILA (CAB. EN HUIRUNO)', 216),
(1214, 52, 'PUERTO MURIALDO', 216),
(1215, 53, 'SAN JOSE DE PAYAMINO', 216),
(1216, 54, 'SAN JOSE DE DAHUANO', 216),
(1217, 55, 'SAN VICENTE DE HUATICOCHA', 216),
(1218, 1, 'ABRAHAM CALAZACÓN', 217),
(1219, 2, 'BOMBOLÍ', 217),
(1220, 3, 'CHIGUILPE', 217),
(1221, 4, 'RÍO TOACHI', 217),
(1222, 5, 'RÍO VERDE', 217),
(1223, 6, 'SANTO DOMINGO DE LOS COLORADOS', 217),
(1224, 7, 'ZARACAY', 217),
(1225, 51, 'ALLURIQUIN', 217),
(1226, 52, 'PUERTO LIMON', 217),
(1227, 53, 'LUZ DE AMERICA', 217),
(1228, 54, 'SAN JACINTO DEL BUA', 217),
(1229, 55, 'VALLE HERMOSO', 217),
(1230, 56, 'EL ESFUERZO', 217),
(1231, 57, 'SANTA MARIA DEL TOACHI', 217),
(1232, 50, 'LA CONCORDIA', 218),
(1233, 51, 'MONTERREY', 218),
(1234, 52, 'LA VILLEGAS', 218),
(1235, 53, 'PLAN PILOTO', 218),
(1236, 1, 'BALLENITA', 219),
(1237, 2, 'SANTA ELENA', 219),
(1238, 51, 'ATAHUALPA', 219),
(1239, 52, 'COLONCHE', 219),
(1240, 53, 'CHANDUY', 219),
(1241, 54, 'MANGLARALTO', 219),
(1242, 55, 'SIMON BOLIVAR (JULIO MORENO)', 219),
(1243, 56, 'SAN JOSE DE ANCON', 219),
(1244, 50, 'LA LIBERTAD', 220),
(1245, 1, 'CARLOS ESPINOZA LARREA', 221),
(1246, 2, 'GENERAL ALBERTO ENRÍQUEZ GALLO', 221),
(1247, 3, 'VICENTE ROCAFUERTE', 221),
(1248, 4, 'SANTA ROSA', 221),
(1249, 51, 'ANCONCITO', 221),
(1250, 52, 'JOSE LUIS TAMAYO (MUEY)', 221);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas_rapidas`
--

CREATE TABLE `preguntas_rapidas` (
  `id_pregunta` int(11) NOT NULL,
  `id_clase` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `tipo` enum('multiple','verdadero_falso','completar') NOT NULL,
  `opcion1` text DEFAULT NULL,
  `opcion2` text DEFAULT NULL,
  `opcion3` text DEFAULT NULL,
  `respuesta` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `preguntas_rapidas`
--

INSERT INTO `preguntas_rapidas` (`id_pregunta`, `id_clase`, `pregunta`, `tipo`, `opcion1`, `opcion2`, `opcion3`, `respuesta`) VALUES
(319, 109, '¿Qué organismo supervisa el seguro de depósitos en la República Dominicana?', 'multiple', 'BANRESERVAS', 'COSEDE', 'PROCONSUMIDOR', 'COSEDE'),
(320, 109, 'El seguro de depósitos cubre cuentas en moneda extranjera.', 'verdadero_falso', 'Verdadero', 'Falso', '', 'Verdadero'),
(321, 109, '¿Cuál es el límite máximo garantizado por el seguro de depósitos por persona y por institución financiera?', 'multiple', 'USD 32 000', 'USD 2 000', 'USD 30 000', 'USD 32 000'),
(322, 109, 'El seguro de depósitos protege a los inversionistas contra pérdidas por fluctuaciones del mercado.', 'verdadero_falso', 'Verdadero', 'Falso', '', 'Falso'),
(323, 109, 'Los depósitos ______ son cubiertos automáticamente por el seguro de la COSEDE.', 'completar', 'a plazo fijo', 'en efectivo', 'electrónicos', 'a plazo fijo'),
(324, 109, '¿Qué tipo de cuenta NO está cubierta por el seguro de depósitos según la normativa actual?', 'multiple', 'Cuentas de ahorros', 'Certificados bancarios', 'Cuentas de inversión', 'Cuentas de inversión'),
(325, 109, 'La COSEDE fue creada mediante la Ley No. 67-__.', 'completar', '04', '05', '06', '06'),
(326, 109, 'El seguro de depósitos aplica únicamente a personas físicas.', 'verdadero_falso', 'Verdadero', 'Falso', '', 'Falso'),
(327, 109, '¿Cuál de estos documentos se requiere para solicitar una indemnización ante la COSEDE?', 'multiple', 'Copia de la cédula', 'Contrato de arrendamiento', 'Recibo de luz', 'Copia de la cédula'),
(328, 109, 'El seguro de depósitos entra en acción cuando una institución financiera está solvente.', 'verdadero_falso', 'Verdadero', 'Falso', '', 'Falso'),
(363, 111, 'El riesgo operacional puede originarse por fallas en procesos  personas  tecnología o eventos externos.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(364, 111, '¿Qué resolución contiene la norma vigente para la administración del   riesgo operativo en el sector financiero popular y solidario en Ecuador?', 'multiple', 'SEPS-IGT-IR-IGJ-2018-0279', 'SEPS-IGT-IGS-INSESF-INR-INGINT-INSEPS-IGJ-0116', 'SEPS-IGT-IGS-INR-INGINT2020-0221', 'SEPS-IGT-IGS-INSESF-INR-INGINT-INSEPS-IGJ-0116'),
(365, 111, '¿Cuál es el riesgo que se evalúa sin aplicar controles?', 'multiple', 'Riesgo residual', 'Riesgo inherente', 'Riesgo externo', 'Riesgo inherente'),
(366, 111, '¿Cuál de las siguientes NO es una etapa del Sistema de Gestión de Riesgo Operativo (SIGRO)?', 'multiple', 'Identificar', 'Medir', 'Financiar', 'Financiar'),
(367, 111, '¿Qué elemento forma parte del SIGRO?', 'multiple', 'Manual contable', 'Estrategias de ventas', 'Políticas y procedimientos', 'Políticas y procedimientos'),
(368, 111, '¿Cuál de los siguientes elementos forma parte del Sistema de Gestión de Riesgo Operativo (SIGRO)?', 'multiple', 'Estrategia publicitaria', 'Capacitación al personal', 'Manual de marketing', 'Capacitación al personal'),
(369, 111, '¿Qué tipo de riesgo se obtiene luego de aplicar los controles adecuados sobre el riesgo identificado?', 'multiple', 'Riesgo inherente', 'Riesgo externo', 'Riesgo residual', 'Riesgo residual'),
(370, 111, '¿Qué etapa del Sistema de Gestión de Riesgo Operativo consiste en observar y analizar la evolución de los riesgos identificados?', 'multiple', 'Controlar', 'Medir', 'Monitorear', 'Monitorear'),
(371, 111, '¿Cuál es el propósito de la etapa “Controlar/Mitigar” en el Sistema de Gestión de Riesgo Operativo (SIGRO)?', 'multiple', 'Identificar los riesgos potenciales antes de que ocurran', 'Realizar auditorías internas sobre los procesos operativos', 'Aplicar controles que reduzcan la probabilidad e impacto de los riesgos', 'Aplicar controles que reduzcan la probabilidad e impacto de los riesgos'),
(372, 111, 'Implementar respaldos periódicos de bases de datos y usar almacenamiento en la nube son acciones propias de la etapa de Controlar/Mitigar dentro del SIGRO', 'verdadero_falso', '', '', '', 'VERDADERO'),
(383, 112, '¿Qué es la Economía Popular y Solidaria?', 'multiple', 'Un sistema financiero internacional', 'Una forma de organización económica basada en la producción colectiva y principios solidarios', 'Un modelo empresarial estatal', 'Una forma de organización económica basada en la producción colectiva y principios solidarios'),
(384, 112, 'La EPS se fundamenta en relaciones basadas en:', 'multiple', 'Competencia y beneficio individual', 'Capital y lucro', 'Solidaridad  cooperación y reciprocidad', 'Solidaridad  cooperación y reciprocidad'),
(385, 112, '¿Cuál de estos principios pertenece a la EPS?', 'multiple', 'Prelación del capital sobre el trabajo', 'Búsqueda del buen vivir y bien común', 'Maximización del beneficio privado', 'Búsqueda del buen vivir y bien común'),
(386, 112, 'La autogestión es un principio de la Economía Popular y Solidaria:', 'verdadero_falso', '', '', '', 'VERDADERO'),
(387, 112, '¿Qué organismo regula y supervisa a las organizaciones de la EPS?', 'multiple', 'Banco Central del Ecuador', 'Superintendencia de Bancos', 'Superintendencia de Economía Popular y Solidaria (SEPS)', 'Superintendencia de Economía Popular y Solidaria (SEPS)'),
(388, 112, '¿Qué promueve la supervisión de la SEPS?', 'multiple', 'Incremento de impuestos', 'Control estatal absoluto', 'Buenas prácticas  transparencia y cumplimiento normativo', 'Buenas prácticas  transparencia y cumplimiento normativo'),
(389, 112, 'Las organizaciones de la EPS no rinden cuentas ni tienen responsabilidad social:', 'verdadero_falso', '', '', '', 'FALSO'),
(390, 112, '¿Qué se prioriza según los principios de la EPS?', 'multiple', 'El capital sobre el trabajo', 'El comercio internacional', 'El trabajo sobre el capital', 'El trabajo sobre el capital'),
(391, 112, 'La Economía Popular y Solidaria es una forma de organización __________ en la que sus integrantes desarrollan procesos para satisfacer necesidades y generar ingresos.', 'completar', '', '', '', 'económica'),
(392, 112, 'La rendición de cuentas y la responsabilidad social son principios fundamentales de la Economía Popular y Solidaria.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(393, 113, '¿Cuál es el órgano máximo de decisión en una cooperativa de la EPS?', 'multiple', 'Consejo de administración', 'Asamblea General', 'Consejo de vigilancia', 'Asamblea General'),
(394, 113, '¿Qué relación tienen los socios con la organización?', 'multiple', 'Solo consumidores de servicios', 'Participan activamente en la toma de decisiones', 'Funcionan como empleados', 'Participan activamente en la toma de decisiones'),
(395, 113, 'Una atribución del Consejo de Administración es:', 'multiple', 'Aprobar los informes de auditoría externa', 'Dirigir y controlar las actividades de la organización', 'Elaborar los presupuestos familiares de los socios', 'Dirigir y controlar las actividades de la organización'),
(396, 113, '¿Cuál es la principal función del Consejo de Vigilancia?', 'multiple', 'Fiscalizar el cumplimiento de normas y decisiones', 'Representar legalmente a la cooperativa', 'Ejecutar las actividades operativas', 'Fiscalizar el cumplimiento de normas y decisiones'),
(397, 113, 'El gerente de una cooperativa es responsable de:', 'multiple', 'Emitir leyes internas', 'Ejecutar las decisiones del Consejo de Administración', 'Elegir a los vocales de la asamblea', 'Ejecutar las decisiones del Consejo de Administración'),
(398, 113, 'Las comisiones especiales tienen como finalidad:', 'multiple', 'Ejecutar los pagos', 'Apoyar funciones específicas determinadas por los órganos de dirección', 'Fiscalizar la gestión financiera', 'Apoyar funciones específicas determinadas por los órganos de dirección'),
(399, 113, 'En las asociaciones  el equivalente a la Asamblea General de una cooperativa es:', 'multiple', 'La junta de vigilancia', 'La Junta General', 'La Junta Directiva', 'La Junta General'),
(400, 113, '¿Qué funciones cumple el administrador en una asociación?', 'multiple', 'Ejecutar decisiones y representar a la organización', 'Controlar las decisiones de los socios', 'Recaudar fondos externos', 'Ejecutar decisiones y representar a la organización'),
(401, 113, 'Podrán ser socios las personas naturales legalmente capaces o las personas jurídicas que cumplan con el vínculo __________ y los requisitos establecidos en el reglamento de la LOEPS y en el estatuto social de la organización.', 'completar', '', '', '', 'común'),
(402, 113, 'La participación activa  el respeto a las decisiones colectivas y la promoción de la transparencia fortalecen el cumplimiento de normas internas y el funcionamiento democrático de las organizaciones de la EPS.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(403, 114, '¿Cuál es el objetivo principal del buen gobierno cooperativo?', 'multiple', 'Aumentar las ganancias de los socios', 'Cumplir metas comerciales anuales', 'Promover una gestión ética  participativa y transparente', 'Promover una gestión ética  participativa y transparente'),
(404, 114, '¿Qué significa gobernabilidad en una cooperativa?', 'multiple', 'Imposición de normas sin participación', 'Control absoluto del consejo de administración', 'Capacidad de tomar decisiones legítimas  transparentes y participativas', 'Capacidad de tomar decisiones legítimas  transparentes y participativas'),
(405, 114, '¿Cuál de estos es un principio del buen gobierno cooperativo?', 'multiple', 'Centralización de poder', 'Control financiero total del gerente', 'Transparencia en la toma de decisiones', 'Transparencia en la toma de decisiones'),
(406, 114, '¿Qué órgano garantiza la participación democrática dentro de una cooperativa?', 'multiple', 'El gerente', 'La Asamblea General', 'El Consejo de Vigilancia', 'La Asamblea General'),
(407, 114, '¿Cuál de las siguientes opciones representa una causa que limita una buena gobernabilidad?', 'multiple', 'Capacitación continua', 'Participación activa', 'Confusión de roles y funciones', 'Confusión de roles y funciones'),
(408, 114, 'La estructura organizativa de una cooperativa permite:', 'multiple', 'Reducir el número de socios', 'Obtener financiamiento estatal', 'Establecer responsabilidades claras y eficaces', 'Establecer responsabilidades claras y eficaces'),
(409, 114, '¿Qué se entiende por liderazgo ético?', 'multiple', 'Imposición de normas desde la dirección', 'Control interno sobre los empleados', 'Coherencia entre los valores  decisiones y acciones del líder', 'Coherencia entre los valores  decisiones y acciones del líder'),
(410, 114, '¿Qué función cumple la normativa de base en el gobierno cooperativo?', 'multiple', 'Elimina derechos de los socios', 'Otorga autonomía ilimitada al gerente', 'Establece reglas para la participación y toma de decisiones', 'Establece reglas para la participación y toma de decisiones'),
(411, 114, '¿Cuál de las siguientes prácticas refleja una buena gobernanza?', 'multiple', 'Ocultamiento de decisiones estratégicas', 'Rendir cuentas a los socios', 'Concentración de poder en la presidencia', 'Rendir cuentas a los socios'),
(412, 114, '¿Qué aspecto es clave para aplicar la gobernabilidad en una cooperativa?', 'multiple', 'Excluir a los socios de las decisiones', 'Promover el acceso a la información y participación activa', 'Limitar las reuniones de trabajo', 'Promover el acceso a la información y participación activa'),
(413, 115, '¿Cuál es el objetivo principal del Balance Social en una cooperativa?', 'multiple', 'Calcular utilidades anuales', 'Evaluar el impacto social y la gestión ética de la cooperativa', 'Estimar el capital de trabajo', 'Evaluar el impacto social y la gestión ética de la cooperativa'),
(414, 115, 'El Balance Social permite principalmente:', 'multiple', 'Realizar auditorías tributarias', 'Rendir cuentas a la sociedad y fomentar la transparencia', 'Crear campañas publicitarias', 'Rendir cuentas a la sociedad y fomentar la transparencia'),
(415, 115, '¿Qué normativa respalda la elaboración del Balance Social?', 'multiple', 'Código de Comercio', 'Ley de Sociedades Anónimas', 'Constitución del Ecuador y la LOEPS', 'Constitución del Ecuador y la LOEPS'),
(416, 115, '¿Cuál de estos es un beneficio del Balance Social?', 'multiple', 'Reducir la participación de socios', 'Fortalecer la legitimidad institucional', 'Eliminar responsabilidades del consejo', 'Fortalecer la legitimidad institucional'),
(417, 115, 'El informe del Balance Social debe elaborarse:', 'multiple', 'Cuando lo solicite la Superintendencia de Bancos', 'De forma periódica conforme a la normativa vigente', 'Solo si hay utilidades', 'De forma periódica conforme a la normativa vigente'),
(418, 115, 'El comité de gestión del Balance Social es responsable únicamente de tareas administrativas.', 'verdadero_falso', '', '', '', 'FALSO'),
(419, 115, '¿Cuál de los siguientes órganos tiene atribuciones en el Art. 12 para supervisar la gestión del Balance Social?', 'multiple', 'Asamblea General', 'Consejo de Administración', 'Junta de Revisión', 'Consejo de Administración'),
(420, 115, 'El responsable del Balance Social dentro de la cooperativa debe:', 'multiple', 'Coordinar y ejecutar el proceso técnico de elaboración del balance', 'Auditar los libros contables', 'Elaborar informes legales', 'Coordinar y ejecutar el proceso técnico de elaboración del balance'),
(421, 115, '¿Qué principio del cooperativismo está directamente relacionado con la rendición de cuentas?', 'multiple', 'Educación y formación', 'Responsabilidad social', 'Interés por la comunidad', 'Responsabilidad social'),
(422, 115, '¿Cuál de estos documentos sirve de guía para la gestión del Balance Social?', 'multiple', 'Reglamento Interno de Trabajo', 'Manual de metodología del Balance Social', 'Plan Estratégico Comercial', 'Manual de metodología del Balance Social'),
(423, 116, '¿Qué es el control interno en una organización?', 'multiple', 'Un sistema para sancionar a los empleados', 'Un reglamento exclusivo para contabilidad', 'Un proceso diseñado para brindar seguridad razonable sobre el cumplimiento de objetivos', 'Un proceso diseñado para brindar seguridad razonable sobre el cumplimiento de objetivos'),
(424, 116, '¿Cuál es uno de los objetivos del control interno?', 'multiple', 'Maximizar las utilidades', 'Garantizar la eficiencia operativa  confiabilidad financiera y cumplimiento normativo', 'Eliminar la participación de los socios', 'Garantizar la eficiencia operativa  confiabilidad financiera y cumplimiento normativo'),
(425, 116, 'El autocontrol implica:', 'multiple', 'La supervisión constante de la SEPS', 'Que solo el gerente revise los procesos', 'La responsabilidad individual de cumplir procedimientos y normas', 'La responsabilidad individual de cumplir procedimientos y normas'),
(426, 116, 'Uno de los componentes del control interno es el ambiente interno.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(427, 116, '¿Qué actividad pertenece a la gestión y evaluación de riesgos?', 'multiple', 'Pago de planillas', 'Identificación y análisis de posibles eventos que puedan afectar los objetivos', 'Auditoría externa', 'Identificación y análisis de posibles eventos que puedan afectar los objetivos'),
(428, 116, '¿Qué componente del control interno se relaciona con garantizar que la información fluya adecuadamente?', 'multiple', 'Actividades de control', 'Evaluación de riesgos', 'Información y comunicación', 'Información y comunicación'),
(429, 116, 'El seguimiento dentro del control interno se realiza a través de:', 'multiple', 'Un proceso político', 'Control de socios', 'Evaluaciones periódicas y monitoreo continuo', 'Evaluaciones periódicas y monitoreo continuo'),
(430, 116, '¿Cuál de los siguientes es un ejemplo de actividad de control?', 'multiple', 'Separación de funciones entre áreas operativas y contables', 'Elaboración del presupuesto nacional', 'Emisión de créditos por el consejo de vigilancia', 'Separación de funciones entre áreas operativas y contables'),
(431, 116, 'El control interno también aplica en la administración de talento humano para:', 'multiple', 'Aumentar sanciones disciplinarias', 'Establecer procesos claros de ingreso  evaluación y promoción', 'Aumentar la carga de trabajo', 'Establecer procesos claros de ingreso  evaluación y promoción'),
(432, 116, 'En los sistemas de información computarizados  el control interno debe:', 'multiple', 'Permitir el acceso libre a todos los usuarios', 'Garantizar integridad  confidencialidad y disponibilidad de los datos', 'Evitar el uso de contraseñas', 'Garantizar integridad  confidencialidad y disponibilidad de los datos'),
(433, 117, '¿Cuál es el órgano supremo de decisión en una cooperativa según el procedimiento parlamentario?', 'multiple', 'Gerencia', 'Asamblea General', 'Consejo de Vigilancia', 'Asamblea General'),
(434, 117, '¿Cuál es el documento que debe contener expresamente los puntos a tratar en la asamblea?', 'multiple', 'Acta anterior', 'Convocatoria', 'Presupuesto anual', 'Convocatoria'),
(435, 117, '¿Qué se requiere para que una asamblea general sea válida?', 'multiple', 'Voto del presidente', 'Quórum legal reglamentario', 'Publicación en medios', 'Quórum legal reglamentario'),
(436, 117, '¿Cuántos días tiene un socio para impugnar una resolución de la asamblea?', 'multiple', '3 días', '10 días', '5 días', '5 días'),
(437, 117, '¿Qué institución puede dejar sin efecto una resolución si no se cumple el procedimiento?', 'multiple', 'Gerencia', 'Asamblea de Representantes', 'Superintendencia de Economía Popular y Solidaria', 'Superintendencia de Economía Popular y Solidaria'),
(438, 117, '¿Cuál de estas NO es una causa para la nulidad de una resolución de asamblea?', 'multiple', 'Ausencia de quórum', 'Incumplimiento del orden del día', 'Opinión del gerente', 'Opinión del gerente'),
(439, 117, '¿Qué tipo de sesión puede convocar el Consejo de Administración?', 'multiple', 'Solo sesiones ordinarias', 'Sesiones ordinarias y extraordinarias', 'Solo sesiones privadas', 'Sesiones ordinarias y extraordinarias'),
(440, 117, '¿Qué debe incluir el acta de una sesión o asamblea?', 'multiple', 'Opiniones generales', 'Fecha  hora  lugar  orden del día  resoluciones y firmas', 'Comentarios de los socios', 'Fecha  hora  lugar  orden del día  resoluciones y firmas'),
(441, 117, '¿Qué se debe hacer con las actas aprobadas?', 'multiple', 'Enviarlas a los socios por correo', 'Archivarlas correctamente para consulta y fiscalización', 'Publicarlas en redes sociales', 'Archivarlas correctamente para consulta y fiscalización'),
(442, 117, 'La convocatoria a una asamblea debe contener el orden del día y ser comunicada en los plazos establecidos.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(443, 118, '¿Cuál es una de las funciones principales del Consejo de Administración en una cooperativa?', 'multiple', 'Establecer el salario de los socios', 'Diseñar el curso estratégico de la institución', 'Ejecutar operaciones diarias', 'Diseñar el curso estratégico de la institución'),
(444, 118, '¿Qué documento regula la conducta ética de todos los actores de la cooperativa?', 'multiple', 'Manual financiero', 'Estatuto de crédito', 'Código de Ética y Comportamiento', 'Código de Ética y Comportamiento'),
(445, 118, '¿Cuál de los siguientes es un principio cooperativo?', 'multiple', 'Autonomía e independencia', 'Centralización del poder', 'Rentabilidad financiera absoluta', 'Autonomía e independencia'),
(446, 118, '¿Qué se prohíbe a los directivos para evitar conflictos de interés?', 'multiple', 'Recibir capacitación financiera', 'Recibir regalos o favores a cambio de servicios', 'Asistir a reuniones internas', 'Recibir regalos o favores a cambio de servicios'),
(447, 118, 'La transparencia en la gestión incluye:', 'multiple', 'Ocultar balances y estados financieros', 'Capacitar únicamente a los gerentes', 'Publicar información financiera y operativa a los socios', 'Publicar información financiera y operativa a los socios'),
(448, 118, '¿Qué ocurre si un directivo divulga información institucional sin autorización?', 'multiple', 'Recibe una capacitación extra', 'Se le felicita por su iniciativa', 'Se considera falta grave y causal de remoción', 'Se considera falta grave y causal de remoción'),
(449, 118, '¿Cuál de estas acciones vulnera el principio de control democrático?', 'multiple', 'Un socio un voto', 'Participación de todos los socios', 'Imposición de decisiones por parte del gerente', 'Imposición de decisiones por parte del gerente'),
(450, 118, 'La participación económica de los socios se refleja en:', 'multiple', 'Aportes sin control ni seguimiento', 'Contribución y control democrático del capital', 'Reparto desigual de utilidades', 'Contribución y control democrático del capital'),
(451, 118, 'El incumplimiento del deber de confidencialidad no tiene consecuencias dentro de la cooperativa.', 'verdadero_falso', '', '', '', 'FALSO'),
(452, 118, 'El código de ética tiene como fin institucionalizar principios de actuación profesional dentro de la cooperativa.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(453, 120, '¿Qué principio guía la responsabilidad social cooperativa según la Ley Orgánica de Economía Popular y Solidaria?', 'multiple', 'Rentabilidad financiera', 'Competencia económica', 'Solidaridad y rendición de cuentas', 'Solidaridad y rendición de cuentas'),
(454, 120, 'Uno de los impactos del compromiso comunitario de la cooperativa es:', 'multiple', 'Exclusión de proveedores internacionales', 'Desvinculación del gobierno', 'Promoción del comercio justo', 'Promoción del comercio justo'),
(455, 120, '¿Cuál de los siguientes es un valor corporativo de las cooperativas?', 'multiple', 'Rivalidad', 'Rentabilidad personal', 'Honestidad', 'Honestidad'),
(456, 120, '¿Qué se promueve mediante la membresía abierta y voluntaria?', 'multiple', 'Discriminación positiva por clase social', 'Inclusión sin distinción de género  raza o religión', 'Restricción territorial del socio', 'Inclusión sin distinción de género  raza o religión'),
(457, 120, '¿Qué función tiene la educación financiera en las cooperativas?', 'multiple', 'Recaudar más capital', 'Reemplazar los servicios contables', 'Asesorar y mejorar la calidad de vida del socio', 'Asesorar y mejorar la calidad de vida del socio'),
(458, 120, 'La responsabilidad social busca que las operaciones sean sustentables solo en lo económico.', 'verdadero_falso', '', '', '', 'FALSO'),
(459, 120, 'El aprendizaje cooperativo implica que los miembros confíen y se apoyen mutuamente para lograr metas.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(460, 120, 'La ética dentro de la cooperativa se basa en valores como igualdad  diálogo y respeto.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(461, 120, 'Las cooperativas no deben establecer vínculos con gobiernos locales ni con sus comunidades.', 'verdadero_falso', '', '', '', 'FALSO'),
(462, 120, 'Uno de los beneficios del trabajo en red entre cooperativas es la reducción de costos y aumento de productividad.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(463, 121, '¿Cuál es el máximo órgano de gobierno en una cooperativa?', 'multiple', 'Consejo de administración', 'Gerencia general', 'Asamblea General', 'Asamblea General'),
(464, 121, '¿Qué principio rige la votación en las asambleas generales?', 'multiple', 'Un voto por cada aporte económico', 'Un voto por persona sin importar el monto de aportación', 'Voto proporcional a la antigüedad', 'Un voto por persona sin importar el monto de aportación'),
(465, 121, '¿Qué documento regula los derechos y obligaciones de los socios?', 'multiple', 'Informe de gestión anual', 'Estatuto social y reglamentos internos', 'Presupuesto aprobado', 'Estatuto social y reglamentos internos'),
(466, 121, '¿Cuál de los siguientes no corresponde a una etapa de la convocatoria a asamblea?', 'multiple', 'Etapa previa', 'Etapa electoral nacional', 'Etapa concurrente', 'Etapa electoral nacional'),
(467, 121, '¿Qué debe considerarse en una asamblea virtual?', 'multiple', 'Registro notariado de cada socio', 'Eliminación del acta final', 'Especificación del tipo de votación (abierta o secreta)', 'Especificación del tipo de votación (abierta o secreta)'),
(468, 121, 'La Asamblea General está integrada solo por el consejo de administración.', 'verdadero_falso', '', '', '', 'FALSO'),
(469, 121, 'Las resoluciones de la Asamblea General son de cumplimiento obligatorio para todos los socios.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(470, 121, 'La Asamblea General de Representantes es un tipo de asamblea previsto para ciertos casos.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(471, 121, 'En una asamblea presencial  no se requiere quórum para su instalación.', 'verdadero_falso', '', '', '', 'FALSO'),
(472, 121, 'Las convocatorias a la asamblea pueden realizarse por medios físicos o virtuales según normativa.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(473, 122, '¿Cuál es el objetivo principal del Fondo de Seguro de Depósitos?', 'multiple', 'Proteger los ahorros de los depositantes', 'Garantizar los préstamos interbancarios', 'Financiar proyectos del gobierno', 'Proteger los ahorros de los depositantes'),
(474, 122, '¿Cuál es el monto máximo de cobertura para las cooperativas de segmento 4?', 'multiple', '$1.000', '$5.000', '$32.000', '$1.000'),
(475, 122, 'El Fondo de Seguro de Depósitos es administrado por la Superintendencia de Bancos.', 'verdadero_falso', 'Verdadero', 'FALSO', '', 'FALSO'),
(476, 122, 'Las cooperativas de ahorro y crédito están obligadas a contribuir al Fondo de Seguro de Depósitos.', 'verdadero_falso', 'Verdadero', 'FALSO', '', 'Verdadero'),
(477, 122, 'El FSD garantiza el reembolso de los depósitos en caso de __________ de la institución financiera.', 'completar', 'quiebra', 'cierre', 'fusión', 'quiebra'),
(478, 122, '¿Qué instituciones están cubiertas por el Fondo de Seguro de Depósitos?', 'multiple', 'Bancos y cooperativas', 'Solo bancos', 'Solo cooperativas', 'Bancos y cooperativas'),
(479, 122, 'El Fondo de Seguro de Depósitos cubre todos los depósitos sin importar su origen.', 'verdadero_falso', 'Verdadero', 'FALSO', '', 'FALSO'),
(480, 122, 'El límite de cobertura para bancos es de __________ dólares por depositante.', 'completar', '32.000', '20.000', '50.000', '32.000'),
(481, 122, '¿Qué evento activa la cobertura del Fondo de Seguro de Depósitos?', 'multiple', 'El cierre voluntario de una cooperativa', 'La intervención por parte del organismo de control', 'La fusión con otra entidad', 'La intervención por parte del organismo de control'),
(482, 122, 'El seguro de depósitos en Ecuador se activa de forma automática al tener una cuenta en una entidad regulada.', 'verdadero_falso', 'Verdadero', 'FALSO', '', 'Verdadero'),
(483, 123, '¿Cuál es la entidad que regula a las aseguradoras privadas en Ecuador?', 'multiple', 'Superintendencia de Bancos', 'Superintendencia de Compañías', 'COSEDE', 'Superintendencia de Compañías'),
(484, 123, 'Las aseguradoras privadas están autorizadas a emitir pólizas de vida.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(485, 123, 'Complete: El contrato entre aseguradora y asegurado se llama ______.', 'completar', 'póliza', 'garantía', 'obligación', 'póliza'),
(486, 123, '¿Cuál de los siguientes seguros es obligatorio por ley en Ecuador?', 'multiple', 'Seguro de salud', 'Seguro de vida', 'SOAT (vehicular)', 'SOAT (vehicular)'),
(487, 123, 'Las aseguradoras privadas no pueden operar sin autorización legal.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(488, 123, 'Complete: El beneficiario de un seguro de vida es quien ______.', 'completar', 'recibe la indemnización', 'firma el contrato', 'paga la prima', 'recibe la indemnización'),
(489, 123, '¿Qué documento describe las condiciones  coberturas y exclusiones del seguro?', 'multiple', 'Factura', 'Póliza', 'Certificado de afiliación', 'Póliza'),
(490, 123, 'El asegurado debe pagar una prima para mantener vigente su póliza.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(491, 123, 'Complete: Una exclusión en un seguro es una ______ de cobertura.', 'completar', 'limitación', 'ampliación', 'renovación', 'limitación'),
(492, 123, '¿Qué tipo de seguro protege al asegurado frente a daños materiales o pérdidas físicas?', 'multiple', 'Seguro patrimonial', 'Seguro de salud', 'Seguro de vida', 'Seguro patrimonial'),
(493, 124, '¿Cuál es el objetivo principal del COSEDE?', 'multiple', 'Proteger a los bancos', 'Proteger los depósitos de los socios', 'Fiscalizar a las cooperativas', 'Proteger los depósitos de los socios'),
(494, 124, 'El COSEDE cubre los depósitos hasta un monto máximo por persona.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(495, 124, 'El Seguro de Depósitos aplica solo a bancos privados.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'FALSO'),
(496, 124, 'La cobertura del Seguro de Depósitos es de hasta:', 'multiple', 'USD 10.000', 'USD 32.000', 'USD 50.000', 'USD 32.000'),
(497, 124, 'El fondo del COSEDE se financia con:', 'multiple', 'Impuestos del Estado', 'Aportes de las entidades financieras', 'Préstamos internacionales', 'Aportes de las entidades financieras'),
(498, 124, 'El Seguro de Depósitos aplica automáticamente sin necesidad de inscripción previa del depositante.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(499, 124, 'Cuando una entidad entra en liquidación  el COSEDE...', 'completar', '...devuelve los ahorros a los socios hasta el límite asegurado.', '...vende los activos de la entidad.', '...inicia una auditoría completa.', '...devuelve los ahorros a los socios hasta el límite asegurado.'),
(500, 124, '¿Qué institución administra el Fondo del Seguro de Depósitos en Ecuador?', 'multiple', 'Banco Central del Ecuador', 'COSEDE', 'SEPS', 'COSEDE'),
(501, 124, 'El Seguro de Depósitos cubre cuentas corrientes  de ahorro y depósitos a plazo.', 'verdadero_falso', 'VERDADERO', 'FALSO', '', 'VERDADERO'),
(502, 124, 'Si un socio tiene cuentas en varias entidades  la cobertura del COSEDE...', 'completar', '...se aplica de manera independiente por cada entidad.', '...se acumula en una sola cobertura.', '...solo aplica en bancos.', '...se aplica de manera independiente por cada entidad.'),
(503, 125, '¿Cuál es el objetivo principal del proceso de calificación de idoneidad?', 'multiple', 'Designar suplentes para los vocales del consejo', 'Elegir a los socios con mayor antigüedad', 'Garantizar que los administradores y vocales cumplan con requisitos técnicos y éticos', 'Garantizar que los administradores y vocales cumplan con requisitos técnicos y éticos'),
(504, 125, '¿Quién emite la normativa que regula la calificación de idoneidad en las cooperativas del sector EPS?', 'multiple', 'Ministerio de Trabajo', 'Asamblea Nacional', 'Superintendencia de Economía Popular y Solidaria (SEPS)', 'Superintendencia de Economía Popular y Solidaria (SEPS)'),
(505, 125, '¿Cuál de los siguientes documentos es obligatorio para calificar la idoneidad?', 'multiple', 'Copia del RUC de la entidad', 'Declaración juramentada de no inhabilitación', 'Constancia de votación de los socios', 'Declaración juramentada de no inhabilitación'),
(506, 125, '¿Qué ocurre si un vocal no cumple con la capacitación posterior a su calificación?', 'multiple', 'No hay consecuencias legales', 'Puede ser removido del cargo', 'Solo se emite una advertencia verbal', 'Puede ser removido del cargo'),
(507, 125, '¿Qué plazo tienen las cooperativas para registrar la información de sus representantes una vez designados?', 'multiple', '60 días hábiles', 'No hay plazo establecido', '15 días hábiles', '15 días hábiles'),
(508, 125, 'Todos los segmentos del sector financiero popular y solidario deben cumplir con el proceso de calificación de idoneidad.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(509, 125, 'La experiencia profesional no es considerada en el análisis de idoneidad.', 'verdadero_falso', '', '', '', 'FALSO'),
(510, 125, 'Una persona puede calificar como vocal aunque tenga inhabilidades legales vigentes.', 'verdadero_falso', '', '', '', 'FALSO'),
(511, 125, 'La capacitación es obligatoria solo para los vocales principales  no para los suplentes.', 'verdadero_falso', '', '', '', 'FALSO'),
(512, 125, 'El cumplimiento normativo fortalece la transparencia y la gestión institucional.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(513, 126, '¿Cuál es la primera etapa del proceso electoral en una cooperativa?', 'multiple', 'Etapa posterior', 'Etapa concurrente', 'Etapa previa', 'Etapa previa'),
(514, 126, '¿Qué documento debe leerse el mismo día de la elección de vocales?', 'multiple', 'Reglamento interno', 'Manual de funciones', 'Acta de la sesión de la asamblea/junta', 'Acta de la sesión de la asamblea/junta'),
(515, 126, '¿Qué órgano realiza la elección de los vocales?', 'multiple', 'Gerencia general', 'Asamblea o Junta General', 'Comité de ética', 'Asamblea o Junta General'),
(516, 126, '¿Qué medio puede utilizarse para convocar a una asamblea virtual?', 'multiple', 'Solo correo postal', 'Llamada telefónica', 'Correos electrónicos o medios institucionales digitales', 'Correos electrónicos o medios institucionales digitales'),
(517, 126, '¿Cuál es la función del formulario de registro total o parcial?', 'multiple', 'Revisión contable', 'Formalizar la designación de los vocales ante la SEPS', 'Realizar encuestas', 'Formalizar la designación de los vocales ante la SEPS'),
(518, 126, 'La asamblea virtual debe cumplir las mismas condiciones legales que una presencial.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(519, 126, 'La lectura del acta se puede realizar hasta 10 días después de la elección.', 'verdadero_falso', '', '', '', 'FALSO'),
(520, 126, 'Solo los socios fundadores pueden participar en la elección de vocales.', 'verdadero_falso', '', '', '', 'FALSO'),
(521, 126, 'El desarrollo del proceso electoral debe garantizar transparencia  legalidad y participación democrática.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(522, 126, 'Las etapas del proceso electoral deben cumplirse en orden cronológico.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(523, 127, '¿Quién representa legalmente a la cooperativa ante terceros?', 'multiple', 'El Consejo de Vigilancia', 'El Representante Legal', 'El Auditor Externo', 'El Representante Legal'),
(524, 127, '¿Qué función NO corresponde al Representante Legal?', 'multiple', 'Firmar contratos', 'Representar judicial y extrajudicialmente a la cooperativa', 'Fiscalizar los estados financieros', 'Fiscalizar los estados financieros'),
(525, 127, 'El Representante Legal debe:', 'multiple', 'Aprobar los estados financieros sin intervención del Consejo', 'Cumplir y hacer cumplir las decisiones de los órganos de gobierno', 'Delegar funciones sin autorización', 'Cumplir y hacer cumplir las decisiones de los órganos de gobierno'),
(526, 127, '¿Cuál de estas es una atribución del Consejo de Administración?', 'multiple', 'Aprobar el plan estratégico y operativo de la cooperativa', 'Realizar auditorías externas', 'Supervisar directamente a los socios', 'Aprobar el plan estratégico y operativo de la cooperativa'),
(527, 127, '¿Qué órgano aprueba y supervisa el cumplimiento del presupuesto institucional?', 'multiple', 'Representante Legal', 'Consejo de Administración', 'Comité de Vigilancia', 'Consejo de Administración'),
(528, 127, 'El Consejo de Administración tiene como responsabilidad:', 'multiple', 'Reemplazar al Representante Legal sin asamblea', 'Convocar elecciones internas', 'Asegurar la ejecución de planes y políticas institucionales', 'Asegurar la ejecución de planes y políticas institucionales'),
(529, 127, 'El Consejo de Vigilancia está encargado de:', 'multiple', 'Fiscalizar la gestión del Consejo de Administración y del Representante Legal', 'Coordinar con la Superintendencia reuniones internas', 'Aprobar el reglamento laboral', 'Fiscalizar la gestión del Consejo de Administración y del Representante Legal'),
(530, 127, '¿Cuál es una de las funciones del Consejo de Vigilancia?', 'multiple', 'Elaborar el presupuesto', 'Dirigir los comités de crédito', 'Proponer la terna para auditor interno y externo', 'Proponer la terna para auditor interno y externo'),
(531, 127, '¿Quién informa sobre riesgos que pueden afectar a la cooperativa?', 'multiple', 'Representante Legal', 'Consejo de Administración', 'Consejo de Vigilancia', 'Consejo de Vigilancia'),
(532, 127, 'El Consejo de Vigilancia puede emitir opinión sobre la razonabilidad de los estados financieros.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(533, 128, '¿Quién presenta el plan estratégico y el plan operativo al Consejo de Administración?', 'multiple', 'Asamblea General', 'Gerencia o responsable técnico', 'Consejo de Vigilancia', 'Gerencia o responsable técnico'),
(534, 128, '¿Hasta qué fecha se debe presentar el plan operativo anual y su presupuesto para el siguiente ejercicio?', 'multiple', '31 de diciembre', '1 de enero', '30 de noviembre', '30 de noviembre'),
(535, 128, '¿Cuál es el propósito del plan estratégico?', 'multiple', 'Determinar únicamente los gastos anuales', 'Establecer actividades rutinarias', 'Definir la visión  misión  objetivos y estrategias de largo plazo', 'Definir la visión  misión  objetivos y estrategias de largo plazo'),
(536, 128, 'La visión de una organización responde a:', 'multiple', '¿Quiénes son nuestros clientes?', '¿Qué valores tenemos?', '¿Qué queremos ser en el futuro?', '¿Qué queremos ser en el futuro?'),
(537, 128, '¿Cuál de estos elementos forma parte del análisis FODA?', 'multiple', 'Plan de compras', 'Programación anual', 'Fortalezas', 'Fortalezas'),
(538, 128, '¿Qué representan los indicadores dentro del plan estratégico?', 'multiple', 'Los nombres de los responsables', 'Las expresiones cuantitativas del desempeño', 'Las actividades sociales', 'Las expresiones cuantitativas del desempeño'),
(539, 128, '¿Qué son las metas dentro de la planificación?', 'multiple', 'Actividades presupuestarias', 'Valores deseados para un indicador en un tiempo determinado', 'Costos máximos', 'Valores deseados para un indicador en un tiempo determinado'),
(540, 128, 'El plan operativo anual se centra en:', 'multiple', 'Gastos históricos', 'Acciones concretas que se ejecutarán durante un año para alcanzar objetivos específicos', 'Créditos de emergencia', 'Acciones concretas que se ejecutarán durante un año para alcanzar objetivos específicos'),
(541, 128, '¿Qué elemento NO forma parte del contenido del plan operativo?', 'multiple', 'Objetivo general', 'Actividades y metas', 'Reglamento interno de socios', 'Reglamento interno de socios'),
(542, 128, 'El presupuesto debe estar alineado al plan operativo y reflejar los recursos necesarios para cumplir las metas.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(543, 129, '¿Cuál es uno de los valores corporativos promovidos por la Cooperativa?', 'multiple', 'Competencia', 'Honestidad', 'Ambición', 'Honestidad'),
(544, 129, '¿Qué principio cooperativo se relaciona con la toma de decisiones democrática?', 'multiple', 'Cooperación entre cooperativas', 'Control democrático de los miembros', 'Autonomía financiera', 'Control democrático de los miembros'),
(545, 129, '¿Cuál es el órgano que conoce los conflictos de interés en la Cooperativa?', 'multiple', 'Gerencia General', 'Comisión Especial de Resolución de Conflictos', 'Consejo de Vigilancia', 'Comisión Especial de Resolución de Conflictos'),
(546, 129, '¿Qué práctica es considerada un acto censurable?', 'multiple', 'Asistir a capacitaciones institucionales', 'Informar conflictos de interés', 'Utilizar el nombre de la cooperativa para beneficios personales', 'Utilizar el nombre de la cooperativa para beneficios personales'),
(547, 129, '¿Cuál de las siguientes es una prohibición para trabajadores y directivos?', 'multiple', 'Participar en capacitaciones', 'Ofrecer servicios a empresas competidoras', 'Colaborar con los socios', 'Ofrecer servicios a empresas competidoras'),
(548, 129, 'La cortesía  la ética y la comunicación efectiva son pilares de la cultura organizacional.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(549, 129, 'Los trabajadores pueden gestionar créditos en base a información falsa si benefician a un socio.', 'verdadero_falso', '', '', '', 'FALSO'),
(550, 129, 'Los principios cooperativos permiten poner en práctica los valores institucionales.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(551, 129, 'Es permitido a los trabajadores intervenir en procesos judiciales que ellos mismos hayan gestionado.', 'verdadero_falso', '', '', '', 'FALSO'),
(552, 129, 'Los actos contrarios a la ética pueden generar sanciones administrativas  civiles o penales.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(553, 130, '¿Qué ley regula a las organizaciones de la Economía Popular y Solidaria en Ecuador?', 'multiple', 'Ley de Compañías', 'Código Orgánico Monetario y Financiero', 'Ley Orgánica de Economía Popular y Solidaria', 'Ley Orgánica de Economía Popular y Solidaria'),
(554, 130, '¿Cuál de los siguientes NO es un principio de la Economía Popular y Solidaria?', 'multiple', 'Autogestión', 'Maximización del lucro', 'Solidaridad', 'Maximización del lucro'),
(555, 130, '¿Cuál es una diferencia principal entre la empresa privada y las organizaciones de EPS?', 'multiple', 'Ambas se enfocan en maximizar el beneficio individual', 'Las organizaciones EPS priorizan el bienestar colectivo', 'Las EPS tienen como fin la especulación financiera', 'Las organizaciones EPS priorizan el bienestar colectivo'),
(556, 130, '¿Qué tipo de organización está reconocida por la LOEPS?', 'multiple', 'Empresa unipersonal', 'Sociedad anónima', 'Cooperativa de ahorro y crédito', 'Cooperativa de ahorro y crédito'),
(557, 130, '¿Qué sucede cuando un socio pierde su calidad dentro de una cooperativa?', 'multiple', 'Se le impone una multa', 'Tiene derecho a la liquidación de haberes', 'Se le otorgan beneficios especiales', 'Tiene derecho a la liquidación de haberes'),
(558, 130, 'La Economía Popular y Solidaria promueve la participación democrática en la toma de decisiones.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(559, 130, 'Los socios de una cooperativa pueden transferir libremente sus derechos sin autorización.', 'verdadero_falso', '', '', '', 'FALSO'),
(560, 130, 'La relación del socio con la organización implica derechos y obligaciones mutuos.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(561, 130, 'Las asociaciones reconocidas por la LOEPS no tienen personalidad jurídica.', 'verdadero_falso', '', '', '', 'FALSO'),
(562, 130, 'La Economía Popular y Solidaria es una forma de organización __________   en la que sus integrantes  de manera individual o colectivamente  desarrollan procesos de producción  intercambio  comercialización  financiamiento y consumo de bienes y servicios.', 'completar', '', '', '', 'económica'),
(563, 131, '¿Qué es la planificación financiera?', 'multiple', 'Una forma de evitar gastos', 'Una herramienta para administrar recursos y alcanzar metas', 'Un sistema de ahorro obligatorio', 'Una herramienta para administrar recursos y alcanzar metas'),
(564, 131, '¿Cuál de las siguientes opciones es un gasto hormiga?', 'multiple', 'Pago de arriendo', 'Compra mensual de alimentos', 'Café diario comprado fuera de casa', 'Café diario comprado fuera de casa'),
(565, 131, '¿Qué es el crédito?', 'multiple', 'Un contrato mediante el cual se presta dinero con obligación de devolución', 'Un subsidio que no requiere devolución', 'Una forma de ahorro programado', 'Un contrato mediante el cual se presta dinero con obligación de devolución'),
(566, 131, '¿Cuál es la diferencia entre ahorrar e invertir?', 'multiple', 'Ahorrar es gastar menos  invertir es endeudarse', 'Ahorrar es guardar dinero  invertir es usarlo para generar ganancias', 'No hay diferencia  son lo mismo', 'Ahorrar es guardar dinero  invertir es usarlo para generar ganancias'),
(567, 131, '¿Por qué es importante elaborar un presupuesto?', 'multiple', 'Para comprar más productos', 'Para dejar de ahorrar', 'Para conocer ingresos  gastos y planificar el ahorro', 'Para conocer ingresos  gastos y planificar el ahorro'),
(568, 131, 'El ahorro debe formar parte del presupuesto mensual.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(569, 131, 'Los ingresos incluyen únicamente los sueldos mensuales.', 'verdadero_falso', '', '', '', 'FALSO'),
(570, 131, 'Endeudarse responsablemente significa conocer las condiciones del crédito antes de aceptarlo.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(571, 131, 'Invertir dinero siempre garantiza que se obtendrá una ganancia.', 'verdadero_falso', '', '', '', 'FALSO'),
(572, 131, 'Los gastos hormiga son insignificantes y no afectan las finanzas personales.', 'verdadero_falso', '', '', '', 'FALSO'),
(573, 132, '¿Cuál de los siguientes elementos forma parte del proceso de planificación financiera?', 'multiple', 'Auditoría externa', 'Estudio de mercado', 'Establecimiento de objetivos financieros', 'Establecimiento de objetivos financieros'),
(574, 132, 'La planeación financiera busca únicamente medir la rentabilidad del negocio.', 'verdadero_falso', '', '', '', 'FALSO'),
(575, 132, '¿Qué debe contener un presupuesto institucional?', 'multiple', 'Análisis de rotación de personal', 'Proyección de ingresos  egresos y flujo de caja', 'Número de asambleas realizadas', 'Proyección de ingresos  egresos y flujo de caja'),
(576, 132, 'El POA debe incluir responsables  costos  fechas y métodos de verificación por cada acción.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(577, 132, '¿Cuál de los siguientes es un indicador clave en la gestión financiera de una cooperativa?', 'multiple', 'Nivel de afiliación política de los socios', 'Rentabilidad', 'Frecuencia de reuniones sociales', 'Rentabilidad'),
(578, 132, 'El informe gerencial mensual debe incluir un análisis de ejecutado frente a presupuesto.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(579, 132, '¿Cuál es uno de los principales objetivos del análisis de sensibilidad?', 'multiple', 'Determinar el número de empleados', 'Calcular las tasas de interés de mercado', 'Evaluar el impacto de cambios en variables críticas', 'Evaluar el impacto de cambios en variables críticas'),
(580, 132, 'El presupuesto puede ajustarse si las condiciones económicas cambian significativamente.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(581, 132, '¿Qué se requiere para abrir una nueva sucursal según la SEPS?', 'multiple', 'Opinión de los socios', 'Solicitud formal  acta de aprobación y dictamen de auditoría externa', 'Informe de cultura organizacional', 'Solicitud formal  acta de aprobación y dictamen de auditoría externa'),
(582, 132, 'La proyección del estado de resultados es suficiente para validar todo el presupuesto.', 'verdadero_falso', '', '', '', 'FALSO'),
(583, 133, '¿Cuál es el principal objetivo de la planeación financiera en una cooperativa?', 'multiple', 'Minimizar los impuestos a pagar', 'Evitar la supervisión externa', 'Traducir el plan estratégico en proyecciones económicas y sostenibles', 'Traducir el plan estratégico en proyecciones económicas y sostenibles'),
(584, 133, '¿Qué herramienta permite transformar objetivos estratégicos en actividades  metas e indicadores?', 'multiple', 'Estado de Resultados', 'Balanced Scorecard', 'Informe de Auditoría', 'Balanced Scorecard'),
(585, 133, 'El presupuesto tiene carácter:', 'multiple', 'Estratégico y a largo plazo', 'Político y coyuntural', 'Operativo y anual', 'Operativo y anual'),
(586, 133, 'El proceso presupuestario incluye fases como programación  formulación  ejecución  control y cierre.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(587, 133, 'El diagnóstico financiero integral permite:', 'multiple', 'Aprobar nuevos productos', 'Calcular el valor de aportes', 'Determinar fortalezas y debilidades financieras', 'Determinar fortalezas y debilidades financieras'),
(588, 133, '¿Qué indicador se utiliza para medir la rentabilidad del patrimonio?', 'multiple', 'ROE', 'ROA', 'Liquidez', 'ROE'),
(589, 133, 'La planeación financiera debe realizarse solo una vez cada cinco años.', 'verdadero_falso', '', '', '', 'FALSO'),
(590, 133, '¿Cuál de estos es un componente del análisis macroeconómico?', 'multiple', 'Provisión de cartera', 'Tasas de interés y entorno político', 'Flujo de caja diario', 'Tasas de interés y entorno político'),
(591, 133, 'El flujo de caja proyectado permite conocer la liquidez futura de la cooperativa.', 'verdadero_falso', '', '', '', 'VERDADERO'),
(592, 133, '¿Cuál de estos no forma parte del presupuesto de capital?', 'multiple', 'Equipos de computación', 'Terrenos', 'Gastos de personal', 'Gastos de personal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE `provincias` (
  `id_provincia` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`id_provincia`, `nombre`) VALUES
(1, 'AZUAY'),
(2, 'BOLIVAR'),
(3, 'CAÑAR'),
(4, 'CARCHI'),
(5, 'COTOPAXI'),
(6, 'CHIMBORAZO'),
(7, 'EL ORO'),
(8, 'ESMERALDAS'),
(9, 'GUAYAS'),
(10, 'IMBABURA'),
(11, 'LOJA'),
(12, 'LOS RIOS'),
(13, 'MANABI'),
(14, 'MORONA SANTIAGO'),
(15, 'NAPO'),
(16, 'PASTAZA'),
(17, 'PICHINCHA'),
(18, 'TUNGURAHUA'),
(19, 'ZAMORA CHINCHIPE'),
(20, 'GALAPAGOS'),
(21, 'SUCUMBIOS'),
(22, 'ORELLANA'),
(23, 'SANTO DOMINGO DE LOS TSACHILAS'),
(24, 'SANTA ELENA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas_alumnos`
--

CREATE TABLE `respuestas_alumnos` (
  `id_respuesta` int(11) NOT NULL,
  `id_usuario` varchar(70) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `respuesta_usuario` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_curso`
--

CREATE TABLE `tipo_curso` (
  `id_tipoc` int(11) NOT NULL,
  `norma` text NOT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `tipo_curso`
--

INSERT INTO `tipo_curso` (`id_tipoc`, `norma`, `descripcion`) VALUES
(1, 'Balance Social', 'Norma de Balance Social para Cooperativas De Ahorro y Crédito y Asociaciones Mutualistas de Ahorro y Crédito para la Vivienda'),
(2, 'Riesgo Operativo', 'Norma de Control para la Administración del Riesgo Operativo en las Entidades del Sector Financiero Popular Y Solidario'),
(3, 'Prevención del Lavado de Activos', 'Norma de Prevención del Lavado de Activos y Financiamiento de Delitos (LA/FT)'),
(4, 'Buen Gobierno', 'Norma de Control del Buen Gobierno, Ética y Comportamiento para las Cooperativas de Ahorro y Crédito, Cajas Centrales y Asociaciones Mutualistas de Ahorro y Crédito para la Vivienda'),
(5, 'Auditoria Interna', 'Norma de Control para el Ejercicio de la Auditoría Interna (Consejo de Vigilancia)'),
(10, 'COSEDE', 'Norma de Difusión del Seguro de Depósitos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_juego`
--

CREATE TABLE `tipo_juego` (
  `id_tipoj` int(11) NOT NULL,
  `titulo` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `tipo_juego`
--

INSERT INTO `tipo_juego` (`id_tipoj`, `titulo`) VALUES
(1, 'Sopa de Letras'),
(2, 'Crucigrama'),
(3, 'Memoria'),
(4, 'Conecta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id_tipo` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id_tipo`, `tipo`) VALUES
(1, 'Socio'),
(2, 'Representante'),
(3, 'Trabajador'),
(4, 'Directivo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Codigo`);

--
-- Indices de la tabla `cantones`
--
ALTER TABLE `cantones`
  ADD PRIMARY KEY (`id_canton`),
  ADD KEY `id_provincia` (`id_provincia`);

--
-- Indices de la tabla `clase`
--
ALTER TABLE `clase`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clase_alumno`
--
ALTER TABLE `clase_alumno`
  ADD PRIMARY KEY (`id_clase_alumno`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`idc`);

--
-- Indices de la tabla `correos_enviados`
--
ALTER TABLE `correos_enviados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cuenta`
--
ALTER TABLE `cuenta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Indices de la tabla `curso_alumno`
--
ALTER TABLE `curso_alumno`
  ADD PRIMARY KEY (`id_curso_alumno`);

--
-- Indices de la tabla `curso_clase`
--
ALTER TABLE `curso_clase`
  ADD PRIMARY KEY (`id_curso_clase`);

--
-- Indices de la tabla `encuesta_rapida`
--
ALTER TABLE `encuesta_rapida`
  ADD PRIMARY KEY (`id_pregunta`);

--
-- Indices de la tabla `encuesta_respuesta`
--
ALTER TABLE `encuesta_respuesta`
  ADD PRIMARY KEY (`id_respuesta`);

--
-- Indices de la tabla `encuesta_usuario`
--
ALTER TABLE `encuesta_usuario`
  ADD PRIMARY KEY (`id_notas`);

--
-- Indices de la tabla `estado_curso`
--
ALTER TABLE `estado_curso`
  ADD PRIMARY KEY (`id_estado`);

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD PRIMARY KEY (`Codigo`);

--
-- Indices de la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `juego_alumno`
--
ALTER TABLE `juego_alumno`
  ADD PRIMARY KEY (`id_juego_alumno`);

--
-- Indices de la tabla `juego_clase`
--
ALTER TABLE `juego_clase`
  ADD PRIMARY KEY (`id_clase_juego`);

--
-- Indices de la tabla `notas_usuario`
--
ALTER TABLE `notas_usuario`
  ADD PRIMARY KEY (`id_notas`);

--
-- Indices de la tabla `palabras`
--
ALTER TABLE `palabras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `parroquias`
--
ALTER TABLE `parroquias`
  ADD PRIMARY KEY (`id_parroquia`),
  ADD KEY `id_canton` (`id_canton`);

--
-- Indices de la tabla `preguntas_rapidas`
--
ALTER TABLE `preguntas_rapidas`
  ADD PRIMARY KEY (`id_pregunta`);

--
-- Indices de la tabla `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indices de la tabla `respuestas_alumnos`
--
ALTER TABLE `respuestas_alumnos`
  ADD PRIMARY KEY (`id_respuesta`);

--
-- Indices de la tabla `tipo_curso`
--
ALTER TABLE `tipo_curso`
  ADD PRIMARY KEY (`id_tipoc`);

--
-- Indices de la tabla `tipo_juego`
--
ALTER TABLE `tipo_juego`
  ADD PRIMARY KEY (`id_tipoj`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id_tipo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cantones`
--
ALTER TABLE `cantones`
  MODIFY `id_canton` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;

--
-- AUTO_INCREMENT de la tabla `clase`
--
ALTER TABLE `clase`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT de la tabla `clase_alumno`
--
ALTER TABLE `clase_alumno`
  MODIFY `id_clase_alumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `idc` int(17) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `correos_enviados`
--
ALTER TABLE `correos_enviados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cuenta`
--
ALTER TABLE `cuenta`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `curso_alumno`
--
ALTER TABLE `curso_alumno`
  MODIFY `id_curso_alumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `curso_clase`
--
ALTER TABLE `curso_clase`
  MODIFY `id_curso_clase` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2034;

--
-- AUTO_INCREMENT de la tabla `encuesta_rapida`
--
ALTER TABLE `encuesta_rapida`
  MODIFY `id_pregunta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=652;

--
-- AUTO_INCREMENT de la tabla `encuesta_respuesta`
--
ALTER TABLE `encuesta_respuesta`
  MODIFY `id_respuesta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `encuesta_usuario`
--
ALTER TABLE `encuesta_usuario`
  MODIFY `id_notas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estado_curso`
--
ALTER TABLE `estado_curso`
  MODIFY `id_estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `juego_alumno`
--
ALTER TABLE `juego_alumno`
  MODIFY `id_juego_alumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `juego_clase`
--
ALTER TABLE `juego_clase`
  MODIFY `id_clase_juego` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `notas_usuario`
--
ALTER TABLE `notas_usuario`
  MODIFY `id_notas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `palabras`
--
ALTER TABLE `palabras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `parroquias`
--
ALTER TABLE `parroquias`
  MODIFY `id_parroquia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1251;

--
-- AUTO_INCREMENT de la tabla `preguntas_rapidas`
--
ALTER TABLE `preguntas_rapidas`
  MODIFY `id_pregunta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=593;

--
-- AUTO_INCREMENT de la tabla `respuestas_alumnos`
--
ALTER TABLE `respuestas_alumnos`
  MODIFY `id_respuesta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_curso`
--
ALTER TABLE `tipo_curso`
  MODIFY `id_tipoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tipo_juego`
--
ALTER TABLE `tipo_juego`
  MODIFY `id_tipoj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cantones`
--
ALTER TABLE `cantones`
  ADD CONSTRAINT `cantones_ibfk_1` FOREIGN KEY (`id_provincia`) REFERENCES `provincias` (`id_provincia`);

--
-- Filtros para la tabla `parroquias`
--
ALTER TABLE `parroquias`
  ADD CONSTRAINT `parroquias_ibfk_1` FOREIGN KEY (`id_canton`) REFERENCES `cantones` (`id_canton`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
