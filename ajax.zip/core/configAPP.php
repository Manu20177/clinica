<?php
	/*===========================================
	|  Datos del servidor - Data of the server  |
	===========================================*/
	const SERVER="localhost";
	const DB="u891835606_plantilla";
	const USER='u891835606_Manu20177';
	const PASS="MMTechSolutions2025*";

	
	
	const SGBD="mysql:host=".SERVER.";dbname=".DB;


	/*===========================================
	| Datos de la encriptacion - Encryption data |
	===========================================*/
	const METHOD='AES-256-CBC';
	const SECRET_KEY='$SPV@2024';
	const SECRET_IV='179120';