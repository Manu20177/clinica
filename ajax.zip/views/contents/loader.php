<!-- views/loader.php -->
<div id="global-loader">
  <div class="loader"></div>
</div>