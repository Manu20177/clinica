<title><?php echo COMPANY; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<link rel="shortcut icon" href="<?php echo SERVERURL; ?>views/assets/icons/logo.ico" />
<link rel="stylesheet" href="<?php echo SERVERURL; ?>views/css/loader.css">

<link rel="stylesheet" href="<?php echo SERVERURL; ?>views/css/main.css">
<link rel="stylesheet" href="<?php echo SERVERURL; ?>views/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo SERVERURL; ?>views/css/buttons.dataTables.min.css">

<script src="<?php echo SERVERURL; ?>views/js/jquery-3.6.0.min.js"></script>
<script src="<?php echo SERVERURL; ?>views/js/sweetalert2.min.js"></script>
<script src="<?php echo SERVERURL; ?>views/js/chart.js"></script>
<script src="<?php echo SERVERURL; ?>views/js/exceljs.min.js"></script>
<div id="global-loader">
  <div class="loader"></div>
</div>
